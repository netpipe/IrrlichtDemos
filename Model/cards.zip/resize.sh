#!/bin/bash
#ls | while read in; do name=$(echo $in|cut -d "." -f 0);if $name="C";then;name="CLUBS");echo $name; convert "./$in" -resize 30% "./converted/$in.2";done  



ls | while read in;
 do name=$(echo $in | cut -d "." -f 1); 
name1=$(echo $name |tail -c 2)

name2=$(echo $name | cut -c1-1)
echo "$name1$name2"

if [[ $name1 == "C" ]]; then
name="CLUBS";
fi;
if [[ $name1 == "H" ]]; then
name="HEARTS";
fi;
if [[ $name1 == "D" ]]; then
name="DIAMONDS";
fi;
if [[ $name1 == "S" ]]; then
name="SPADES";
fi;

convert "./$in" -resize 8% "./converted/$name2$name.jpg"
echo $name;
done;
