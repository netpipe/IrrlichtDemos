#ifndef AZADI_H
#define AZADI_H

#ifndef __OSX__
	#include <AL/al.h>
	#include <AL/alc.h>
#else
	#include <OpenAL/al.h>
	#include <OpenAL/alc.h>
#endif

#include "Input/Input.h"
#include "GUI/FPSCounter.h"
#include "Particle/ParticleFactory.h"
#include "Texture/TextureFactory.h"
#include "Sound/SoundFactory.h"

//#define PI 3.1415926535897932384626433832795f
#define PI 3.14159
const float piover180 = 0.0174532925f;


class ModelFactory ;
class Drawing;
class Textures;
class SDL_Surface;

enum mov
{
    FORWARD=0,
    BACKWARD,
    LEFT,
    RIGHT
};

//! The main Azadi class that handles the main game loop
class Azadi : public eventListener,ConsoleListener
{
    public:
        Azadi(int argc, char** argv);
	~Azadi(); // Cleans up the engine
        int Run();
        GLubyte *glext; // Contains the GL extensions available
    private:
        bool Init();
        void drawCursor(vector3f<GLfloat> forward, float ix, float iy);   // Cursor drawing
        bool Draw();
        void ProcessMessages();
        void parseParameters(int argc, char** argv);
        void cmdTriggered(std::string cmd);
        void cmdReleased(std::string cmd);
        std::string acceptConsoleCommand(std::string);


        Drawing* drawing;

        //! Screen size
        int screen[2];

        //! Window SDL-Handler
        SDL_Surface* window;

        GUI::FPSCounter fps_counter;

        //! Program done?
        bool done;

        //! Mouse position
        int mouse[2];

        //! Koordinates of the center
        int center[2];

        // Selction and dispatch status
        bool selecting;
        bool dispatching;

        // Dispatch cursor position
        GLfloat cursorPos;
        GLfloat curMousePos;

        GLfloat origPos[3];
        GLfloat cursPos[3];
        GLfloat CamPos[3];

        GLfloat dxrot;
        GLfloat dyrot;

        bool MoveKey[4];

        ModelFactory * Modeldata;

        ParticleFactory *testPart;

        ALCcontext *soundContext;
        ALCdevice *soundDevice;

        bool soundDeviceWorking;
        bool fullScreen;
        bool withAudio;
};


#endif
