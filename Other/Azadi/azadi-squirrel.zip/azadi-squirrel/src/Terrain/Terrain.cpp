#include "Terrain.h"
#include <math.h>
#include <cstdlib>
#include <iostream>
#include "../vector.h"
const float piover180 = 0.0174532925f;

cTrainP::cTrainP(){}

cTerrainDT::cTerrainDT(){}

Terrain::Terrain()
{
	frustum = new Frustum;  //Instantiate the frustum class
}

Terrain::~Terrain(){}


void Terrain::Initialise(){
//seed, smooth, LOD, rough, tzpe, TNum
Sphere(5,5);
//fillnoise(123,1, 1,1,1,1);

}


void Terrain::Draw(){
// need to fill noise then tile it
// LOD lookup
// 1  - DTile 6x6 1x1 tri strip
// 2  - DTile 6x6 fan 3 to 1 lod convert
// 3  - DTile 6x6 strip
//  4 = DTile 6x6 fan 2 to 1 lod convert
// 5  - DTile big patch scaler's
//  6 = DTileregular 6x6 triangle fan

    frustum->ExtractFrustum();
//	PointInFrustum(1,1,1);

//glCallList(sphereDL);
int end1=16;
bool close=1;
 if (close){
	 unsigned int innerT=0;
bool point=0;
bool chopT=0;
bool chopB=0;
bool chop=0;
int c=14;
int Xstart=2;
int BR1=0,BR2=0;
int TR1=0,TR2=0;
unsigned int zlimit=0;
unsigned int zstart=0;

		unsigned int z=2;
  if (frustum->SphereCheck(2*24,0,2*24,4*24)){//bottom left
	chop=1;
	chopT=1;
	chopB=0;
	end1 = 8;
	c=8;
	point=1;
	zlimit = 6;
  }

  if (frustum->SphereCheck(2*24,0,10*24,4*24)){//bottom right
	chop=1;
	chopT=0;	//chop Top
	chopB=1;	//chop Bottom
	end1 = 8;	//end top and bottom at 6
	c=8;		//chop at 8 rows X
	point=1;	//set to point in frustum
	zstart = 4;	//z starts at 4+2 = 6
	zlimit = 10;	//z ends at 12
  }


  if (frustum->SphereCheck(14*24,0,10*24,4*24)){//top right
	chop=0;
	chopT=0;
	chopB=1;
	Xstart=8;
	BR1=8;
	BR2=8;
	point=1;
	TR1 = 8;
	TR2 = 8;
	zstart=4;
	zlimit = 10;
  }

  if (frustum->SphereCheck(14*24,0,2*24,4*24)){//top left
	chop=0;
	chopT=1;
	chopB=0;
	Xstart=8;
	BR1=8;
	BR2=8;
	point=1;
	TR1 = 16;
	TR2 = 16;
	zlimit = 6;
	zstart = 0;
  }


// middle ones get checked last
  if (frustum->SphereCheck(13*24,0,6*24,1*24)){//tm
chop=0;
chopT=0;
chopB=0;
Xstart=8;
BR1=8;
BR2=8;
point=1;
TR1 = 8;
TR2 = 8;
zlimit = 12;
zstart = 2;
}

  if (frustum->SphereCheck(8*24,0,12*24,1*24)){//right middle
chop=0;
chopT=1;
chopB=0;
Xstart=8;
BR1=8;
BR2=8;
point=1;
TR1 = 8;
TR2 = 8;
zlimit = 6;
zstart = 6;
}//

 if (frustum->SphereCheck(0*24,0,6*24,1*24)){//bottom middle
chopT=0;
chopB=0;
end1 = 8;
c=8;
point=1;
}

  if (frustum->SphereCheck(8*24,0,0*24,1*24)){//left middle
chopT=0;
chopB=1;
Xstart=8;
BR1=8;
BR2=8;
point=1;
TR1 = 8;
TR2 = 8;
zlimit = 6;
zstart = 6;
}


if (point){
									//LOD, x, z.DTNumber,patch,scale
if (!chopB){
		for (BR1; BR1 < end1; BR1++){
		DrawTerrainT(5,BR1,innerT,innerT,0,1);
		}
		innerT++;
		for (BR2; BR2 < end1; BR2++){
		DrawTerrainT(5,BR2,innerT,innerT,0,1);
		}		
}
innerT++;
z = zstart+2;
	unsigned int ST=7; // start tile

	for (unsigned int core=0; core < 3; core++){
  if(z < zlimit){
  	 for (unsigned int Tinc=0; Tinc < 4; Tinc++){

		if (chop){
				DrawTerrainT(5,0,z,innerT,0,1);
				DrawTerrainT(5,1,z,innerT,0,1);
		}

					for (unsigned int DTrowloop=Xstart; DTrowloop < c; DTrowloop++)
					{
				 	DrawTerrainT(1,DTrowloop,z,ST,0,0);
				 	ST++;
					}
		if (!chop){
				DrawTerrainT(5,14,z,innerT,0,1);
				DrawTerrainT(5,15,z,innerT,0,1);
		}
	z++;
  }	
 	 }
	innerT++;
	}

if (!chopT){
		 for (TR1; TR1 < end1; TR1++){
		  DrawTerrainT(5,TR1,z,1,0,1);
		 }
		 z++;
		 for (TR2; TR2 < end1; TR2++){
		  DrawTerrainT(5,TR2,z,1,0,1);
		 }
 }
}//end of point check

//////////////
////////////
//////////								Far Away Tile Draw Funct!
////////
} else {
	if (frustum->SphereCheck(192,0,192,300)){
	//	for (int DTNumber=0; DTNumber < 1; DTNumber+=1){
	//	for (int g; g< 10; g++){
	int DTNumber=0;
	  for (int x=0; x< 12; x++){
	   int patch=0;
		DTNumber++;
		TTile[DTNumber].x = x;
		for (int z=0; z< 16; z++){
			TTile[DTNumber].z = z;
	//int 			LOD, x, z.DTNumber,patch,scale
			DrawTerrainT(5,x,z,DTNumber,patch,1);
		}
	patch++;
	  }
 	}//end cpherecheck
 }//endif
	

}


void Terrain::fillnoise(int seed,int smooth, int LOD,int rough,int tzpe,int TNum){
//srand(seed);
	// we need to fill outer rim too rememmber

for (int i=0;i<10;i++){
  for (int DTp = 1 ; DTp < 16 ; DTp+=1){
	for (int z = 0; z < 8; z+=LOD){
		for (int x = 0; x < 8; x+=LOD){
	//seed = seed*(x+z+x*x) ;
			TTile[i].Patch[DTp].Train[x][z] += Noise(x,z,seed,rough,tzpe);
		}
	}
 }
}
//	smoothNoise(smooth,LOD,1);
}



float Terrain::Noise(int x, int z,int seed,int rough, int tzpe){
 
	int n;
	n = x * z * rand() ;
//	n = (n << 10);
//	n = n * n / 1337073843;
	//if (n<0){n=0;} // Thold
	return ( n );
}
 
 
 
void Terrain::smoothNoise(int times, int LOD, int rough){
 for (int i=0; i < times; i++){
  for (int DTNumber = 1 ; DTNumber < 23 ; DTNumber+=1){ // DTile width loop the 
	for (int DTp = 0 ; DTp < 16 ; DTp+=1){
		for (int z = 1; z < 7 ; z+=LOD){
			for (int x = 1; x < 7; x+=LOD){
 
   				float corners = ( 
				TTile[DTNumber].Patch[DTp].Train[x-LOD][z-LOD]+
				TTile[DTNumber].Patch[DTp].Train[x+LOD][z-LOD]+
				TTile[DTNumber].Patch[DTp].Train[x-LOD][z+LOD]+
				TTile[DTNumber].Patch[DTp].Train[x+LOD][z+LOD] ) / 16;

				float sides = ( 
				TTile[DTNumber].Patch[DTp].Train[x-LOD][z]  +
				TTile[DTNumber].Patch[DTp].Train[x+LOD][z]  +
				TTile[DTNumber].Patch[DTp].Train[x][z-LOD]  +
				TTile[DTNumber].Patch[DTp].Train[x][z+LOD] ) /  8;

				float center = TTile[DTNumber].Patch[DTp].Train[x][z] / 4;
				TTile[DTNumber].Patch[DTp].Train[x][z] = (corners + sides + center);
			}
		}
	}
  }
 }
}


///////		//////////////////////////////////////////////////////////////////////////////
/////////////////////////////////			////////////	     /////////////////
////////			 ////////////////////////////				//////
//////////////////////////////////////////////////////////////////////////////////////////////

void Terrain::DrawTerrainT(int LOD,int x,int y,int DTNumber,int Dtile,int scale)
{

TTile[DTNumber].z=y*24;
TTile[DTNumber].x=x*24;

	if (frustum->SphereCheck(TTile[DTNumber].x+12,1,TTile[DTNumber].z+12,14)){

switch(LOD){
// 1  - 1x1 tri strip

  case 1 : {
int g=0;
	 for (int DTp = 0 ; DTp < 16 ; DTp+=4){
		TTile[DTNumber].Patch[DTp].z=TTile[DTNumber].z+g;
	  for (int strip=0; strip < 24; strip+=6){//fill routine
		TTile[DTNumber].Patch[DTp].x=TTile[DTNumber].x+strip;
	    for (int z = TTile[DTNumber].Patch[DTp].z; z < TTile[DTNumber].Patch[DTp].z+6+scale; z+=1+scale){

		int zp1= z+1+scale;
	     for (int x = TTile[DTNumber].Patch[DTp].x; x < TTile[DTNumber].Patch[DTp].x+6+scale; x+=1+scale){

		int xp1= x+1+scale;

	float xz=TTile[DTNumber].Patch[DTp].Train[x][z];
	float xzp1=TTile[DTNumber].Patch[DTp].Train[x][zp1];
	float xp1zp1=TTile[DTNumber].Patch[DTp].Train[xp1][zp1];
	float xp1z=TTile[DTNumber].Patch[DTp].Train[xp1][z];
	//printf("%i",DTp);
		glBegin(GL_TRIANGLE_STRIP); 
		glColor3f(xp1zp1, 1 , xp1zp1);
			glVertex3f(xp1, xp1zp1, zp1);
		glColor3f(0.5, xp1z , 1);
			glVertex3f(xp1, xp1z, z);
		glColor3f(xzp1, 1 , 1);
			glVertex3f(x, xzp1, zp1 );
		glColor3f(xz, xz , 1);
			glVertex3f(x, xz , z ); 
		glEnd();

	
}}}g+=6;DTp++;
 }
break;
}



case 2 :{
// 2  - 6x6 fan 3 to 1 lod convert

int g=0;
	 for (int DTp = 0 ; DTp < 16 ; DTp+=4){
		TTile[DTNumber].Patch[DTp].z=TTile[DTNumber].z+g;
	  for (int strip=0; strip < 4; strip+=1){
		TTile[DTNumber].Patch[DTp].x=TTile[DTNumber].x+strip*6;//x location

  glBegin(GL_TRIANGLE_FAN);
	glColor3f(1, 1, 1);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+3,
		TTile[DTNumber].Patch[DTp].Train[4][4],
		TTile[DTNumber].Patch[DTp].z+3);
	glColor3f(1, 0, 1);
glTexCoord3f(-1.0, -1.0, 0.0);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+6,	//br
		TTile[DTNumber].Patch[DTp].Train[7][7],
		TTile[DTNumber].Patch[DTp].z+6);
		 if (TTile[DTNumber].Patch[DTp].nLOD[3] < LOD){
	glVertex3f( TTile[DTNumber].Patch[DTp].x+6,
		TTile[DTNumber].Patch[DTp].Train[7][6],
		TTile[DTNumber].Patch[DTp].z+5);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+6,
		TTile[DTNumber].Patch[DTp].Train[7][5],
		TTile[DTNumber].Patch[DTp].z+4);
		 }//
	glVertex3f( TTile[DTNumber].Patch[DTp].x+6,	//rm
		TTile[DTNumber].Patch[DTp].Train[7][4],
		TTile[DTNumber].Patch[DTp].z+3);
		 if (TTile[DTNumber].Patch[DTp].nLOD[3] < LOD){
	glVertex3f( TTile[DTNumber].Patch[DTp].x+6,
		TTile[DTNumber].Patch[DTp].Train[7][4],
		TTile[DTNumber].Patch[DTp].z+2);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+6,
		TTile[DTNumber].Patch[DTp].Train[7][2],
		TTile[DTNumber].Patch[DTp].z+1);
		 }//
glTexCoord3f(1.0, 1.0, 0.0);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+6,	//tr
		TTile[DTNumber].Patch[DTp].Train[7][1],
		TTile[DTNumber].Patch[DTp].z+0);
	glColor3f(0, 0, 1);
		 if (TTile[DTNumber].Patch[DTp].nLOD[2] < LOD){
	glVertex3f( TTile[DTNumber].Patch[DTp].x+5,
		TTile[DTNumber].Patch[DTp].Train[6][1],
		TTile[DTNumber].Patch[DTp].z+0);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+4,
		TTile[DTNumber].Patch[DTp].Train[5][1],
		TTile[DTNumber].Patch[DTp].z+0);
		 }//
	glVertex3f( TTile[DTNumber].Patch[DTp].x+3,	//tm
		TTile[DTNumber].Patch[DTp].Train[4][1],
		TTile[DTNumber].Patch[DTp].z+0);
//	glColor3f(0, 0, 0.5);
		 if (TTile[DTNumber].Patch[DTp].nLOD[2] < LOD){
	glVertex3f( TTile[DTNumber].Patch[DTp].x+2,
		TTile[DTNumber].Patch[DTp].Train[3][1],
		TTile[DTNumber].Patch[DTp].z+0);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+1,
		TTile[DTNumber].Patch[DTp].Train[3][1],
		TTile[DTNumber].Patch[DTp].z+0);
		 }//
	glVertex3f( TTile[DTNumber].Patch[DTp].x+0,	//tl
		TTile[DTNumber].Patch[DTp].Train[1][1],
		TTile[DTNumber].Patch[DTp].z+0);
		 if (TTile[DTNumber].Patch[DTp].nLOD[1] < LOD){
	glVertex3f( TTile[DTNumber].Patch[DTp].x+0,
		TTile[DTNumber].Patch[DTp].Train[1][2],
		TTile[DTNumber].Patch[DTp].z+1);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+0,
		TTile[DTNumber].Patch[DTp].Train[1][3],
		TTile[DTNumber].Patch[DTp].z+2);
		 }//
	glVertex3f( TTile[DTNumber].Patch[DTp].x+0, 	//ml
		TTile[DTNumber].Patch[DTp].Train[1][4],
		TTile[DTNumber].Patch[DTp].z+3);
		 if (TTile[DTNumber].Patch[DTp].nLOD[1] < LOD){
	glVertex3f( TTile[DTNumber].Patch[DTp].x+0,
		TTile[DTNumber].Patch[DTp].Train[1][5],
		TTile[DTNumber].Patch[DTp].z+4);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+0,
		TTile[DTNumber].Patch[DTp].Train[1][6],
		TTile[DTNumber].Patch[DTp].z+5);
		 }//
glTexCoord3f(1.0, -1.0, 0.0);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+0,	 //bl
		TTile[DTNumber].Patch[DTp].Train[1][7],
		TTile[DTNumber].Patch[DTp].z+6);
		 if (TTile[DTNumber].Patch[DTp].nLOD[0] < LOD){
	glVertex3f( TTile[DTNumber].Patch[DTp].x+1,
		TTile[DTNumber].Patch[DTp].Train[2][7],
		TTile[DTNumber].Patch[DTp].z+6);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+2,
		TTile[DTNumber].Patch[DTp].Train[3][7],
		TTile[DTNumber].Patch[DTp].z+6);
		 }
	glVertex3f( TTile[DTNumber].Patch[DTp].x+3, 	//bm
		TTile[DTNumber].Patch[DTp].Train[4][7],
		TTile[DTNumber].Patch[DTp].z+6);
		 if (TTile[DTNumber].Patch[DTp].nLOD[0] < LOD){
	glVertex3f( TTile[DTNumber].Patch[DTp].x+4,
		TTile[DTNumber].Patch[DTp].Train[5][7],
		TTile[DTNumber].Patch[DTp].z+6);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+6,
		TTile[DTNumber].Patch[DTp].Train[6][7],
		TTile[DTNumber].Patch[DTp].z+6);
		 }/// finish off the triangle back where we started
	glColor3f(0, 0, 1);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+6,
		TTile[DTNumber].Patch[DTp].Train[7][7],
		TTile[DTNumber].Patch[DTp].z+6);
	 glEnd();
}g+=6;}
break;
}

  case 3 :{
// 3  - 6x6 tristrip
int g=0;
	 for (int DTp = 0 ; DTp < 16 ; DTp+=4){
		TTile[DTNumber].Patch[DTp].z=TTile[DTNumber].z+g;
	  for (int strip=0; strip < 4; strip+=1){
		TTile[DTNumber].Patch[DTp].x=TTile[DTNumber].x+strip*6;//x location

  	 glBegin(GL_TRIANGLE_STRIP);
	glColor3f(1, 2, 1);
		glVertex3f( TTile[DTNumber].Patch[DTp].x+6,
			TTile[DTNumber].Patch[DTp].Train[6][6],
			TTile[DTNumber].Patch[DTp].z+6);
glColor3f(0, 1, 1);
		glVertex3f( TTile[DTNumber].Patch[DTp].x+6,
			TTile[DTNumber].Patch[DTp].Train[6][0],
			TTile[DTNumber].Patch[DTp].z);
		glVertex3f( TTile[DTNumber].Patch[DTp].x,
			TTile[DTNumber].Patch[DTp].Train[0][6],
			TTile[DTNumber].Patch[DTp].z+6);
		glVertex3f( TTile[DTNumber].Patch[DTp].x,
			TTile[DTNumber].Patch[DTp].Train[0][0],
			TTile[DTNumber].Patch[DTp].z);
	 glEnd();
}g+=6;}
break;
}

 case 4 : { 
//  4 = 6x6 fan 2 to 1 lod convert
int g=0;
	 for (int DTp = 0 ; DTp < 16 ; DTp+=4){
		TTile[DTNumber].Patch[DTp].z=TTile[DTNumber].z+g;
	  for (int strip=0; strip < 4; strip+=1){
		TTile[DTNumber].Patch[DTp].x=TTile[DTNumber].x+strip*6;//x location
	glBegin(GL_TRIANGLE_FAN);
		glColor3f(1, 1, 0);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+3,	//center
		TTile[DTNumber].Patch[DTp].Train[4][4],
		TTile[DTNumber].Patch[DTp].z+3);
		glColor3f(0, 1, 1);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+6,	// br
		TTile[DTNumber].Patch[DTp].Train[7][7],
		TTile[DTNumber].Patch[DTp].z+6);
		 if (TTile[DTNumber].Patch[DTp].nLOD[3] > LOD){
	glVertex3f(TTile[DTNumber].Patch[DTp].x+6,
		TTile[DTNumber].Patch[DTp].Train[7][4],
		TTile[DTNumber].Patch[DTp].z+3);
			} //right middle
		glVertex3f( TTile[DTNumber].Patch[DTp].x+6,//tr
		TTile[DTNumber].Patch[DTp].Train[7][1],
		TTile[DTNumber].Patch[DTp].z+0);
		 if (TTile[DTNumber].Patch[DTp].nLOD[2] > LOD){
	glVertex3f( TTile[DTNumber].Patch[DTp].x+3,
		TTile[DTNumber].Patch[DTp].Train[4][1],
		TTile[DTNumber].Patch[DTp].z+0);
			} //middle top
	glVertex3f( TTile[DTNumber].Patch[DTp].x+0, //tl
		TTile[DTNumber].Patch[DTp].Train[1][1],
		TTile[DTNumber].Patch[DTp].z+0);
		 if (TTile[DTNumber].Patch[DTp].nLOD[1] > LOD){
	glVertex3f( TTile[DTNumber].Patch[DTp].x+0,
		TTile[DTNumber].Patch[DTp].Train[1][4],
		TTile[DTNumber].Patch[DTp].z+3);
			} //left middle
	glVertex3f( TTile[DTNumber].Patch[DTp].x+0, //bl
		TTile[DTNumber].Patch[DTp].Train[1][7],
		TTile[DTNumber].Patch[DTp].z+6);
		 if (TTile[DTNumber].Patch[DTp].nLOD[0] > LOD){
	glVertex3f( TTile[DTNumber].Patch[DTp].x+3,
		TTile[DTNumber].Patch[DTp].Train[4][7],
		TTile[DTNumber].Patch[DTp].z+6);
			} //bottom extra
	glVertex3f( TTile[DTNumber].Patch[DTp].x+6,	//br
		TTile[DTNumber].Patch[DTp].Train[7][7],
		TTile[DTNumber].Patch[DTp].z+6);
	glEnd();
}g+=6;}
 break;
}//endCase

case 5 : {
// 5  - big patch scaler's
		TTile[DTNumber].x=x*24*scale;
		TTile[DTNumber].z=y*24*scale;
		TTile[DTNumber].Patch[Dtile].z=TTile[DTNumber].z;
		TTile[DTNumber].Patch[Dtile].x=TTile[DTNumber].x;//x location
	glBegin(GL_TRIANGLE_FAN);
		glColor3f(1, 1, 0);
	glVertex3f( TTile[DTNumber].Patch[Dtile].x+12*scale,	//center
		TTile[DTNumber].Patch[Dtile].Train[4][4],
		TTile[DTNumber].Patch[Dtile].z+12*scale);
		glColor3f(0, 1, 1);
	glVertex3f( TTile[DTNumber].Patch[Dtile].x+24*scale,	// br
		TTile[DTNumber].Patch[Dtile].Train[7][7],
		TTile[DTNumber].Patch[Dtile].z+24*scale);
			//right middle
		glVertex3f( TTile[DTNumber].Patch[Dtile].x+24*scale,//tr
		TTile[DTNumber].Patch[Dtile].Train[7][1],
		TTile[DTNumber].Patch[Dtile].z);
			//middle top
	glVertex3f( TTile[DTNumber].Patch[Dtile].x, //tl
		TTile[DTNumber].Patch[Dtile].Train[1][1],
		TTile[DTNumber].Patch[Dtile].z);
			//left middle
	glVertex3f( TTile[DTNumber].Patch[Dtile].x, //bl
		TTile[DTNumber].Patch[Dtile].Train[1][7],
		TTile[DTNumber].Patch[Dtile].z+24*scale);
			//bottom extra
	glVertex3f( TTile[DTNumber].Patch[Dtile].x+24*scale,	//br
		TTile[DTNumber].Patch[Dtile].Train[7][7],
		TTile[DTNumber].Patch[Dtile].z+24*scale);
	glEnd();
break;
}

case 6 : {
//  6 = regular 6x6 triangle fan
int g=0;
	 for (int DTp = 0 ; DTp < 16 ; DTp+=4){
		TTile[DTNumber].Patch[DTp].z=TTile[DTNumber].z+g;
	  for (int strip=0; strip < 4; strip+=1){
		TTile[DTNumber].Patch[DTp].x=TTile[DTNumber].x+strip*6;//x location
	glBegin(GL_TRIANGLE_FAN);
		glColor3f(1, 1, 0);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+3,	//center
		TTile[DTNumber].Patch[DTp].Train[4][4],
		TTile[DTNumber].Patch[DTp].z+3);
		glColor3f(0, 1, 1);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+6,	// br
		TTile[DTNumber].Patch[DTp].Train[7][7],
		TTile[DTNumber].Patch[DTp].z+6);
		glVertex3f( TTile[DTNumber].Patch[DTp].x+6,//tr
		TTile[DTNumber].Patch[DTp].Train[7][1],
		TTile[DTNumber].Patch[DTp].z+0);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+0, //tl
		TTile[DTNumber].Patch[DTp].Train[1][1],
		TTile[DTNumber].Patch[DTp].z+0);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+0, //bl
		TTile[DTNumber].Patch[DTp].Train[1][7],
		TTile[DTNumber].Patch[DTp].z+6);
	glVertex3f( TTile[DTNumber].Patch[DTp].x+6,	//br
		TTile[DTNumber].Patch[DTp].Train[7][7],
		TTile[DTNumber].Patch[DTp].z+6);
	glEnd();
}g+=6;}
break;
}


}//End Switch
}// end of Tile Frustum check
}




void Terrain::Sphere(int dtheta,int dphi){

   int n;
   int theta,phi;
   vector3f<float> Vertex[4];

sphereDL = glGenLists(1);

glNewList(sphereDL,GL_COMPILE);

   for (theta=-90;theta<=90-dtheta;theta+=dtheta) {
      for (phi=0;phi<=360-dphi;phi+=dphi) {
         n = 0;
         Vertex[n].X = cos(theta*piover180) * cos(phi*piover180);
         Vertex[n].Y = cos(theta*piover180) * sin(phi*piover180);
         Vertex[n].Z = sin(theta*piover180);
         n++;
         Vertex[n].X = cos((theta+dtheta)*piover180) * cos(phi*piover180);
         Vertex[n].Y = cos((theta+dtheta)*piover180) * sin(phi*piover180);
         Vertex[n].Z = sin((theta+dtheta)*piover180);
         n++;
         Vertex[n].X = cos((theta+dtheta)*piover180) * cos((phi+dphi)*piover180);
         Vertex[n].Y = cos((theta+dtheta)*piover180) * sin((phi+dphi)*piover180);
         Vertex[n].Z = sin((theta+dtheta)*piover180);
         n++;

         if (theta > -90 && theta < 90) {
            Vertex[n].X = cos(theta*piover180) * cos((phi+dphi)*piover180);
            Vertex[n].Y = cos(theta*piover180) * sin((phi+dphi)*piover180);
            Vertex[n].Z = sin(theta*piover180);
            n++;
         }


//
glColor3f(3,1,0);
//

glPushMatrix();
//glTranslatef(222,20,222);
glScalef(5,5,5);
glPointSize(5);
glBegin(GL_POINTS);
for (int i=0; i < 3;i++){
glVertex3f(Vertex[i].X,Vertex[i].Y,Vertex[i].Z);
}
glEnd();
glPopMatrix();


      }
   }
glEndList();
}

