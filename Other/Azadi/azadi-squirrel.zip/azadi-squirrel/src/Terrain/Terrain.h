#ifndef TERRAIN_H
#define TERRAIN_H

#ifndef __OSX__
	#include <GL/gl.h>
#else
	#include <OpenGL/gl.h>
#endif

#include "../vector.h"
#include "../Camera/Frustum.h"

const int Twidth=7;
const int MTWidth=24;
//const int DTpn=5;

class cTrainP{
	public:
		cTrainP();
		int LOD;
		int x,z; //bottom right start coords
		//int roughness,material;
		float Train[8][8];// extra row for smoothing
		int nLOD[4];
};

class cTerrainDT{
	public:
		int x,y,z;
		cTerrainDT();
		//vector3f<float> Vertex;
		cTrainP Patch[16]; //4x4 tile from of 6x6
};

//cTerrainDT TTile[(MTWidth * MTWidth)];
//cTerrainDT *TTile = new cTerrainDT[100];

class Terrain
{
	public:
		Terrain();  // Constructor
		~Terrain();  // Destructor
		void Initialise();
		void Draw();
		//void cTDraw();
		float Noise (int x, int z, int seed, int rough, int tzpe);
		void smoothNoise(int times, int LOD, int rough);
		void fillnoise(int seed,int smooth, int LOD,int rough,int tzpe,int TNum);
		//float GetHeight(int x,y,z);
		void DrawTerrainT(int LOD,int x,int y,int DTNumber,int patch,int scale);
		void Sphere(int,int);
		unsigned int sphereDL;

		friend class Azadi;
	private:
		Frustum *frustum;
		cTerrainDT TTile[103];

};

#endif
