#include "Input.h"
#include "../GUI/Console.h"

bool Input::isKeyDepressed(int no)
{
    return keys[no];
}

int Input::getTimesPressed(int no)
{
    return keysp[no];
}

bool Input::getKeyPress(int no)
{
    if (!keysp[no])
        return false;

    keysp[no]--;
    return true;
}

bool Input::getMouseClick(int no)
{
    if (!mousep[no])
    	return false;

    mousep[no]--;
    return true;
}

bool Input::isMouseButtonDepressed(int no)
{
    return mouse[no];
}

int Input::removeKeyPress(int no)
{
    return --keysp[no];
}

bool Input::isQuit()
{
    return quit;
}

Input::Input()
:layouts(1),override_layouts(1)
{
    mode=true; // KeyMode at start
    active_layout=0;
    flush();
    quit=false;
}


bool Input::registerKeyListener(std::string cmdName,unsigned short defkey,eventListener *caller,unsigned short mod,unsigned char layout,bool registerATconsole) // Use this to register Functions to keys
{
    if(layout >= layouts.size()) // Invalid Layout
        return false;

    listeners[cmdName] = caller;
    layouts[layout][defkey][mod] = cmdName;

   // if(registerATconsole)
   //     console.registerObject(*((ConsoleListener*)caller),cmdName);

    return true;
}


bool Input::registerOverrideKeyListener(std::string cmdName,unsigned short defkey,eventListener *caller,unsigned short mod,unsigned char layout,bool registerATconsole) // Use this to register Functions to keys
{
    if(layout >= override_layouts.size()) // Invalid Layout
        return false;

    if(layout >= layouts.size()) // Invalid Layout
        return false;

    listeners[cmdName] = caller;
    override_layouts[layout][defkey][mod] = cmdName;
    layouts[layout][defkey][mod] = cmdName;
    return true;
}

void Input::KeyMode()
{
    mode=true;
}




void Input::TextMode(eventListener* tl)
{
    textListener = tl;
    mode=false;
}

bool Input::getKeyMode()
{
    return mode;
}



bool Input::setLayout(unsigned char ly)
{
    if(ly < layouts.size())
        active_layout = ly;
    else
        return false;
    return true;
}


unsigned char Input::addLayout()
{
    layouts.resize(layouts.size()+1);
    return layouts.size()-1;
}




void Input::get()
{

    SDL_Event event;

    while (SDL_PollEvent(&event))
    {

        if ( event.type == SDL_QUIT )  { quit = true; }

        if ( event.type == SDL_KEYDOWN )
        {
            keys[event.key.keysym.sym] = 1;
            keysp[event.key.keysym.sym]++;

            if(mode)
            {
                for(std::map<unsigned short,std::map<unsigned short,std::string> >::iterator key_iterator=layouts[active_layout].begin(); key_iterator != layouts[active_layout].end();key_iterator++)
                    for(std::map<unsigned short,std::string>::iterator mod_iterator=key_iterator->second.begin(); mod_iterator != key_iterator->second.end(); mod_iterator++)
                        if(key_iterator->first==event.key.keysym.unicode && mod_iterator->first ==event.key.keysym.mod)
                            listeners[mod_iterator->second]->cmdTriggered(mod_iterator->second);
            }else
            {
                bool key=false;
                for(std::map<unsigned short,std::map<unsigned short,std::string> >::iterator key_iterator=override_layouts[active_layout].begin(); key_iterator != override_layouts[active_layout].end();key_iterator++)
                    for(std::map<unsigned short,std::string>::iterator mod_iterator=key_iterator->second.begin(); mod_iterator != key_iterator->second.end(); mod_iterator++)
                        if(key_iterator->first==event.key.keysym.unicode && mod_iterator->first ==event.key.keysym.mod)
                        {
                            listeners[mod_iterator->second]->cmdTriggered(mod_iterator->second);
                            key=true;
                        }

                if((SDLK_BACKSPACE <= event.key.keysym.unicode && SDLK_DELETE >= event.key.keysym.unicode
                && SDLK_ESCAPE != event.key.keysym.unicode && event.key.keysym.unicode != SDLK_PAUSE
                || SDLK_KP_PERIOD >= event.key.keysym.unicode && SDLK_LEFT <= event.key.keysym.unicode) && !key)
                    textListener->charEntered(event.key.keysym.unicode);
            }

        }

        if ( event.type == SDL_KEYUP )
        {
            keys[event.key.keysym.sym] = 0;

            if(mode)
                for(std::map<unsigned short,std::map<unsigned short,std::string> >::iterator key_iterator=layouts[active_layout].begin(); key_iterator != layouts[active_layout].end();key_iterator++)
                    for(std::map<unsigned short,std::string>::iterator mod_iterator=key_iterator->second.begin(); mod_iterator != key_iterator->second.end(); mod_iterator++)
                        if(key_iterator->first==event.key.keysym.sym && mod_iterator->first ==event.key.keysym.mod)
                            listeners[mod_iterator->second]->cmdReleased(mod_iterator->second);
        }

        if (event.type ==  SDL_MOUSEMOTION)
        {
            mouseX = event.motion.x;
            mouseY = event.motion.y;
        }

        if (event.type ==  SDL_MOUSEBUTTONDOWN ) {
            mousep[event.button.button]++;
            mouse[event.button.button] = 1;
        }

        if (event.type ==  SDL_MOUSEBUTTONUP ) {
            mouse[event.button.button] = 0;
        }




    }

}

int Input::getMouseX()
{
    return mouseX;
}

int Input::getMouseY()
{
    return mouseY;
}

void Input::removeDepressed(int i)
{
    keys[i] = 0;
    return;
}

void Input::flush()
{
    for (int i=0; i<512; i++)
    	keys[i] = 0;
    for (int i=0; i<512; i++)
    	keysp[i] = 0;
    for (int i=0; i<8; i++)
    	mouse[i] = 0;
    for (int i=0; i<8; i++)
    	mousep[i] = 0;
}
