#ifndef INPUT_H
#define INPUT_H

#include <SDL/SDL.h>
#include <map>
#include <string>
#include <vector>



class Input;

/*! \brief Baseclass for eventListeners

    Inherit this class and register an instance of the inherited class using the
    registerKeyListener or registerOverrideKeyListener functions of the Input class
 */
class eventListener
{
    friend class Input;
    protected:
        virtual void cmdTriggered(std::string cmd) { };
        virtual void cmdReleased(std::string cmd) { };

        virtual void charEntered(unsigned short int ch) { };
        virtual void charReleased(unsigned short int ch) { };

};



/*! \brief Provides an usefule layoutbased interface for user-input

    Register your eventListener classes and they will be called.
    You can switch between the layouts, eg. you can create a layout for
    moving the wasd way and you can create a layout for the arrow-keys.
 */
class Input
{
	private:
		bool keys[512];
		unsigned char keysp[512];
		bool quit;
		int mouseX;
		int mouseY;
		bool mouse[8];
		int mousep[8];


		bool mode; //! True = KeyMode / False = String Mode
		unsigned char active_layout; //! The active layout

        eventListener * textListener;
        std::map<std::string,eventListener *> listeners;

    //!  Vector Contains Layouts
    //!     |          Map Contains Keys
    //!     |                |                 Map Contains Key-Modifers(like shift,alt,ctrl)
    //!     V                V                       V                 And here we save the corresponding cmd name
	std::vector< std::map<unsigned short,std::map<unsigned short,std::string> > > layouts;
        std::vector< std::map<unsigned short,std::map<unsigned short,std::string> > > override_layouts; /* the same for override-key combinations
                                                                                                    which only differ that they still work in
                                                                                                         text mode */
	public:
        //! Proccesses all the events
		void get();

		Input();

        /*! \brief Use this to register your eventListener

            \param cmdName: The Name of the command you want to register
            \param defkey: the default Key for this command. This key can be overriden if e.g. the configuration is beeing read from a file
            \param caller: Pointer to an inherited eventListener instace
            \param mod: The Keymodiefer. you can pass OR'ed values of KMOD_NONE, KMOD_NUM, KMOD_CAPS, KMOD_LCTRL, KMOD_RCTRL, KMOD_RSHIFT, KMOD_LSHIFT, KMOD_RALT, KMOD_LALT, KMOD_CTRL, KMOD_SHIFT, KMOD_ALT. Example: KMOD_LSHIFT|KMOD_LALT . These are the same values as you can read in the SDL documentation
            \param layout: The Layoutnumber in which you want to register the command. You can register the same command several times in several layouts and also on several keys in the same layouts. The default layout is 0
            \param registerATconsole: Wether the Input class should register this cmd also in the console. This is not supported yet.

            The classes/functions registered with this function will not be called in text mode if you don't register them also using registerOverrideKeyListener.
         */
        bool registerKeyListener(std::string cmdName,unsigned short defkey,eventListener *caller,unsigned short mod=KMOD_NONE,unsigned char layout=0,bool registerATconsole=false); // Use this to register Functions to keys
        /*! \brief Use this to register eventListener that should override the textmode

            \param cmdName: The Name of the command you want to register
            \param defkey: the default Key for this command. This key can be overriden if e.g. the configuration is beeing read from a file
            \param caller: Pointer to an inherited eventListener instace
            \param mod: The Keymodiefer. you can pass OR'ed values of KMOD_NONE, KMOD_NUM, KMOD_CAPS, KMOD_LCTRL, KMOD_RCTRL, KMOD_RSHIFT, KMOD_LSHIFT, KMOD_RALT, KMOD_LALT, KMOD_CTRL, KMOD_SHIFT, KMOD_ALT. Example: KMOD_LSHIFT|KMOD_LALT . These are the same values as you can read in the SDL documentation
            \param layout: The Layoutnumber in which you want to register the command. You can register the same command several times in several layouts and also on several keys in the same layouts. The default layout is 0
            \param registerATconsole: Wether the Input class should register this cmd also in the console. This is not supported yet.

            The classes/functions registered with this function will be called in text mode, but not in Keymode if you don't register them also using registerKeyListener.
         */
        bool registerOverrideKeyListener(std::string cmdName,unsigned short defkey,eventListener *caller,unsigned short mod=KMOD_NONE,unsigned char layout=0,bool registerATconsole=false); // Use this to register Functions to keys

        /*! \brief Set the active Layout
            \param Takes the Layoutnumber as parameter
            \return Returns if it was successful or not
         */
        bool setLayout(unsigned char);
        /*! \brief get the active Layout
            \return The number of the acctive layout
         */
        unsigned char getLayout();
        /*! \brief Adds a new layout
            \return Returns the new layouts number
         */
        unsigned char addLayout();
        /*! \brief Returns if KeyMode is active
         */
        bool getKeyMode(); // Are we in Key or in Text mode?
        /*! \brief Activate Keymode. In this Mode all cmds registerd with registerKeyListener work
         */
        void KeyMode(); // turn Keymode on.

        /*! \brief Activates Textmode
            \param tl: The eventListener that gets the chars

            Disables all registerKeyListener Functions and enables all registerOverrideKeyListener of the current layout.
            Will send all non-command-keys as char to the charEntered function of eventListener,
            including ENTER,RETURN,BACKSPACE,DELETE and the ARROW keys
         */
        void TextMode(eventListener* tl);


        // just there to prevent breaking old code
		bool isKeyDepressed(int no);
		bool isMouseButtonDepressed(int no);
		int getTimesPressed(int no);
		int removeKeyPress(int no);
		void removeDepressed(int no);
		bool getKeyPress(int no);
		bool getMouseClick(int no);
		int getMouseX();
		int getMouseY();
		bool isQuit();
		void flush();
};

#endif
