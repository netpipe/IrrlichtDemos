#ifndef MODEL_H_INCLUDED
#define MODEL_H_INCLUDED

#include "ModelFactory.h"

/*! \brief Model class
 */
class ModelFactory::Model
{
    public:
        class Action;
        /*! \brief Constructor
            \param md: a pointer to the Models data ( vertices,textures,faces,bones)
         */
        Model(mdata * md);
        //! Draw it..
        void Draw();
        //! Update the animations(actions) of the model
        void Update();
        //! Map of actions
        std::map<const char*,Action> actions;

        void reset(); //! Reset all actions

        //! Sets the Location in 3D Space
        void setLoc(float x,float y,float z);
        //! Sets the Rotation in 3D Space
        void setRot(float w,float x,float y,float z);
        float * getLoc();
        float * getRot();

        //! Is this Model enabled
        bool enabled;
        bool drawSkeleton;  //! Draw the skelet or not
        bool drawMeshes;    //! Draw the meshes or not

    private:
        float loc[3]; // Location of the model
        float rot[4]; // Rotation ..
        workingFrame position;
        ModelFactory::mdata * ModelData;
};

#endif // MODEL_H_INCLUDED
