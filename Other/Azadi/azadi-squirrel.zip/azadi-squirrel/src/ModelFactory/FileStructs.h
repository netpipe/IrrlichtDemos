#ifndef __FILESTRUCT
#define __FILESTRUCT

#include <map>

struct fileAction
{
    unsigned int frameNum;  // Length of the uint array which contains the indexes of the frames
    unsigned int name;
};



struct workingAction
{
    unsigned int numFrames;
    unsigned int * frames;
    unsigned int frame;
    bool play;
    char * name;
};




struct fileFrame
{
    unsigned int nr;
    unsigned int numBonePositions; // Length of the uint array which contains the bone-positions
};


struct fileBonePos
{
    unsigned int boneID;
    float loc[3];
    float rot[4];
};



union workingBonePos
{
    float loc[3];
    float rot[4];
    workingBonePos()
    {
        loc[0]=loc[1]=loc[2]=rot[0]=rot[1]=rot[2]=rot[3]=0.0;
    };
};




struct workingFrame
{
    unsigned int nr;
    std::map<unsigned int,workingBonePos> positions;
};



//! Struct of a Bone
struct fileBone
{
    float qRotate[4]; // Quaternion
    float vOffset[3]; // Vector
    float fLength; // of the Bone..
    int nJointType;
    int children[8];
    int Parent;
    float weight;
    char options;   // 0=CONNECTED 1=HINGE 2=CONNECTED+HINGE
    unsigned int nameL; // amount of chars following this struct
};



//! Struct of the Bone we will actually work with
struct workingBone
{
    float qRotate[4]; // Quaternion
    float vOffset[3]; // Vector
    float fLength; // of the Bone..
    int nJointType;
    int children[8];
    int Parent;
    float weight;
    char options;   // 0=CONNECTED 1=HINGE 2=CONNECTED+HINGE
    char * name; //name
};



//! Vertex Struct
struct fileVertex
{
    float vPos[3]; // Vertex Position
};


//! Face Struct
struct fileFace
{
    unsigned int normal;
    unsigned int numVertices; // how long the array of vertices is which will follow this struct
    unsigned int texture;
};


struct fileVertex2D
{
    float vPos[2];
};


struct workingFace
{
    unsigned int normal;
    unsigned int * vertices;
    unsigned int numVertices;
    unsigned int texId;
    fileVertex2D * uvcoords;
};



//! The vertex Group header struct
struct fileVertexGroup
{
    unsigned int detailLevel;
    unsigned int boneID;
    unsigned int vertexL; // amount of ints following the name
};

struct workingVertexGroup
{
    unsigned int detailLevel;
    unsigned int boneID;
    unsigned int vertexL;
    unsigned int * vertices;
};



//! This is the File Header
struct fileHeader
{
    unsigned int version;
    unsigned int numBones;
    unsigned int numVertices;
    unsigned int numFaces;
    unsigned int numGroups;
    unsigned int numTextures;
    unsigned int numActions;
    unsigned int numFrames;
};


#endif
