#include "ModelFactory.h"
#include "Action.h"
#include "Mdata.h"
#include "../GUI/Console.h"
#include "../Texture/TextureFactory.h"



ModelFactory::Model::Model(mdata * md)
{
    loc[0]=loc[1]=loc[2]=rot[0]=rot[1]=rot[2]=rot[3] = 0;
    drawSkeleton=drawMeshes=enabled=true;

    ModelData=md;

    position.nr=0;

    reset();
    Update();
}

void ModelFactory::Model::reset()
{
    actions = ModelData->defaultactions;
}


void ModelFactory::Model::setLoc(float x,float y,float z)
{
    loc[0]=x;
    loc[1]=y;
    loc[2]=z;
}


void ModelFactory::Model::setRot(float w,float x,float y,float z)
{
    rot[0]=w;
    rot[1]=x;
    rot[2]=y;
    rot[3]=z;
}


float * ModelFactory::Model::getLoc()
{
    float *tmp = new float[3];
    memcpy(tmp,loc,3*sizeof(float));
    return tmp;
}

float * ModelFactory::Model::getRot()
{
    float *tmp = new float[4];
    memcpy(tmp,rot,4*sizeof(float));
    return tmp;
}



void ModelFactory::Model::Update()
{
//    for(std::map<unsigned int,workingBonePos>::iterator itposition.positions.

    // Update all Actions
    for( std::map<const char*,Model::Action>::iterator Iterator = actions.begin(); Iterator != actions.end(); Iterator++ )
        if(Iterator->second.play)
        {
            Iterator->second.update();

        }

}


void ModelFactory::Model::Draw()
{
    if(enabled)
    {
        if(drawSkeleton)
        {
            glColor3f(1.0,1.0,0.0);
            for(unsigned int i=0; i < ModelData->numBones;i++)
            {
                glPushMatrix(); // Save the Matrix

                glTranslatef(ModelData->bones[i].vOffset[0],ModelData->bones[i].vOffset[1],ModelData->bones[i].vOffset[2]);
                glRotatef(ModelData->bones[i].qRotate[0],ModelData->bones[i].qRotate[1],ModelData->bones[i].qRotate[2],ModelData->bones[i].qRotate[3]);

                glBegin(GL_LINES);
                    glVertex3f(0 ,0,0);
                    glVertex3f(0 ,ModelData->bones[i].fLength,0);
                glEnd();
               glPopMatrix();
            }
        }

        if(drawMeshes)
        {
	    glColor3f(1.0, 1.0, 1.0);
            for (unsigned int i=0; i < ModelData->numFaces;i++)
            {
                glPushMatrix(); // Save the Matrix
                    glTranslatef(loc[0],loc[1],loc[2]);
                    glRotatef(rot[0],rot[1],rot[2],rot[3]);

                    if(ModelData->numTextures > 0)
                        texture_factory.applyTexture(ModelData->texID[ModelData->faces[i].texId]);


                    glBegin(GL_POLYGON);
                        if( ModelData->faces[i].normal < ModelData->numVerts)
                            glNormal3fv(ModelData->vertices[ModelData->faces[i].normal].vPos);

                        for(unsigned int vi=0; vi < ModelData->faces[i].numVertices;vi++)
                            if( ModelData->faces[i].vertices[vi] < ModelData->numVerts)
                            {
                                if(ModelData->numTextures > 0)
                                    glTexCoord2fv(ModelData->faces[i].uvcoords[vi].vPos);
                                glVertex3fv(ModelData->vertices[ModelData->faces[i].vertices[vi]].vPos);
                            }
                            else
                                console << GUI::Console::warning << GUI::Console::lowish << "Modeldrawer: Vertex " << vi << " out of Range(" << ModelData->numVerts << ")" << GUI::Console::endl();


                    glEnd();



                glPopMatrix();
            }

        }
    }
}
