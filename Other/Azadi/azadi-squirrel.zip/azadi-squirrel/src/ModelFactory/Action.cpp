#include "Action.h"


ModelFactory::Model::Action::Action(unsigned int nbones)
:frames(0)
{
    play= false;
    frame_position=last_update=0;
    speed = 1.0;
    numBones = nbones;
/*
    tmpframe.numBonePositions = nbones;
    tmpframe.nr=0;
    tmpframe.positions = new fileBonePos[tmpframe.numBonePositions];

    for(unsigned int i=0;i<tmpframe.numBonePositions;i++)
    {
        tmpframe.positions[i].boneID=i;
        tmpframe.positions[i].loc[0]=tmpframe.positions[i].loc[1]=tmpframe.positions[i].loc[2]=
        tmpframe.positions[i].rot[0]=tmpframe.positions[i].rot[1]=tmpframe.positions[i].rot[2]=tmpframe.positions[i].rot[3]=0;
    }
*/

}


void ModelFactory::Model::Action::setFrame(unsigned int frm)
{
    frame_position = frm;
}


float ModelFactory::Model::Action::getFramePosition()
{
    return frame_position;
}


void ModelFactory::Model::Action::addKeyFrame(workingFrame frm)
{
    workingFrame * tmp = new workingFrame;
    memcpy(tmp,&frm,sizeof(workingFrame));

    if(flexible)
    {
        frames.clear();
        frames.push_back(&tmpframe);   // First frame is actuall frame
        frame_position=speed; // Actuall frame is next frame;
    }
    frames.push_back(tmp);
}



void ModelFactory::Model::Action::update()
{
    if(SDL_GetTicks() - last_update < intervall || // Its not time yet to update positions
    !play || frame_position >=frames[frames.size()-1]->nr // we are not playing or we ended now
    || frames.size() < 2)  // we got no frames
        return;


    // get 2 Frames which surround the needed one
    // or see if the needed one self is a given keyframe
    unsigned int smaller,bigger = 0;

    bool self=false;
    for(unsigned int i=0; i < frames.size();i++)
    {
        if(frames[i]->nr == frame_position)
        {
            self = true;
            smaller = i;
            break;
        }
        if(frames[i]->nr < frame_position)
            smaller = i;

        if(frames[i]->nr > frame_position)
        {
            bigger = i;
            break;
        }
    }

    if(self)    // the ordered frame is a keyframe - no calcs needed
        position = frames[smaller];// just set the actuall pos to the frames position
    else // The ordered frame needs to be calculated using interpolation
    {
        position = &tmpframe;
        for(unsigned int o=0;o < numBones;o++)
        {
            for(unsigned int i=0;i<3;i++) // Interpolation of X Y Z Coordinates
            {
                position->positions[o].loc[i] =

                    frames[smaller]->positions[o].loc[i]
                                        +
               ( (frames[bigger]->positions[o].loc[i] - frames[smaller]->positions[o].loc[i]) /
                            ((float)frames[bigger]->nr - (float)frames[smaller]->nr))
                                        *
                            (frame_position - (float)frames[smaller]->nr);
            }
              /*
                linear_interpolation(
                                    frames[smaller].nr,frames[smaller].positions[sm_pos].loc[i], // Frame and Value 0
                                    frames[bigger].nr ,frames[bigger].positions[bg_pos].loc[i], // Frame and Value 1
                                    frame_position);  // Needed Frame */

            for(unsigned int i=0;i<4;i++) // Interpolation of Rotation
            {
                position->positions[o].rot[i] =

                    frames[smaller]->positions[o].rot[i]
                                        +
               ( (frames[bigger]->positions[o].rot[i] - frames[smaller]->positions[o].rot[i]) /
                            ((float)frames[bigger]->nr - (float)frames[smaller]->nr))
                                         *
                            (frame_position - (float)frames[smaller]->nr);
            }
            /*
                position->positions[o].rot[i] =  linear_interpolation(
                                    frames[smaller].nr,frames[smaller].positions[sm_pos].rot[i], // Frame and Value 0
                                    frames[bigger].nr ,frames[bigger].positions[bg_pos].rot[i], // Frame and Value 1
                                    frame_position);  // Needed Frame */
        }
       // frames[smaller].
    }

    last_update = SDL_GetTicks();
    frame_position+=speed;
    if(frames[frames.size()-1]->nr >= frame_position && loop) // Reached the end? If loop, restart
        frame_position -= (float)frames[frames.size()-1]->nr;

}

/*
float Model::Action::linear_interpolation (float frame0,float value0,float frame1,float value1,float frame)
{
    return value0 + ((value1 - value0) / (frame1 - frame0)) * (frame - frame0);
}
*/
