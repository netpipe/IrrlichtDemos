#ifndef ACTION_H_INCLUDED
#define ACTION_H_INCLUDED

#include <string>
#include <vector>

#include "FileStructs.h"
#include "Model.h"


/*! \brief Action interface and handler

 */
class ModelFactory::Model::Action
{
    friend class Model;
    public:

        Action(unsigned int nbones);

        /*! \brief Set the active Frame
            \param Takes the Framenumber as parameter
         */
        void setFrame(unsigned int frm);
        /*! \brief Get the active Layout
            \return Returns if it was successful or not
         */
        float getFramePosition();
        /*! \brief Adds a KeyFrame to the Animation
         */
        void addKeyFrame(workingFrame frm);
        /*! \brief Reports the status of the Animation
            \return If the Animation is completed or not
         */
        bool Status(); // Completed?


        /*! \brief Speed of the Animation. Default is 1.0

            Frames per intervall
         */
        float speed; // How much frames per intervall ?

        //! How often to update the positions
        unsigned int intervall; // Intervall of Position Update
        //! Loop the animation or not
        bool loop;
        //! Play it or not
        bool play;
        /*! \brief Turns flexible Mode on

            In flexible Mode, only 2 Frames exist and the animation will try to reach
            the last added keyframe on the direct way without proccessing the other frames.which get deleted
            you can use the reset function of the Model class to restore all actions
        */
        bool flexible; /* If true, then addKeyframe will always be the only keyframe
                          that the action will try to reach, without using the others  */
    private:
        void update();
        //float linear_interpolation(float frame0,float value0,float frame1,float value1,float frame);

        std::vector<workingFrame*> frames; // All the animations frames
        workingFrame * position;    // The actuall frame
        workingFrame tmpframe;      // Tmp Frame

        float frame_position;

        unsigned int last_update; // Last time we updated
        unsigned int numBones;




};





#endif // ACTION_H_INCLUDED
