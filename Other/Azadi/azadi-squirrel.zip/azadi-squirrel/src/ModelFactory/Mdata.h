#ifndef MDATA_H_INCLUDED
#define MDATA_H_INCLUDED

#include "Model.h"


struct ModelFactory::mdata
{
    workingBone * bones;  //! Array of bones
    fileVertex * vertices;
    workingFace * faces;
    workingVertexGroup * vGroups;
    std::string * texName; // avoid name collision
    unsigned int * texID;
    unsigned int numVGroups;
    unsigned int numBones;
    unsigned int numVerts;
    unsigned int numFaces;
    unsigned int numTextures;
    std::map<const char*,Model::Action> defaultactions;
};

#endif // MDATA_H_INCLUDED
