#include "ModelFactory.h"
#include "Action.h"
#include "../Texture/TextureFactory.h"
#include "Mdata.h"
#include "../FileSystem/FileSystem.h"

using GUI::Console;


ModelFactory::ModelFactory()
{
    models.clear();
    console.registerObject(*this,"modelfactory");
}

/*! \brief Loads Model Data
    \return Returns Model ID or -1 on error
 */
int ModelFactory::LoadModel(char * filename)
{
    // Is this Model already loaded?
    if(ModelData.find(filename) != ModelData.end())
    { // Yes? Then we only need to create a new Model instance
         models.push_back(Model(ModelData[filename]));
         return models.size()-1;
    }


    // Inputfile Object
    fileSystem file;
    file.open(filename,BIN | IN);

    if(!file)
    {
        //valid=false;
        console << Console::warning << Console::lowish << "ModelLoader: Invalid file \"" << filename << "\"" << Console::endl();
        return -1;
    }


    // Create File Header Object
    fileHeader header;

    // Read Header from file
    file.read( (char*)&header, sizeof(fileHeader));


    // Check for correct file version.
    if(header.version != 4)
    {
        //valid=false;
        console << Console::warning << "ModelLoader: Invalid/wrong header version(" << header.version << ") in file \"" << filename << "\"" << Console::endl();
        return -1;
    }


    ModelData[filename] = new mdata;


    ModelData[filename]->numBones= header.numBones;

    // Create an array for the bones
    if(header.numBones > 0)
    {
        try
        {
            ModelData[filename]->bones = new workingBone[header.numBones];
        }
        catch (const std::bad_alloc& )
        {
            console << Console::warning << "ModelLoader: Was not able to allocate " << header.numBones << "bone-instances." << Console::endl();
            //valid=false;
            return -1;
        }


        fileBone *tmpbone = new fileBone;

        // Read all bones
        for(unsigned int i=0;i < header.numBones;i++)
        {
            // Read fileBone struct
            file.read((char*)tmpbone, sizeof(fileBone));
            // Put information in workingBone struct
            memcpy(ModelData[filename]->bones[i].children,tmpbone->children,8*sizeof(int));
            ModelData[filename]->bones[i].fLength    = tmpbone->fLength;
            ModelData[filename]->bones[i].nJointType = tmpbone->nJointType;
            ModelData[filename]->bones[i].options    = tmpbone->options;
            ModelData[filename]->bones[i].Parent     = tmpbone->Parent;

            memcpy(ModelData[filename]->bones[i].qRotate,tmpbone->qRotate,4*sizeof(float));
            memcpy(ModelData[filename]->bones[i].vOffset,tmpbone->vOffset,3*sizeof(float));
            ModelData[filename]->bones[i].weight     = tmpbone->weight;

       /*     printf("  nameL = %u\n",tmpbone->nameL);
            printf("  fLength = %f\n",tmpbone->fLength);
            printf("  nJointType = %i\n",tmpbone->nJointType);
            printf("  options = %i\n",tmpbone->options);
            printf("  Parent = %i\n",tmpbone->Parent); */

            ModelData[filename]->bones[i].name       = new char[tmpbone->nameL];
            // now read the name
            file.read(ModelData[filename]->bones[i].name,tmpbone->nameL);

    /*        printf("Name: %s\nqRotate: %f %f %f %f\nvOffset: %f %f %f\n",bones[i].name, bones[i].qRotate[0],
                                                                                        bones[i].qRotate[1],
                                                                                        bones[i].qRotate[2],
                                                                                        bones[i].qRotate[3],
                                                                                        bones[i].vOffset[0],
                                                                                        bones[i].vOffset[1],
                                                                                        bones[i].vOffset[2]);*/

        }
        delete tmpbone;
    }


    // Read the Vertices
    ModelData[filename]->numVerts = header.numVertices;
    if(header.numVertices > 0)
    {
        try
        {
            ModelData[filename]->vertices = new fileVertex[header.numVertices];
        }
        catch (const std::bad_alloc& )
        {
            console << Console::warning << "ModelLoader: Was not able to allocate " << header.numVertices << " Vertex-instances." << Console::endl();
            //valid=false;
            return -1;
        }

        for (unsigned int i =0; i < ModelData[filename]->numVerts;i++)
        {
            file.read((char*) ModelData[filename]->vertices+sizeof(fileVertex)*i,sizeof(fileVertex));
            //printf("(%u) : %f %f %f\n",i,vertices[i].vPos[0],vertices[i].vPos[1],vertices[i].vPos[2]);
        }

    }


    // Read the Faces
    ModelData[filename]->numFaces = header.numFaces;
    if(header.numFaces > 0)
    {
        try
        {
            ModelData[filename]->faces = new workingFace[header.numFaces];
        }
        catch (const std::bad_alloc& )
        {
            console << Console::warning << "ModelLoader: Was not able to allocate " << header.numFaces << " face-instances." << Console::endl();
            //valid=false;
            return -1;
        }


        fileFace* tmpface = new fileFace;

        for( unsigned int i=0; i < ModelData[filename]->numFaces;i++)
        {
            file.read((char*) tmpface,sizeof(fileFace));
            ModelData[filename]->faces[i].normal = tmpface->normal;
            ModelData[filename]->faces[i].numVertices = tmpface->numVertices;
            ModelData[filename]->faces[i].texId = tmpface->texture;

            // Init place for vertices
            try
            {
                ModelData[filename]->faces[i].vertices = new unsigned int[tmpface->numVertices];
            }
            catch (const std::bad_alloc& )
            {
                console << Console::warning << "ModelLoader: Was not able to allocate " << tmpface->numVertices << " face-vertices-array." << Console::endl();
                //valid=false;
                return -1;
            }
            // read the verts
            file.read((char*) ModelData[filename]->faces[i].vertices,tmpface->numVertices*sizeof(unsigned int));


          //  printf("Verts: %u %u %u %u\n",faces[i].vertices[0],faces[i].vertices[1],faces[i].vertices[2],faces[i].vertices[3]);

            // now we read the UV Coordinates
            try
            {
                ModelData[filename]->faces[i].uvcoords = new fileVertex2D[tmpface->numVertices];
            }
            catch (const std::bad_alloc& )
            {
                console << Console::warning << "ModelLoader: Was not able to allocate " << tmpface->numVertices << " face-uvcoords-array." << Console::endl();
                //valid=false;
                delete tmpface;
                return -1;
            }
            file.read((char*) ModelData[filename]->faces[i].uvcoords,sizeof(fileVertex2D)*tmpface->numVertices);


         //   for(unsigned int j=0;j<tmpface->numVertices;j++)
        //        printf("UV: %f | %f\n",ModelData[filename]->faces[i].uvcoords[j].vPos[0],ModelData[filename]->faces[i].uvcoords[j].vPos[1]);


            // Search double vertices for debugging
            for(unsigned int ii=0;ii < tmpface->numVertices;ii++)
                for(unsigned int o=0;o < tmpface->numVertices;o++)
                    if(ModelData[filename]->faces[i].vertices[ii] == ModelData[filename]->faces[i].vertices[o] && o != ii)
                    {
                        console << Console::warning << "ModelLoader: Broken Model! Found same vertices in face " << ModelData[filename]->faces[i].vertices[ii] << " in file " << filename << Console::endl();
                        return -1;
                        break;

                    }

        }

        delete tmpface;

    }


    // Read the VertexGroups
    ModelData[filename]->numVGroups = header.numGroups;
    if (header.numGroups > 0)
    {
        fileVertexGroup * tmpgroup = new fileVertexGroup;
        try
        {
            ModelData[filename]->vGroups = new workingVertexGroup[header.numGroups];
        }
        catch (const std::bad_alloc& )
        {
            console << Console::warning << "ModelLoader: Error: Was not able to allocate " << header.numGroups << " VertexGroup-instances." << Console::endl();
            //valid=false;
            return -1;
        }

        for(unsigned int i =0;i < header.numGroups; i++)
        {
            file.read((char*) tmpgroup, sizeof(fileVertexGroup));
            ModelData[filename]->vGroups[i].boneID = tmpgroup->boneID;
            ModelData[filename]->vGroups[i].detailLevel = tmpgroup->detailLevel;
            ModelData[filename]->vGroups[i].vertexL = tmpgroup->vertexL;

            try
            {
                ModelData[filename]->vGroups[i].vertices = new unsigned int[tmpgroup->vertexL];
            }
            catch (const std::bad_alloc& )
            {
                console << Console::warning << "ModelLoader: Error: Was not able to allocate " << tmpgroup->vertexL << "Group-vertices-arrays." << Console::endl();
                //valid=false;
                return false;
            }

            file.read((char*) ModelData[filename]->vGroups[i].vertices, sizeof(unsigned int)*tmpgroup->vertexL);


        }
        delete tmpgroup;
    }

    // Read the Textures
    ModelData[filename]->numTextures  = header.numTextures;
    ModelData[filename]->numTextures = header.numTextures;
    if( header.numTextures > 0)
    {
        try
        {
            ModelData[filename]->texName = new std::string[header.numTextures];
            ModelData[filename]->texID = new unsigned int[header.numTextures];
        }
        catch (const std::bad_alloc& )
        {
            console << Console::warning << "ModelLoader: Error: Was not able to allocate " << header.numTextures << " Texture-names." << Console::endl();
            //valid=false;
            return -1;
        }

        for(unsigned int i=0;i < header.numTextures;i++)
        {
            unsigned int length=0;
            file.read((char*) &length,sizeof(unsigned int));

            if(length <= 0)
                break;

            char * tmp;
            try
            {
                tmp = new char[length+1];
            }
            catch (const std::bad_alloc& )
            {
                console << Console::warning << "ModelLoader: Error: Was not able to allocate " << length+1 << " Texturename-memory for reading." << Console::endl();
                //valid=false;
                return -1;
            }

            file.read((char*) tmp, sizeof(char)*length);
            tmp[length]='\0';
            ModelData[filename]->texName[i] = tmp;
            int tmpid = texture_factory.loadTexture((std::string)tmp);
            if( tmpid == -1)
            {
                console << Console::warning << "ModelLoader: Could not load texture " << tmp << Console::endl();
                return -1;
            }

            ModelData[filename]->texID[i] = tmpid;

            //printf("Texture(%u): %s\n",i,tmp);
            delete tmp;
        }

    }


    // Read the Animation-Actions
    std::vector<workingAction> tmp_actions;
    if ( header.numActions > 0 )
    {
        workingAction tmpworkact;
        fileAction tmpaction;
        for(unsigned int i=0;i < header.numActions;i++)
        {
            file.read((char*)&tmpaction, sizeof(fileAction));
            try
            {
                tmpworkact.frames = new unsigned int[tmpaction.frameNum];
                tmpworkact.numFrames = tmpaction.frameNum;
                tmpworkact.frame = 0;
                tmpworkact.play = false;
            }
            catch (const std::bad_alloc& )
            {
                console << Console::warning << "ModelLoader: Error: Was not able to allocate " << tmpaction.frameNum << " Frame-indicies ." << Console::endl();
                //valid=false;
                return false;
            }
            file.read((char*)tmpworkact.frames,sizeof(unsigned int)*tmpaction.frameNum);

            tmpworkact.name = new char[tmpaction.name+1];
            file.read(tmpworkact.name,sizeof(char)*tmpaction.name);
            tmpworkact.name[tmpaction.name] = '\0';

            tmp_actions.push_back(tmpworkact);
            //printf("Read Action (%u): %s(%u), %u frames.\n",i,actions[i].name,tmpaction.name,tmpaction.frameNum);
           // for(unsigned int j=0;j<tmpaction.frameNum;j++)
              //  printf("  %u\n",actions[i].frames[j]);

        }
    }


    std::vector<workingFrame> frames;
    // Read the Animation-Frames
    if( header.numFrames > 0)
    {
        workingFrame tmpworkffrm;
        fileFrame tmpfrm;
        for(unsigned int i=0;i < header.numFrames;i++)
        {
            file.read((char*)&tmpfrm,sizeof(fileFrame));
            tmpworkffrm.nr = tmpfrm.nr;

//            tmpworkffrm.numBonePositions = tmpfrm.numBonePositions;
            fileBonePos *tmpbpos;
            try
            {
                tmpbpos = new fileBonePos[tmpfrm.numBonePositions];
            }
            catch (const std::bad_alloc& )
            {
                console << Console::warning << "ModelLoader: Was not able to allocate " << tmpfrm.numBonePositions << " BonePos Structs ." << Console::endl();
                //valid=false;
                return -1;
            }

            file.read((char*)tmpbpos,sizeof(fileBonePos)*tmpfrm.numBonePositions);

            for(unsigned int o=0;o < tmpfrm.numBonePositions;o++)
            {
                workingBonePos tmp;
                memcpy(tmp.loc,tmpbpos[o].loc,sizeof(float)*3);
                memcpy(tmp.rot,tmpbpos[o].rot,sizeof(float)*4);
                tmpworkffrm.positions.insert(std::make_pair(tmpbpos[o].boneID,tmp));
            }
            frames.push_back(tmpworkffrm);

        }
    }

    // Convert actions to the Action-Class
    for(unsigned int i=0;i < tmp_actions.size();i++)
    {
        Model::Action newAction(header.numBones);
        // Add the frames to the action
        for(unsigned int f=0;f < tmp_actions[i].numFrames;f++)
            if(tmp_actions[i].frames[f] < frames.size() )
                newAction.addKeyFrame(frames[tmp_actions[i].frames[f]]);

        ModelData[filename]->defaultactions.insert(std::make_pair(tmp_actions[i].name, newAction));
    }

    models.push_back(Model(ModelData[filename]));
    console << Console::normal << Console::lowish << "ModelLoader: Loaded " << filename << Console::endl();

    file.close();

    return models.size()-1;

}

//! is beeing called from Azadi to update Animations
void ModelFactory::Update()
{
    for(unsigned int i=0;i<models.size();i++)
        models[i].Update();
}

//! Draw all the stuff
void ModelFactory::Draw()
{
    //console << "models.size()" << models.size() << GUI::Console::endl();
    for(unsigned int i=0;i<models.size();i++)
        models[i].Draw();
}


std::string ModelFactory::acceptConsoleCommand(std::string cmd)
{
    std::vector<std::string> args = splitArgs(cmd);

    if(args[0] == "modelfactory")
    {
        console << "usage:" << GUI::Console::endl();
        console << "load example.azm" << GUI::Console::endl();
    }
    if(args[0] == "load")
    {
        if(args.size() > 1)
            LoadModel((char *) args[1].c_str());
        else
            console << "usage: load example.azm" << GUI::Console::endl();

    }

    return "?";
}






