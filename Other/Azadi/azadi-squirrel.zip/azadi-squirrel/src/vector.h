#ifndef VECTOR_H
#define VECTOR_H


#include "GUI/Console.h"
#include <math.h>
//#include "azadimath.h"
#ifndef __OSX__
	#include <GL/gl.h>
#else
	#include <OpenGL/gl.h>
#endif

#ifdef __VEC__
#include <altivec.h>

#define bool char
#define true 1
#define false 0
typedef union
{
	vector float vect;
	GLfloat V[3];
	float v[3];
}vec;
#endif

//! vector3f vector template class that contains vector functions such as normalize, dot product, cross product etc.
template<class T>
class vector3f
{
    public:
	#ifdef __VEC__
        vector3f(T x=0,T y=0,T z=0)
        {
	    this->X = &vect.V[0];
	    this->Y = &vect.V[1];
	    this->Z = &vect.V[2];
            (*this->X)=x;
            (*this->Y)=y;
            (*this->Z)=z;
        };
	#else
	vector3f(T x=0, T y =0, T z=0)
	{
		this->X = x;
		this->Y = y;
		this->Z = z;
	}
	#endif


        T length()
        {
	    #ifdef __VEC__
	    T t = sqrt(((*this->X)*(*this->X)) + ((*this->Y)*(*this->Y)) + ((*this->Z)*(*this->Z)));
	    #else
            T t = sqrt((this->X*this->X) + (this->Y*this->Y) + (this->Z*this->Z));
	    #endif
            return t;
        };


        void Normalize()
        {
            T l=length();
            if(l != 0)
            {
		#ifdef __VEC__
		(*this->X) /= l;
		(*this->Y) /= l;
		(*this->Z) /= l;
		#else
                this->X /= l;
                this->Y /= l;
                this->Z /= l;
		#endif
            }else
                console << GUI::Console::warning << "Vector length is 0 !" << GUI::Console::endl();
        };



        vector3f<T> operator*(T rhs)
        {
            vector3f<T> tmp(this->X,this->Y,this->Z);
            tmp.X *= rhs;
            tmp.Y *= rhs;
            tmp.Z *= rhs;
            return tmp;
        };


        //! crossproduct
        vector3f<T> crossproduct(vector3f<T> bb)
        {
            vector3f<T> cc;
	    #ifdef __VEC__
	    (*cc.X)= (*this->Y)*(*bb.Z) - (*this->Z)*(*bb.Y);
            (*cc.Y)= (*this->Z)*(*bb.X) - (*this->X)*(*bb.Z);
            (*cc.Z)= (*this->X)*(*bb.Y) - (*this->Y)*(*bb.X);
	    #else
            cc.X= this->Y*bb.Z - this->Z*bb.Y;
            cc.Y= this->Z*bb.X - this->X*bb.Z;
            cc.Z= this->X*bb.Y - this->Y*bb.X;
	    #endif
            return cc;
        };


        vector3f<T> normcrossprod(vector3f<T> bb)
        {
             vector3f<T> tmp = crossproduct(bb);
             tmp.Normalize();
             return tmp;
        };

        vector3f<T> operator-(vector3f<T> rhs)
        {
            vector3f<T> tmp(this->X,this->Y,this->Z);
            //tmp.print();
            //printf("Sub\n");
            //rhs.print();
            tmp.X-=rhs.X;
            tmp.Y-=rhs.Y;
            tmp.Z-=rhs.Z;
            return tmp;
        };

        vector3f<T> operator+(vector3f<T> rhs)
        {
            vector3f<T> tmp(this->X,this->Y,this->Z);
            //tmp.print();
            //printf("Add\n");
            //rhs.print();
            tmp.X+=rhs.X;
            tmp.Y+=rhs.Y;
            tmp.Z+=rhs.Z;
            return tmp;
        };

        //! Dotproduct
        T dotproduct(vector3f<T> rhs)
        {
           return (this->X*rhs->X + this->Y*rhs->Y + this->Z*rhs->Z);
        }

        void getArray(T *array[])
        {
            array=new T[3];
            *array[0]=X;
            *array[1]=Y;
            *array[2]=Z;
        }

        void print()
        {
            printf("%i: %f | %f | %f \n",this,X,Y,Z);
        }

	#ifdef __VEC__
		vec vect;

		T *X, *Y, *Z;
	#else
		T X,Y,Z;
	#endif

};


/*
void normalize(float v[3]) {
   GLfloat d = sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);
   if (d == 0.0) {
      printf("zero length vector",stderr);
      return;
   }
   v[0] /= d; v[1] /= d; v[2] /= d;
}

void normcrossprod(float v1[3], float v2[3], float out[3])
{
   GLint i, j;
   GLfloat length;

   out[0] = v1[1]*v2[2] - v1[2]*v2[1];
   out[1] = v1[2]*v2[0] - v1[0]*v2[2];
   out[2] = v1[0]*v2[1] - v1[1]*v2[0];
   normalize(out);
}
*/

#endif

