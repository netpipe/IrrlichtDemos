#include "Azadi.h"
#include "Terrain/Terrain.h"
#include "ModelFactory/ModelFactory.h"
#include "GUI/Drawing.h"
#include "frustum.h"

#include <SDL/SDL.h>

#ifndef __OSX__
	#include <GL/gl.h>
	#include <GL/glu.h>
#else
	#include <OpenGL/gl.h>
	#include <OpenGL/glu.h>
#endif

extern Input input;

Terrain TP;
GLdouble projection_matrix[16]={1, 0, 0, 0,
					      0, 1, 0, 0,
					      0, 0, 1, 0,
					      0, 0, 0, 1};

GLdouble modelview_matrix[16]={1, 0, 0, 0,
					       0, 1, 0, 0,
					       0, 0, 1, 0,
					       0, 0, 0, 1};
GLint viewport_matrix[4];

Azadi::Azadi(int argc, char** argv)
{

    Modeldata = new ModelFactory;
    screen[0]=1024,screen[1]=768;

    fullScreen = false;
    withAudio = true;

    parseParameters(argc,argv);

}

Azadi::~Azadi()
{
	if (soundDeviceWorking)
		alcCloseDevice(NULL);
}


void Azadi::parseParameters(int argc, char** argv)
{
	for (int i = 1; i< argc; i++)
	{
		if (strcmp(argv[i], "-fullscreen") == 0)
			fullScreen = true;
		else if (strcmp(argv[i], "-window") == 0)
			fullScreen = false;
		else if (strcmp(argv[i], "-nosound") == 0)
			withAudio = false;
		else if (strcmp(argv[i], "-withsound") == 0)
			withAudio = true;
	}
}



bool Azadi::Init()
{

    console << GUI::Console::medium << GUI::Console::normal << "Initialising Azadi Engine" << GUI::Console::endl();

    GLfloat fogColor[4]={0.0, 0.0, 0.0, 1.0};

    if ( SDL_Init( SDL_INIT_VIDEO ) < 0 )
    {
        printf( "Unable to init SDL: %s\n", SDL_GetError() );
        return false;
    }

    atexit(SDL_Quit);

    SDL_WM_SetCaption("Azadi", "azadi.bmp");
    SDL_EnableUNICODE(1);
    SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL);
    //SDL_SetModState(KMOD_NUM,false);
    SDL_ShowCursor(SDL_DISABLE);



    SDL_GL_SetAttribute( SDL_GL_RED_SIZE, 5 );
    SDL_GL_SetAttribute( SDL_GL_GREEN_SIZE, 5 );
    SDL_GL_SetAttribute( SDL_GL_BLUE_SIZE, 5 );
    SDL_GL_SetAttribute( SDL_GL_DEPTH_SIZE, 16 );
    SDL_GL_SetAttribute( SDL_GL_DOUBLEBUFFER, 1 );


    center[0]=screen[0]/2;
    center[1]=screen[1]/2;

    CamPos[0]=0.0f;
    CamPos[1]=0.0f;
    CamPos[2]=0.0f;

    MoveKey[0]=false;
    MoveKey[1]=false;
    MoveKey[2]=false;
    MoveKey[3]=false;


    input.registerKeyListener("forward",SDLK_w,this);
    input.registerKeyListener("backward",SDLK_s,this);
    input.registerKeyListener("left",SDLK_a,this);
    input.registerKeyListener("right",SDLK_d,this);
    input.registerKeyListener("quit",SDLK_ESCAPE,this,KMOD_NONE,0,true);
    input.registerKeyListener("exit",SDLK_ESCAPE,this,KMOD_NONE,0,true);
    input.registerKeyListener("select",SDLK_SPACE,this);
    input.registerOverrideKeyListener("exit",SDLK_ESCAPE,this);

/*
Just for testing layout functionality
    input.addLayout();

    input.registerKeyListener("forward",SDLK_UP,&Mkeys,KMOD_NONE,1);
    input.registerKeyListener("backward",SDLK_DOWN,&Mkeys,KMOD_NONE,1);
    input.registerKeyListener("left",SDLK_LEFT,&Mkeys,KMOD_NONE,1);
    input.registerKeyListener("right",SDLK_RIGHT,&Mkeys,KMOD_NONE,1);
    input.registerKeyListener("quit",SDLK_ESCAPE,&Mkeys,KMOD_NONE,1);

    input.setLayout(1);
*/


    console << GUI::Console::medium << GUI::Console::normal << "Initialising Screen" << GUI::Console::endl();
    // create a new window
    if (!fullScreen)
    	window = SDL_SetVideoMode(screen[0], screen[1], 32,
                                           SDL_OPENGL);
    else
	window = SDL_SetVideoMode(screen[0], screen[1], 32,
					   SDL_OPENGL | SDL_FULLSCREEN);

    if ( !window )
    {
        printf("Unable to set %ix%i video: %s\n",screen[0],screen[1], SDL_GetError());
        return false;
    }

    // Nice Colorflow
    glShadeModel(GL_SMOOTH);

    glEnable(GL_DEPTH_TEST);
    // Enable texturing
    glEnable(GL_TEXTURE_2D);

    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // Enable GL FOG, lets us increase the speed of the rendering by having gl not render beyond a certain distance
    // It also eliminates the visible clipping that can be seen when we go further than what our gluPerspective can give us
    console << GUI::Console::lowish << GUI::Console::highish << "Initialising Fog" << GUI::Console::endl();

    glEnable(GL_FOG);

    glFogf(GL_FOG_MODE, GL_EXP2);
    glFogfv(GL_FOG_COLOR, fogColor);
    glFogf(GL_FOG_DENSITY, 0.005);
    glHint(GL_FOG_HINT, GL_FASTEST);
    glFogf(GL_FOG_START, 20.0);
    glFogf(GL_FOG_END, 500.0);


//------------------------------------------------------------ Culling


    Azadi :: CamPos[1]=-20;	//camera initialise value

    glViewport (0, 0, (GLsizei) screen[0], (GLsizei) screen[1]);

	drawing = new Drawing();
	console.initTextures();


	int tempo, tempy;

    if (!(withAudio) || !(soundDevice = alcOpenDevice(NULL)))
    {
	soundDeviceWorking = false;
	sound_factory.soundNotWorking();
    }
    else
    {
	soundDeviceWorking = true;
	soundContext = alcCreateContext(soundDevice, NULL);
    	alcMakeContextCurrent(soundContext);
    }

    texture_factory.loadTexture("test.png");	// Fixed it so that it loads the texture here, within the instance, rather than in Azadi::Azadi which is the constructor

/*=========================================================

	Sound factory example.

	Loads test.ogg from the ./data/sound/  directory
	Attaches it to a new source
	sets the source's attenuation to 0.0 (turns it off)
	sets the source's volume to 1.0 (Clamped to this value)
	starts playing the source


	to move a sound/source's position;
	sound_factory.moveSound(sourceID, vector<GLfloat> newPosition);

	to stop playing a source;
	sound_factory.stopSource(sourceID);
*/

    tempo = sound_factory.loadSound("test.ogg");
    sound_factory.newSource();
    tempy = sound_factory.attachSound(tempo);
    sound_factory.setSourceAtten(tempy, 0.0);
    sound_factory.setSourceVol(tempy, 1.0);
    sound_factory.setSourceLoop(tempy, true);
    sound_factory.playSource(tempy);

//=========================================================

	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
    vector3f<GLfloat> pos(-5.0, 1.0, 2.0);
    vector3f<GLfloat> dir(-5.0, 2.0, 2.0);
    vector3f<GLfloat> col(1.0, 0.0, 0.0);

    testPart = new ParticleFactory();
    testPart->init(pos, dir, col, 1.0, 45.0, 500, 20, 500,  10.0);  // Testing!

    return true;
}



int Azadi::Run()
{

    if(!Init()) {
        console << GUI::Console::error << GUI::Console::high << "Azadi engine initialisation failed" << GUI::Console::endl();
        return 1;
    }

    console << GUI::Console::normal << GUI::Console::highish << "Azadi engine initialisation finished" << GUI::Console::endl();


    // The following code is necessary otherwise the distance of wherever the mouse was
    // to the center of the screen gets accounted for in the rotations later on.
    // Which means sometimes we end up up-side-down
    SDL_WarpMouse(center[0],center[1]);

    //! Program main loop
    done = false;
    selecting=false;
    dispatching=false;

    unsigned int lastupdate=0;
    unsigned int intervall=30;
    while (!done)
    {
        ProcessMessages();
        if(SDL_GetTicks() - lastupdate >= intervall)
        {                // Center Mouse after each movment
            if (selecting == false)
                SDL_WarpMouse(center[0],center[1]);
            lastupdate=SDL_GetTicks();
        }
        Modeldata->Update();
        Draw();
        sound_factory.tick();  // Updates the sounds :D
        //SDL_Delay(22); // Set to 1 for quicker delay, still allows mouse movement.

    }

    console << GUI::Console::low << GUI::Console::normal << "Closing engine" << GUI::Console::endl();
    console << Drawing::getFrame() << " frames in " << SDL_GetTicks()/1000.0 << " seconds" << GUI::Console::endl();
    console << "Average framerate: " << 1000.0*Drawing::getFrame()/SDL_GetTicks() << GUI::Console::endl();

    return 0;
}

void Azadi::drawCursor(vector3f<GLfloat> forward, float ix, float iy)
{

	GLfloat cursPos[3];
	GLfloat test[3];

	cursPos[0] = origPos[0];
	cursPos[1] = origPos[1];
	cursPos[2] = origPos[2];

    #ifdef __VEC__
	cursPos[0] += *forward.X * (-cursorPos);
	cursPos[1] += *forward.Y * (-cursorPos);
	cursPos[2] += *forward.Z * (-cursorPos);
	#else
	cursPos[0] += forward.X * (-cursorPos);
	cursPos[1] += forward.Y * (-cursorPos);
	cursPos[2] += forward.Z * (-cursorPos);
	#endif

	test[0] = - ( cursPos[2]);
	test[1] = 0;
	test[2] = (cursPos[0] * 1);

	glTranslatef(CamPos[0], CamPos[1], CamPos[2]);
	glPushMatrix();
	glTranslatef(cursPos[0], cursPos[1],cursPos[2]);

	glColor3f(1.0, 1.0, 1.0);
	glBegin(GL_LINES);
	{
		glVertex3f(cursPos[0], cursPos[1], cursPos[2]);
		glVertex3f(-3.0, 0.0, 0.0);
		glVertex3f(0.0, 0.0, 0.0);
		glVertex3f(0.0, 3.0, 0.0);
		glVertex3f(0.0, 0.0,0.0);
		glVertex3f(0.0, 0.0, 1.0);
	}
	glEnd();

	glPopMatrix();

	glLoadIdentity();
	glRotatef(iy, 1.0, 0.0, 0.0);
	glRotatef(ix, 0.0, 1.0, 0.0);

	glTranslatef(-cursPos[0], -cursPos[1], -cursPos[2]);

	glPushMatrix();
}

bool Azadi::Draw()
{

    float movespeed;
    // Variable declarations should be at the beginning of the function
    GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 }; GLfloat mat_shininess[] = { 90.0 };
    GLfloat light_position[] = {1.5, 1.5 ,1.0, 0};

    //! Setup Cam
    // Rotation Vars
    static float ix=0;
    static float iy=0;

    vector3f<GLfloat> forward;
    vector3f<GLfloat> side;

    float Xangle, Yangle;

//    char buf[100];



    //glFrustum (-1.0, 1.0, -1.0, 1.0, 1.5, 20.0);
    //glFrustum(0,width,0,height,1.0,1.0);
    //glFrustum( GLdouble left, GLdouble right, GLdouble bottom, GLdouble top, GLdouble near, GLdouble far )

    glMatrixMode (GL_PROJECTION);
    glLoadIdentity ();
   // gluPerspective(60, screen[0]/screen[1], 0.1, 1800);  // Increased the viewable distance
	glFrustum (-1.0, 1.0, -1.0, 1.0, 1.5, 810.0);
    glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, 5.0);
    glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, 2.0);
    glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, 1.5);


    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
/* */
    glMatrixMode (GL_MODELVIEW);
    glLoadIdentity ();



    //Keep the angles small
    while(iy>360)
        iy-=360;

    while(iy<0)
        iy+=360;

    while(ix>360)
        ix-=360;

    while(ix<0)
        ix+=360;

    Xangle = iy*piover180;
    Yangle = ix*piover180;

    #ifdef __VEC__
    (*forward.Y) = -sin(Xangle);
    (*forward.X) = cos(Xangle)*sin(Yangle);
    (*forward.Z) = cos(Xangle)*-cos(Yangle);
    #else
    forward.Y = -sin(Xangle);
    forward.X = cos(Xangle)*sin(Yangle);
    forward.Z = cos(Xangle)*-cos(Yangle);
    #endif

    forward.Normalize();

    // Display the forward X Y Z and rotations in the window bar
   // sprintf( buf,"X:%f Y:%f Z:%f iy:%f ix:%f ",forward.X,forward.Y,forward.Z,iy,ix );
    //SDL_WM_SetCaption(buf, NULL);

    side=forward.normcrossprod(vector3f<GLfloat> (0.0f,1.0f,0.0f));


    movespeed=0.1;    // Modify the speed settings here!
    if(MoveKey[FORWARD])
    {
	if(!dispatching)
	{
		#ifdef __VEC__
        	CamPos[0]-=*forward.X*movespeed;
        	CamPos[1]-=*forward.Y*movespeed;
        	CamPos[2]-=*forward.Z*movespeed;
		#else
        	CamPos[0]-=forward.X*movespeed;
        	CamPos[1]-=forward.Y*movespeed;
        	CamPos[2]-=forward.Z*movespeed;
		#endif
	}
	else
	{
		iy+=2.5;
	}
    }
    if(MoveKey[BACKWARD])
    {
	if(!dispatching)
	{
		#ifdef __VEC__
        	CamPos[0]+=*forward.X*movespeed;
        	CamPos[1]+=*forward.Y*movespeed;
        	CamPos[2]+=*forward.Z*movespeed;
		#else
        	CamPos[0]+=forward.X*movespeed;
        	CamPos[1]+=forward.Y*movespeed;
        	CamPos[2]+=forward.Z*movespeed;
		#endif
	}
	else
	{
		iy-=2.5;
	}
    }
    if(MoveKey[LEFT])
    {
	if(!dispatching)
	{
		#ifdef __VEC__
        	CamPos[0]+=*side.X*movespeed;
        	CamPos[1]+=*side.Y*movespeed;
        	CamPos[2]+=*side.Z*movespeed;
		#else
        	CamPos[0]+=side.X*movespeed;
        	CamPos[1]+=side.Y*movespeed;
        	CamPos[2]+=side.Z*movespeed;
		#endif
	}
	else
	{
		ix-=2.5;
	}
    }
    if(MoveKey[RIGHT])
    {
	if(!dispatching)
	{
		#ifdef __VEC__
		CamPos[0]-=*side.X*movespeed;
        	CamPos[1]-=*side.Y*movespeed;
        	CamPos[2]-=*side.Z*movespeed;
		#else
        	CamPos[0]-=side.X*movespeed;
        	CamPos[1]-=side.Y*movespeed;
        	CamPos[2]-=side.Z*movespeed;
		#endif
	}
	else
	{
		ix+=2.5;
	}
    }

    // Set it so that if the space button is being held, the screen doesn't rotate
    if (!selecting && !dispatching)
    {
    	iy-=(center[1]-mouse[1])*0.05;   // The mouse movement speed though hasn't been changed
    	ix-=(center[0]-mouse[0])*0.05;
    }

    // We DO need light !
    glEnable(GL_LIGHT0);

    // Move the cam
    if(!dispatching)
    {
    	glRotatef(iy,1,0,0);
    	glRotatef(ix,0,1,0);
    	glTranslatef(CamPos[0],CamPos[1],CamPos[2]);
    }

    /**************************************************************************
     ************************* Camera Setup Finished *************************
    ***************************************************************************/

    alListener3f(AL_POSITION, CamPos[0], CamPos[1],CamPos[2]);
    glClearColor (0.0, 0.0, 0.0, 0.0);
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );


    // If we are dispatching, then run the draw cursor function
    if (dispatching)
        drawCursor(forward, ix, iy);

    // draw temporary particle system
    testPart->tick();
    testPart->draw();

    glTranslatef(-8*24, 1.0,-6*24);


    ExtractFrustum();
	//if (SphereInFrustum(1,1,1,5)){printf("coolrunnins");};
	//PointInFrustum(1,1,1);
    TP.Draw();

    glEnable(GL_LIGHTING);

    glEnable(GL_TEXTURE_2D);

glTranslatef(100,0,100);
glScalef(1.5,1.5,1.5);
glRotatef(-90,1,0,0);
    glEnable(GL_TEXTURE_2D);
    Modeldata->Draw();

glPopMatrix();

    glDisable(GL_LIGHTING);



/*---------------------------------------------------------------------------------------------------------------------
		Temporary, just to show that texturing does actually work.
*/
    glPushMatrix();
	glTranslatef(15, 30, 0);
	texture_factory.applyTexture(2);
	glBegin(GL_POLYGON);
	{
		glTexCoord3f(-1.0, -1.0, 0.0);
		glVertex3f(-2.0, -2.0, 0.0);
		glTexCoord3f(1.0, -1.0, 0.0);
		glVertex3f(20.0, -2.0, 0.0);
		glTexCoord3f(1.0, 1.0, 0.0);
		glVertex3f(20.0, 20.0, 0.0);
		glTexCoord3f(-1.0, 1.0, 0.0);
		glVertex3f(-20.0, 20.0, 0.0);
	}
	glEnd();
	glPopMatrix();

//---------------------------------------------------------------------------------------------------------------------

    if(dispatching)
	glPopMatrix();

	// Disable texturing
	glDisable(GL_TEXTURE_2D);

    //! Menu drawing starts here
    glMatrixMode (GL_PROJECTION);
    glLoadIdentity ();
    glOrtho( 0, screen[0],screen[1], 0, 0, 1 );
    //gluOrtho2D (0.0, (GLdouble) screen[0], 0.0, (GLdouble) screen[1]);

    glMatrixMode (GL_MODELVIEW);
    glLoadIdentity ();

    //Drawing::prepare2D();
    console.draw();
    fps_counter.draw();

    Drawing::flipBuffers();

    return true;
}



/*! \brief Processes the messages
 */
void Azadi::ProcessMessages()
{
    input.get();

    console.parseInput();
/*
    MoveKey[FORWARD] = input.isKeyDepressed(SDLK_w);
    MoveKey[BACKWARD] = input.isKeyDepressed(SDLK_s);
    MoveKey[LEFT] = input.isKeyDepressed(SDLK_a);
    MoveKey[RIGHT] = input.isKeyDepressed(SDLK_d);
*/
   // done = input.isKeyDepressed(SDLK_ESCAPE) | input.isQuit();

 //   if (input.getKeyPress(SDLK_BACKQUOTE))
   //     console.toggleShow();

    if (input.getKeyPress(SDLK_PAGEUP))
        console.increaseVerbosityLevel();

    if (input.getKeyPress(SDLK_PAGEDOWN))
        console.decreaseVerbosityLevel();



    mouse[0] = input.getMouseX();
    mouse[1] = input.getMouseY();


    if (input.getMouseClick(SDL_BUTTON_RIGHT)) {

        selecting=false;
        dispatching = true;
        SDL_ShowCursor(SDL_DISABLE);
        cursorPos=100.0;
        curMousePos=mouse[1];

        origPos[0] = -CamPos[0];
        origPos[1] = -CamPos[1];
        origPos[2] = -CamPos[2];

        viewport_matrix[0]=0;
        viewport_matrix[1]=0;
        viewport_matrix[2]=screen[0];
        viewport_matrix[3]=screen[1];

        glGetDoublev(GL_PROJECTION_MATRIX, projection_matrix);
        glGetIntegerv(GL_VIEWPORT, viewport_matrix);
    }




    //input.flush();
}


void Azadi::cmdTriggered(std::string cmd)
{
    if(cmd == "forward")
        MoveKey[FORWARD] = true;
    if(cmd == "backward")
        MoveKey[BACKWARD] = true;
    if(cmd == "left")
        MoveKey[LEFT] = true;
    if(cmd == "right")
        MoveKey[RIGHT] = true;
    if(cmd == "exit" || cmd == "quit")
        done = true;
    if(cmd == "select")
    {
        selecting = !selecting;
        SDL_ShowCursor(selecting?SDL_ENABLE:SDL_DISABLE);
    }
    //console << cmd << " + " <<GUI::Console::endl();

}

void Azadi::cmdReleased(std::string cmd)
{
    if(cmd == "forward")
        MoveKey[FORWARD] = false;
    if(cmd == "backward")
        MoveKey[BACKWARD] = false;
    if(cmd == "left")
        MoveKey[LEFT] = false;
    if(cmd == "right")
        MoveKey[RIGHT] = false;

    //console << cmd << " - " << GUI::Console::endl();

}



std::string Azadi::acceptConsoleCommand(std::string cmd)
{
    done = true;
    return "?";
}
