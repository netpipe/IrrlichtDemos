#include "../Input/ConsoleListener.h"
#include "angelscript.h"
#include "scriptstring.h"

//! Scripting engine class
class ScriptEngine : public ConsoleListener
{
	public:
		ScriptEngine();
		~ScriptEngine();
		std::string acceptConsoleCommand(std::string);

	private:
		asIScriptEngine *scriptEngine;
};

extern ScriptEngine script_engine;
