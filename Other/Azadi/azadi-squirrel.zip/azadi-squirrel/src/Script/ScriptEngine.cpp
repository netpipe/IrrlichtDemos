#include "ScriptEngine.h"
#include <cassert>
#include "../GUI/Console.h"

using GUI::Console;
namespace ScriptHandler
{
	void displayint(asIScriptGeneric *gen)
	{
		int i = gen->GetArgDWord(0);
		console << i << Console::endl();
	}

	void displaystring(asIScriptGeneric *gen)
	{
		console << "Entered a string" << Console::endl();
	}

	void loadscript(std::string& filename)
	{
		// need to write a script loader
	}
};
using namespace ScriptHandler;

//! ScriptEngine constructor
ScriptEngine::ScriptEngine()
{
	int r;

	console.registerObject(*this, (std::string)"cmd");
	console << Console::medium << Console::normal << Console::high << "Initializing Scripting Engine" << Console::endl();
	scriptEngine = asCreateScriptEngine(ANGELSCRIPT_VERSION);
	if (scriptEngine == 0)
	{
		console << Console::medium << Console::normal << Console::high << "Could not initialize the scripting engine" << Console::endl();
	}

	// Temporary
	#ifdef __powerpc__
	RegisterScriptString(scriptEngine);
	#endif
	r = scriptEngine->RegisterGlobalFunction("void _display(int)", asFUNCTION(displayint), asCALL_GENERIC);
	assert (r>=0);
	#ifdef __powerpc__
	r = scriptEngine->RegisterGlobalFunction("void _display(const string &in)", asFUNCTION(displaystring), asCALL_GENERIC);
	assert (r>=0);
	#endif
}

//! ScriptEngine destructor
ScriptEngine::~ScriptEngine()
{

}

std::string ScriptEngine::acceptConsoleCommand(std::string command)
{
	int result;

	std::string com;
	std::string::size_type loc = command.find(' ',0);
	std::string command_portion = command.substr(0,loc);
	if(command_portion == "print")
	{
		com = "_display(" + command.substr(loc+1, std::string::npos) + ")";
	}
	else if(command_portion == "loadscript")
	{
		com = "_loadscript(" + command.substr(loc+1, std::string::npos) + ")";
	}
	result = scriptEngine->ExecuteString("ScriptHandler", com.c_str());
	if (result < 0)
	{
		console << "Error " << result << " in " << com << Console::endl();
	}
	else if (result == asEXECUTION_EXCEPTION)
	{
		console << com << " raised an exception error" << Console::endl();
	}
}
