#ifndef BUTTON_H
#define BUTTON_H

class Input;

namespace GUI
{

    class Button {
    public:
        enum direction {DIRECTION_RIGHT, DIRECTION_DOWN, DIRECTION_LEFT, DIRECTION_UP};
    protected:
        signed x;
        signed y;
        direction current_direction;
        unsigned referenceID;
        bool is_clicked;
        unsigned button_number;
    public:
        Button();
        Button(signed x, signed y, direction current_direction);
        Button& setX(signed x);
        Button& setY(signed y);
        Button& setDirection(direction current_direction);
        Button& setButtonNumber(unsigned number);
        void draw();
        void parseInput(Input& input);
        bool getMouseClick();
        void initTextures();
    };
}


#endif
