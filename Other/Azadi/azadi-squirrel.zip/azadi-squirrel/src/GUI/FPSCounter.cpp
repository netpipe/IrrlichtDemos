#include "FPSCounter.h"

#include <sstream>

#ifndef __OSX__
	#include <GL/gl.h>
#else
	#include <OpenGL/gl.h>
#endif

#include "Drawing.h"

GUI::FPSCounter::FPSCounter() {
	show = true;
	x = 4;
	y = 582;
	width = 100;
	height = 14;
}

void GUI::FPSCounter::parseInput(Input& input) {
}

void GUI::FPSCounter::initTextures() {
}

void GUI::FPSCounter::toggleShow()
{
    show = !show;
}

void GUI::FPSCounter::draw() {

    if (!show) return;

    Drawing::prepare2D();

    glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND);

    glColor4f(0.0,0.6,1.0,1.0);
    glRectd(x,y,x+28,y+height);

    glColor4f(1.0,1.0,1.0,1.0);
    glRectd(x+28,y,x+width,y+height);

    glColor4f(0.0,0.0,0.0,1.0);
    glBegin(GL_LINE_LOOP);

    glVertex2i(x,y);
    glVertex2i(x+width,y);
    glVertex2i(x+width,y+height);
    glVertex2i(x,y+height);

    glEnd();

    glBegin(GL_LINES);
        glVertex2i(x+28,y);
        glVertex2i(x+28,y+height);
    glEnd();

    glColor3f(1.0,1.0,1.0);
    std::stringstream fps;
    fps << Drawing::getFPS();
    Drawing::drawText(x+4,y,"FPS",12);

    glColor3f(0.0,0.0,0.0);
    Drawing::drawText(x+28+4,y,fps.str(),12);

   glColor3f(1.0,1.0,1.0);
   glDisable(GL_BLEND);
   glEnable(GL_CULL_FACE);
}

