#include "Button.h"

#include "../Texture/TextureFactory.h"
#include "../Input/Input.h"
#include <string>

GUI::Button::Button()
{
}

GUI::Button::Button(signed x, signed y, direction current_direction)
{
	this->x = x;
	this->y = y;
	this->current_direction = current_direction;
	this->is_clicked = false;
}

void GUI::Button::initTextures() {
	referenceID = texture_factory.loadTexture("core_gui.png");
}

GUI::Button& GUI::Button::setX(signed x)
{
	this->x = x;
	return *this;
}

GUI::Button& GUI::Button::setY(signed y)
{
	this->y = y;
	return *this;
}

GUI::Button& GUI::Button::setButtonNumber(unsigned number)
{
	this->button_number = number;
	return *this;
}

GUI::Button& GUI::Button::setDirection(direction current_direction)
{
	this->current_direction = current_direction;
	return *this;
}

void GUI::Button::parseInput(Input& input)
{
	if (input.getMouseX()>(x) && input.getMouseX()<(x+16))
		if (input.getMouseY()>(y) && input.getMouseY()<(y+16))
			if (input.getMouseClick(1))
				is_clicked = true;
}

bool GUI::Button::getMouseClick()
{
	if (is_clicked == false)
		return false;
	is_clicked = false;
	return true;
}

void GUI::Button::draw()
{
    glLoadIdentity ();
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
        glTranslatef(x, y, 0.0f);
	glTranslatef(8,8,0);

	texture_factory.applyTexture(referenceID);


        glRotated(current_direction*90,0.0,0.0,1.0);
	float x[2];
	float y[2];

	x[0] = (button_number%32)*(1/32.0);
	x[1] = x[0] + (1/32.0);
	y[0] = (button_number/32)*(1/32.0);
	y[1] = y[0] + (1/32.0);

	glBegin(GL_QUADS);

	glTexCoord2f(x[0],1.0-y[0]);
	glVertex2f(-8.0f, -8.0f);
	
	glTexCoord2f(x[1],1.0-y[0]);
	glVertex2f(8.0f, -8.0f);
	
	glTexCoord2f(x[1],1.0-y[1]);
	glVertex2f(8.0f, 8.0f);
	
	glTexCoord2f(x[0],1.0-y[1]);
	glVertex2f(-8.0f, 8.0f);
	
	glEnd();

	glDisable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);

}
