#ifndef __FILESYSTEM
#define __FILESYSTEM

#include <fstream>

#include <zlib.h>

#ifdef WIN32
	#include <fcntl.h>
	#include <io.h>
	#define SET_BINARY_MODE(file) setmode(fileno(file), 0_BINARY)
#else
	#define SET_BINARY_MODE(file)
#endif

/*
ios::app  	append output
ios::ate 	seek to EOF when opened
ios::binary 	open the file in binary mode
ios::in 	open the file for reading
ios::out 	open the file for writing
ios::trunc 	overwrite the existing file
*/

#define APP     0x01
#define ATE     0x02
#define BIN     0x04
#define IN      0x08
#define OUT     0x10
#define TRUNC   0x20

#define CHUNK   1048576

class fileSystem
{
    public:
        fileSystem(char* filename=0,unsigned char flags=0);
        void open(char* filename,unsigned char flags);
        void read(char* buffer, unsigned int num);
        void close(bool destroy=false);
        operator bool();
        int getFilesize();
        int tellg();

    private:
        std::fstream file;
        void openCompressed(char* filename,unsigned char flags);
        bool valid;
        int position;
};


#endif
