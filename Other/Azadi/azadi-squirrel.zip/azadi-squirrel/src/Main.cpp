#include "Azadi.h"
#include "GUI/Console.h"
#include "Texture/TextureFactory.h"
#include "Sound/SoundFactory.h"
#include "Script/ScriptEngine.h"
#include <cstdio>

#ifdef __OSX__
	#import <Cocoa/cocoa.h>
#endif

//! Global Console Object for printing Information

Input input;
GUI::Console console;
TextureFactory texture_factory;
SoundFactory sound_factory;
ScriptEngine script_engine;

int main ( int argc, char** argv )
{
    #ifdef __OSX__
	NSApplicationLoad();
	NSAutoreleasePool *autoreleasepool = [[NSAutoreleasePool alloc] init];
    #endif

    Azadi game(argc,argv);
    game.Run();

    #ifdef __OSX__
	[autoreleasepool release];
    #endif
    return 0;
}




