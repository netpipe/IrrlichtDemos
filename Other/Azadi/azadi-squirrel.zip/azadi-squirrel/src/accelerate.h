/*
	Shorter more legible prototypes for vector functions
*/

#if __3dNOW__
	#include <mm3dnow.h>
#elif __SSE__
	#include <xmmintrin.h>
#elif __VEC__
	#include <altivec.h>
#endif

/*

	Altivec

*/

// Datatype
#define m64 __m64

// Functions
#define m_pfmul _m_pfmul

/*

	SSE
	
*/

// Datatype
#define m128 __m128

// Functions
#define mm_mul_ps _mm_mul_ps
