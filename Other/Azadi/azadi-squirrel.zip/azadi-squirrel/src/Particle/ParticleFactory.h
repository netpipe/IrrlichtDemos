#include "Particle.h"
#include <map>

#ifndef __OSX__
	#include <GL/gl.h>
#else
	#include <OpenGL/gl.h>
#endif

//! Class definition of the Particle factory
class ParticleFactory
{
	public:
		ParticleFactory();
		~ParticleFactory();
		bool init(vector3f<GLfloat> pos, vector3f<GLfloat> dir, vector3f<GLfloat> color, GLfloat alpha, GLfloat coneSize, GLfloat life, GLfloat duration, unsigned int numParts, GLfloat psize);
		int tick();	// Updates particle positions, returns  1 if all the particles are dead
		void draw();
	private:
		std::map<unsigned int,Particle> particles;
		GLfloat size;
		vector3f<GLfloat> position;
		vector3f<GLfloat> direction;
		vector3f<GLfloat> col;
		GLfloat pAlpha;
		GLfloat pLife;
		unsigned int lastErased;
		unsigned int numParticles;
		unsigned int lastBorn;
};
