#include "../vector.h"

class Particle
{
	public:
		Particle();
		~Particle();
		bool isDead();
		bool init(vector3f<GLfloat> pos, vector3f<GLfloat> dir, vector3f<GLfloat> col, GLfloat alpha, GLfloat life);
		void draw();
		char update();
	private:
		GLfloat position[3];
		GLfloat direction[3];
		GLfloat color[4];
		GLfloat coef;
};
