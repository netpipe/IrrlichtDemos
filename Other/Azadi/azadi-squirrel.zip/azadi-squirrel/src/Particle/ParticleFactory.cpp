#include "ParticleFactory.h"

ParticleFactory::ParticleFactory()
{
	lastBorn = 0;
	lastErased = 0;

}

ParticleFactory::~ParticleFactory()
{

}

//! This is a big fat function O_O   Underdocumented at the moment
bool ParticleFactory::init(vector3f<GLfloat> pos, vector3f<GLfloat> dir, vector3f<GLfloat> color, 
	GLfloat alpha, GLfloat coneSize,
	GLfloat life, GLfloat duration, unsigned int numParts, GLfloat psize)
{
	numParticles = numParts;
	size = psize;
	position = pos;
	direction = dir;
	col = color;
	pAlpha = alpha;
	pLife = life;
	return false;
}

//! Updates the position of the particles as well as creates new ones
int ParticleFactory::tick()
{
	unsigned int i;
	unsigned int birthRate;
	vector3f<GLfloat> temp;

	srand( SDL_GetTicks() );

	birthRate = unsigned(lastBorn) + 1;

	if (lastBorn < numParticles)
	{
		i = lastBorn;
		lastBorn = birthRate;
	}
	else
	{
		i = 0;
		lastBorn = 0;
	}
	for (; i< birthRate; i++)
	{
		if (particles[i].isDead())
		{
			// Should turn this random generator function into a simplified function for myself
			temp.X = (direction.X + ( rand() / ((double)RAND_MAX + 1) ) ); temp.X -= (rand()/((double)RAND_MAX + 1));
			temp.Y = (direction.Y + ( rand() / ((double)RAND_MAX + 1) ) ); temp.Y -= (rand()/((double)RAND_MAX + 1));
			temp.Z = (direction.Z + ( rand() / ((double)RAND_MAX + 1) ) ); temp.Z -= (rand()/((double)RAND_MAX + 1));
			particles[i].init(position, temp, col, pAlpha, pLife);
		}
	}

	for(i=0; i<unsigned(particles.size()); i++)
	{
		particles[i].update();
	}
	return 0;
}

//! Draws the particles themselves
void ParticleFactory::draw()
{
	unsigned int i;

	glPointSize(size);
	glBegin(GL_POINTS);
	{
		for (i=0; i< unsigned(particles.size()); i++)
		{
			particles[i].draw();
		}
	}
	glEnd();
}

