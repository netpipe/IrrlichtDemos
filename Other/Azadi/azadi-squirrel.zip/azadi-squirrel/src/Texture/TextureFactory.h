#ifndef TEXTUREFACTORY_H_04112006
#define TEXTUREFACTORY_H_04112006

#ifndef __OSX__
	#include <png.h>
	#include <GL/gl.h>
#else
	#include <libpng/png.h>
	#include <OpenGL/gl.h>
#endif

#include <map>

#define PNG_OK		 0
#define PNG_FILEIOERROR  1
#define PNG_MALLOCERROR  2
#define PNG_JUMPSETERROR 3

//! Texture factory class, globalised with texture_factory
class TextureFactory
{
	public:
		TextureFactory();
		~TextureFactory();
		int loadTexture(const std::string& filename);
		int applyTexture(int texNumber);
	private:
		std::map<std::string,unsigned> textures;
		std::map<unsigned,GLuint> references;
		int loadPNG(const std::string& filename);
};

extern TextureFactory texture_factory;

#endif

