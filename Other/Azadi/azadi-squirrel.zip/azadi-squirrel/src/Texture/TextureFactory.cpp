#include "TextureFactory.h"
#include "../GUI/Console.h"
#include <cstdio>

#ifdef __OSX__
	#include <OpenGL/glu.h>
#else
	#include <GL/glu.h>
#endif

using GUI::Console;

TextureFactory::TextureFactory()
{
	console << Console::normal << Console::high << "Initializing Texture Factory" << Console::endl();
}

TextureFactory::~TextureFactory()
{

}

//! Loads a PNG and generates the texture
int TextureFactory::loadPNG(const std::string& filename)
{

	console << Console::normal << Console::highish << "Attempting to load: " << filename << Console::endl();

	png_structp png_ptr;
	png_infop info_ptr;
	png_infop end_ptr;

	GLubyte	*image_data;
	GLbyte sig[8];

	GLint bit_depth;
	GLint color_type;

	unsigned long width;
	unsigned long height;
	unsigned int rowbytes;
	GLuint component;

	image_data=NULL;
	unsigned int i;
	png_bytepp row_pointers=NULL;

	FILE* infile = fopen(filename.c_str(),"rb");
	if (!infile)
	{
		console << Console::warning << Console::medium << "Cannot open texture:" << filename << Console::endl();
		return PNG_FILEIOERROR;
	}

	// Reads the file to see if the PNG signature exists
	fread(sig, 1, 8, infile);
	if (!png_check_sig((GLubyte *) sig, 8))
	{
		console << Console::warning << Console::medium << filename << " is not a valid PNG" << Console::endl();
		fclose(infile);
		return PNG_FILEIOERROR;
	}

	// Creates a structure to read the PNG information
	png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if (!png_ptr)
	{
		fclose(infile);
		return PNG_MALLOCERROR;
	}

	info_ptr=png_create_info_struct(png_ptr);
	if (!info_ptr)
	{
		png_destroy_read_struct(&png_ptr, (png_infopp) NULL, (png_infopp) NULL);
		fclose(infile);
		return PNG_MALLOCERROR;
	}

	end_ptr = png_create_info_struct(png_ptr);
	if (!end_ptr)
	{
		png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp) NULL);
		fclose(infile);
		return PNG_MALLOCERROR;
	}

	if (setjmp(png_jmpbuf(png_ptr)))
	{
		png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
		fclose(infile);
		return PNG_JUMPSETERROR;
	}

	png_ptr->io_ptr = (png_voidp)infile;

	png_init_io(png_ptr, infile);
	png_set_sig_bytes(png_ptr, 8);

	// Start the PNG information reading
	png_read_info(png_ptr, info_ptr);
	png_get_IHDR(png_ptr, info_ptr, (png_uint_32 *)&width, (png_uint_32 *)&height, (int *)&bit_depth, (int *)&color_type, NULL, NULL, NULL);
	width = width;
	height = height;

	// Set up the alpha for textures
	if (color_type == PNG_COLOR_TYPE_RGB_ALPHA)
		component = GL_RGBA;
	else
		component = GL_RGB;

	png_read_update_info(png_ptr, info_ptr);

	rowbytes = png_get_rowbytes(png_ptr, info_ptr);

	// Allocate the data required to store the image
	if ((image_data=new GLubyte[rowbytes * height]) == NULL)
	{
		png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
		return 4;
	}

	if ((row_pointers=new png_bytep[height* sizeof(png_bytep)]) == NULL)
	{
		png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
		delete [] image_data;
		image_data = NULL;
		return 4;
	}

	for (i=0; i<height; ++i)
		row_pointers[height -1 -i] = image_data + i*rowbytes;

	// Finally read the image itself
	png_read_image(png_ptr, row_pointers);

	delete [] row_pointers;

	png_destroy_read_struct(&png_ptr, &info_ptr, NULL);

	fclose (infile);

	GLuint texID;

	// Texture Generation
	glGenTextures(1, &texID);

	glBindTexture(GL_TEXTURE_2D, texID);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST_MIPMAP_NEAREST);

	glTexImage2D(GL_TEXTURE_2D, 0, component, width, height, 0, component, GL_UNSIGNED_BYTE, image_data);

	// Generate mipmaps
	gluBuild2DMipmaps(GL_TEXTURE_2D, component, width, height, component, GL_UNSIGNED_BYTE, image_data);

	delete [] image_data;
	delete [] end_ptr;

	unsigned referenceID = unsigned(textures.size());

	references[referenceID] = texID;
	textures[filename] = referenceID;

	return PNG_OK;
}

//! Texture loading function (Can be appended to include more file formats) Returns the texture index number
int TextureFactory::loadTexture(const std::string& textureName)
{
	std::string texname("./data/textures/"); // Should be changed to wherever the data belongs
	std::string extra;
	std::string ext;
	std::string temp;

	texname += textureName;

	std::map<std::string,unsigned>::iterator value  = textures.find(texname);
	if (value != textures.end())
	{
		console << Console::normal << Console::high << texname << " already loaded." << Console::endl();
		return (*value).second;
	}

	if ((textureName).find(".png") != std::string::npos)
		if (loadPNG(texname) == PNG_OK)
		{
			return textures[texname];
		}
		else
		{
			return -1;
		}
	else
		console << Console::lowish << Console::warning << "Loading of file" << textureName << "failed: Filetype unsupported" << Console::endl();

	return -1; // return an error number -1
}

//! Applies a texture specified with index texNumber
int TextureFactory::applyTexture(int texNumber)
{
	glBindTexture(GL_TEXTURE_2D, references[texNumber]);
	return 0;
}
