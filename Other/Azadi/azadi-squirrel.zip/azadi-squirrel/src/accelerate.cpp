#include "accelerate.h"

//! Accelerate framework that facilitates SIMD instruction vector functions
namespace Accelerate
{
	/* 
		All these are function definitions for vector acceleration
		At the moment, the way we are implementing it into
		Azadi doesn't provide much performance improvement at all

		However, I'll steadily modify the vector3f<T> template to work
		more fluidly with this framework
	*/

	//! Contains SIMD specific vector formats
	typedef struct
	{
		#if __3dNOW__
			union{
				m64 vec;
				float v[2];
			}vector1;
			union{
				m64 vec;
				float v[2];
			}vector2;
			
		#elif __SSE__
			union{
				m128 vec;
				float v[3];
			}vect;
		
		#elif __VEC__
			union{
				vector float vec;
				float v[3];
			}vect;
		
		#else
			union{
				float vec[3];
				float v[3];
			}vect;
		
		#endif
	}vector3f;

	#ifdef __VEC__
		vector float zero=(vector float){0};
	#endif

	//! Loads a vector x,y,z into the vector3f struct vect
	int loadvector(vector3f *vect, float x, float y, float z)
	{
		#if __3dNOW__
			vect->vector1.v[0]=x;
			vect->vector1.v[1]=y;
			vect->vector2.v[0]=z;
		
		#elif __VEC__
			vect->vect.v[0]=x;
			vect->vect.v[1]=y;
			vect->vect.v[2]=z;
		
		#elif __SSE__
			vect->vect.v[0]=x;
			vect->vect.v[1]=y;
			vect->vect.v[2]=z;
		
		#else
			vect->vect.v[0]=x;
			vect->vect.v[1]=y;
			vect->vect.v[2]=z;
	
		#endif
	
		return 0;
	}

	//! Multiplies the vector3f vec1 vector by scalar
	vector3f vecMulScalar3f(vector3f vec1, float scalar)
	{
		vector3f temp;
		#if __3dNOW__
			m64 scale;
			scale=(m64){scalar};
			temp.vector1.vec=m_pfmul(vec1.vector1.vec, scale);
			temp.vector2.vec=m_pfmul(vec1.vector2.vec, scale);
			
			return temp;
		#elif __VEC__
			vector float scale;
			scale=(vector float){scalar};
			temp.vect.vec=vec_madd(vec1.vect.vec, scale, zero);
			
			return temp;
		#else
			vec1.vect.v[0]*=scalar;
			vec1.vect.v[1]*=scalar;
			vec1.vect.v[2]*=scalar;
		
			return vec1;
		#endif
	}

	//! Calculates the dot product of vector3f vec1 and vector3f vec2 using SIMD instructions
	float dotproduct(vector3f vec1, vector3f vec2)
	{
		vector3f temp;
		#if __VEC__
			printf("Altivec style\n");
			temp.vect.vec=vec_madd(vec1.vect.vec, vec2.vect.vec, zero);
		
			return (temp.vect.v[0]+temp.vect.v[1]+temp.vect.v[2]);
		
		#elif __3dNOW__
			temp.vector1.vec=m_pfmul(vec1.vector1.vec, vec2.vector1.vec);
			temp.vector2.vec=m_pfmul(vec1.vector2.vec, vec2.vector2.vec);
		
			return (temp.vector1.v[0]+temp.vector1.v[1]+temp.vector2.v[0]);	

		#elif __SSE__
			temp.vect.vec=mm_mul_ps(vec1.vect.vec, vec2.vect.vec);
		
			return (temp.vect.v[0]+temp.vect.v[1]+temp.vect.v[2]);
	
		#else
			temp.vect.v[0]=vec1.vect.v[0] * vec2.vect.v[0];
			temp.vect.v[1]=vec1.vect.v[1] * vec2.vect.v[1];
			temp.vect.v[2]=vec1.vect.v[2] * vec2.vect.v[2];

			return (temp.vect.v[0]+temp.vect.v[1]+temp.vect.v[2]);
	
		#endif	
	}

	//! Calculates the cross product of vector3f vec1 and vector3f vec2
	vector3f crossproduct(vector3f vec1, vector3f vec2)
	{
		vector3f temp;
		#if __3dNOW__
			temp.vector1.v[0]=(vec1.vector2.v[0] * vec2.vector1.v[1]) - (vec1.vector1.v[1] * vec2.vector2.v[0]);
			temp.vector1.v[1]=(vec1.vector1.v[0] * vec2.vector2.v[0]) - (vec1.vector2.v[0] * vec2.vector1.v[0]);
			temp.vector2.v[0]=(vec1.vector1.v[1] * vec2.vector1.v[0]) - (vec1.vector1.v[0] * vec2.vector1.v[1]);
		
			return temp;
		
		#else
			temp.vect.v[0]=(vec1.vect.v[2] * vec2.vect.v[1]) - (vec1.vect.v[1] * vec2.vect.v[2]);
			temp.vect.v[1]=(vec1.vect.v[0] * vec2.vect.v[2]) - (vec1.vect.v[2] * vec2.vect.v[0]);
			temp.vect.v[2]=(vec1.vect.v[1] * vec2.vect.v[0]) - (vec1.vect.v[0] * vec2.vect.v[1]);
	
			return temp;
		#endif
	}


	/*
		These are the function definitions that will work with the vector3f<T>
		template. Remember, this is only a temporary solution
	*/

	//! A front end to the aformentioned dotproduct function for Azadi
	float dotProd(float x, float y, float z, float x1, float y1, float z1)
	{
		float result;

		vector3f vec1, vec2;
		loadvector(&vec1, x, y, z);
		loadvector(&vec2, x1, y1, z1);

		result=dotproduct(vec1, vec2);

		return result;
	}

	//! A front end to the aformentioned cross product function for Azadi
	int crossProd(float *result[3], float x, float y, float z, float x1, float y1, float z1)
	{
		vector3f vec1, vec2, vec3;
		loadvector(&vec1, x, y, z);
		loadvector(&vec2, x1, y1, z1);

		vec3 = crossproduct(vec1, vec2);
		(*result[0]) = vec3.vect.v[0];
		(*result[1]) = vec3.vect.v[1];
		(*result[2]) = vec3.vect.v[2];

		// Missing a normalize function

		return 0;
	}
}
