#include "Client.h"

//! Connects to the master server
bool client::cconnect()
{

	return true;
}

//! Disconnects from the master server
bool client::cdisconnect()
{

	return true;
}

//! Send data down the wire
bool client::cpushdata()
{

	return true;
}

//! Receive data from the wire
bool client::creceivedata()
{

	return true;
}

