#ifndef __MINGW32__
#include <sys/socket.h>
#else
#include <winsock2.h>
#endif

//! Class that contains the functions to connect to the master server
class client
{
	public:
		bool cconnect();
		bool cdisconnect();
		bool cpushdata();
		bool creceivedata();
	private:
		int sock;
};
