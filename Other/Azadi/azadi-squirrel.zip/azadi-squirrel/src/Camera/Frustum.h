#include <GL/gl.h>
#include <cmath>

class Frustum
{
	public:
		void ExtractFrustum();
		bool PointCheck(float, float, float);
		bool SphereCheck(float, float, float, float);
		float frustum[6][4];
};
