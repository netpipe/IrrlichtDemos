#ifndef SOUNDFACTORY_H
#define SOUNDFACTORY_H

#include "../Azadi.h"
#include "../vector.h"
#include "Ogg/OggFile.h"
#include "SoundSource/SoundSource.h"

//! Global sound factory that facilitates the loading and playing of audio
class SoundFactory
{
	public:
		SoundFactory();
		~SoundFactory();
		void soundNotWorking();
		long loadSound(const std::string&);
		unsigned int newSource();
		long attachSound(unsigned int);	// Attaches a sound to a source, returns the source ID
		bool playSource(unsigned int);	// Plays the source ID'd sound
		bool stopSource(unsigned int);	// Stops the source ID'd sound
		bool moveSound(unsigned int, vector3f<GLfloat> );	// moves the souce to a new position
		bool removeSound(unsigned int);	// detaches the source from the sound
		bool setSourceAtten(unsigned int, float);
		bool setSourceVol(unsigned int, float);
		bool setSourceLoop(unsigned int, bool);
		void tick();	// This function should be called every cycle, it updates the sound
				// Buffers

	private:
		unsigned int sources;
		bool soundIsWorking;
		bool loadOgg(const std::string&);
		unsigned int counter;
		std::map<std::string,unsigned int> sounds;
		std::map<unsigned int,OggFile> files;
		std::map<unsigned int,SoundSource> soundsources;
		std::map<unsigned int,unsigned int> source;
};

extern SoundFactory sound_factory;

#endif
