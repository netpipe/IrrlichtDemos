#include "../../vector.h"

#ifndef __OSX__
	#include <AL/al.h>
#else
	#include <OpenAL/al.h>
#endif

#include "../Ogg/OggFile.h"

//! Class that handles sound sources for OpenAL
class SoundSource
{
	public:
		bool setPos(vector3f<GLfloat>);
		void update();
		bool isPlaying();
		void play();
		void stop();
		void attachToSource(OggFile*, unsigned int);
		void setAttenuation(float);
		void setVolume(float);
		void setLooping(bool);
	private:
		float volume;
		bool looping;
		bool bufferit(ALuint);
		vector3f<GLfloat> position;
		unsigned int source;
		OggFile *ogg;
		ALuint buffers[2];
};
