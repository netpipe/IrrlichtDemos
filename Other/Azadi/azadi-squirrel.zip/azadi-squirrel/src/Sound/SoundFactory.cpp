#include "SoundFactory.h"
#include "../GUI/Console.h"

using GUI::Console;

//! SoundFactory constructor
SoundFactory::SoundFactory()
{
	console << Console::normal << Console::high << "Initializing Sound Factory" << Console::endl();
	sources = 0;
	soundIsWorking = true;
}

//! SoundFactory destructor
SoundFactory::~SoundFactory()
{

}

void SoundFactory::soundNotWorking()
{
	soundIsWorking = false;
}

//! loads an ogg file into the sound factory
bool SoundFactory::loadOgg(const std::string& filename)
{
	unsigned int selector = unsigned(files.size());

	if (files[selector].open(filename)<0)
	{
		console << Console::normal << Console::high << "Error loading: " << filename << Console::endl();
		return false;
	}

	unsigned int reference = unsigned(sounds.size());
	sounds[filename] = reference;

	return true;
}

//! The front end to all the sound loading functions, returns an ID number of the loaded sound
long SoundFactory::loadSound(const std::string& filename)
{
	if (!soundIsWorking)
		return -1;
	std::string soundname("./data/sound/");  // Modify to where the sounds should be
	soundname += filename;

	std::map<std::string,unsigned>::iterator value  = sounds.find(soundname);
	if (value != sounds.end())
	{
		console << Console::normal << Console::high << soundname << " already loaded" << Console::endl();
		return (*value).second;
	}
	console << Console::normal << Console::high << "Attempting to load: " << soundname << Console::endl();
	if (loadOgg(soundname.c_str()))
	{
		return sounds[soundname];
	}
	else
	{
		console << Console::normal << Console::high << soundname << " was not loaded" << Console::endl();
		return -1;
	}
}

//! Adds a new source to the factory
unsigned int SoundFactory::newSource()
{
	if (!soundIsWorking)
		return 0;
	return sources++;
}

//! Attaches a sound and returns the source ID
long SoundFactory::attachSound(unsigned int sndNum)
{
	if (sndNum <0)
		return -1;
	source[sources-1] = sndNum;
	soundsources[sources-1].attachToSource(&(files[sndNum]), soundsources.size());
	return source[sources-1];
}

//! Plays a sound specified by a source ID
bool SoundFactory::playSource(unsigned int sourceNum)
{
	if (sourceNum < 0)
		return false;
	soundsources[sourceNum].play();
	return true;
}

bool SoundFactory::stopSource(unsigned int sourceNum)
{
	if (sourceNum < 0)
		return false;
	soundsources[sourceNum].stop();
	return true;
}

//! Moves the sound to a new
bool SoundFactory::moveSound(unsigned int srcNum, vector3f<GLfloat> position)
{
	if (srcNum < 0)
		return false;
	soundsources[srcNum].setPos(position);
	return true;
}

//! Removes the sound specified by the ID from the sound factory freeing up the memory in the process
bool SoundFactory::removeSound(unsigned int sndNum)
{
	return true;
}

//! Sets the attenuation of a source designated by srcNum
bool SoundFactory::setSourceAtten(unsigned int srcNum, float attenuation)
{
	if (srcNum < 0)
		return false;
	soundsources[srcNum].setAttenuation(attenuation);
	return true;
}

//! Sets the volume of a source designated by srcNum
bool SoundFactory::setSourceVol(unsigned int srcNum, float volume)
{
	if (srcNum < 0)
		return false;
	soundsources[srcNum].setVolume(volume);
	return true;
}

//! Set the source looping property
bool SoundFactory::setSourceLoop(unsigned int srcNum, bool looping)
{
	if (srcNum < 0)
		return false;
	soundsources[srcNum].setLooping(looping);
	return true;
}

//! Updates the buffers of all the sound sources
void SoundFactory::tick()
{
	if (soundIsWorking)
	{
		unsigned int i;
		for(i=0; i!=soundsources.size(); i++)
		{
			if (soundsources[i].isPlaying())
				soundsources[i].update();
		}
	}
}
