#include <stdio.h>
#include <math.h>

int main()
{
	FILE *fo;
	float i, test;

	fo=fopen("sintab.bin", "rb");
	for(i=0; i<360; i+=0.001)
	{
		fread(&test, sizeof(float), 1, fo);
		printf("sin(%f) = %f\n", i, test);
	}

	fclose (fo);
	return 0;
}
