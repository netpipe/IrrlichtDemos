#include "masterheader.h"
#include "azadi.h"
#include "console.h"


//! Global Console Object for printing Information
Console* console;


int main ( int argc, char** argv )
{
    console = new Console;

    Azadi game(argc,argv);



    return game.Run();
}




