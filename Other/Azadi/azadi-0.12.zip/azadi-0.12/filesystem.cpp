#include "filesystem.h"


fileSystem::fileSystem(char* filename,unsigned char flags)
{
    if(filename!=0)
        open(filename,flags);

};


/*! \brief Opens a file

 Access files in archives and dirs
 Use \ to access archivs, e.g data.zip\models/test.azm
 You can access archivs in archivs using data.zip\somedir/some.zip\somefile.amd
 Only relative paths yet (i don't see any reason why this should change --Ano)
 */
void fileSystem::open(char* filename,unsigned char flags)
{
    //! File inside a compressed file? (compressed files are accessed using \)
    //..
    //..
    // Not done yet

    #ifdef WIN32

    //! Convert any / back to \ for Windows
    for(int i=0;filename[i]!='\0';i++)
        if(filename[i] == '/')
            filename[i]='\\';

    #endif

    // Convert the flags to fstream flags
    unsigned char flg=0x00;;
    if(flags & APP)
        flg |= std::ios::app;
    if(flags & ATE)
        flg |= std::ios::ate;
    if(flags & BIN)
        flg |= std::ios::binary;
    if(flags & IN)
        flg |= std::ios::in;
    if(flags & OUT)
        flg |= std::ios::out;
    if(flags & TRUNC)
        flg |= std::ios::trunc;

    file.open(filename,(std::_Ios_Openmode)flg);

    valid = (file) ? true : false;
};



void fileSystem::read(char* buffer, unsigned int num)
{
    file.read(buffer,num);
}


void fileSystem::close(bool destroy)
{
    file.close();
    if(destroy)
        delete this;
}

int fileSystem::getFilesize()
{
    int oldpos = file.tellg(); // Save position
    file.seekg(0); // Jump to start
    int size=0;  // init size var
    while(file.peek() != EOF)
        size++; // get size

    file.seekg(oldpos); // jump to prev pos
    return size; // Return size
}



fileSystem::operator bool()
{
    return valid;
}


void fileSystem::openCompressed(char* filename,unsigned char flags)
{

};


