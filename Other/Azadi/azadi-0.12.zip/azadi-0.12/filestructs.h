#ifndef __FILESTRUCT
#define __FILESTRUCT


//! Struct of a Bone
struct fileBone
{
    float qRotate[4]; // Quaternion
    float vOffset[3]; // Vector
    float fLength; // of the Bone..
    int nJointType;
    int children[8];
    int Parent;
    float weight;
    char options;   // 0=CONNECTED 1=HINGE 2=CONNECTED+HINGE
    unsigned int id;
    unsigned int nameL; // amount of chars following this struct
};



//! Struct of the Bone we will actually work with
struct workingBone
{
    float qRotate[4]; // Quaternion
    float vOffset[3]; // Vector
    float fLength; // of the Bone..
    int nJointType;
    int children[8];
    int Parent;
    float weight;
    char options;   // 0=CONNECTED 1=HINGE 2=CONNECTED+HINGE
    unsigned int id;
    char * name; //name
};






//! Vertex Struct
struct fileVertex
{
    unsigned int id;
    float vPos[3]; // Vertex Position
};


//! Face Struct
struct fileFace
{
    unsigned int id;
    unsigned int normal;
    unsigned int numVertices; // how long the array of vertices is which will follow this struct
};


struct workingFace
{
    unsigned int id;
    unsigned int normal;
    unsigned int * vertices;
    unsigned int numVertices;
};



//! The vertex Group header struct
struct fileVertexGroup
{
    unsigned int id;
    unsigned int detailLevel;
    unsigned int boneID;
    unsigned int vertexL; // amount of ints following the name
};


//! This is the File Header
struct fileHeader
{
    unsigned int version;
    unsigned int numBones;
    unsigned int numVertices;
    unsigned int numFaces;
    unsigned int numGroups;
};


#endif
