#include "masterheader.h"
GLuint ListID;
const int Twidth=7;
const int MTWidth=24;
const int DTpn=5;

///////////////////// summary //////////
// well, basically you calculate all lod's for tiles... they remain that way and we are done.
// noise is recalculated for each tile on moves. lod noise fill
////////////////////////////////////////



class cTrainP{
public:
cTrainP();
int LOD;
int x,z; //bottom right start coords
//int roughness,material;
float Train[8][8];// extra row for smoothing
int nLOD[4];
};
cTrainP::cTrainP(){printf("s");};


class cTerrainDT{
public:
int x;
cTerrainDT();
vector<float> Vertex;
cTrainP Patch[16]; //4x4 tile from of 6x6
};
cTerrainDT::cTerrainDT(){printf("M");};

cTerrainDT TTile[4];
//cTerrainDT TTile[(MTWidth * MTWidth)];
//cTerrainDT *TTile = new cTerrainDT[100];



class Terrain
{
	public:
		void initialize();
		//void cTDraw();
		float Noise (int x, int z, int seed, int rough, int tzpe);
		void smoothNoise(int times, int LOD, int rough);
		void fillnoise(int seed,int smooth, int LOD,int rough,int tzpe,int TNum);
		//float GetHeight(int x,y,z);
		void DrawTerrainT(int LOD);
	private:
 
};
 


void Terrain::initialize(){
//seed, smooth, LOD, rough, tzpe, TNum
//Terrain->DrawTerrainT(1);
};



void Terrain::fillnoise(int seed,int smooth, int LOD,int rough,int tzpe,int TNum){
//srand(seed);

// we need to fill outer rim too rememmber
  for (int DTp = 0 ; DTp < 15 ; DTp+=1){
	for (int z = 0; z < 7; z+=LOD){
		for (int x = 0; x < Twidth; x+=LOD){
//seed = seed*(x+z+x*x) ;
			TTile[TNum].Patch[DTp].Train[x][z] += Noise(x,z,seed,rough,tzpe);
		}
	}
 }
//smoothNoise(smooth,LOD,1);
}


float Terrain::Noise(int x, int z,int seed,int rough, int tzpe){
 
	int n;
	n = x* z / rand() % 10 ;
	n = (n << 10);
	n = n * n / 1337073843;
	//if (n<0){n=0;} // Thold
	return ( n );
};
 
 
 
void Terrain::smoothNoise(int times, int LOD, int rough){
 for (int i=0; i < times; i++){
  for (int DTWidth = 1 ; DTWidth < 23 ; DTWidth+=1){ // DTile width loop the 
	for (int DTp = 0 ; DTp < 5 ; DTp+=1){
		for (int z = 1; z < 6 ; z+=LOD){
			for (int x = 1; x < 6; x+=LOD){
 
   				float corners = ( 
				TTile[DTWidth].Patch[DTp].Train[x-LOD][z-LOD]+
				TTile[DTWidth].Patch[DTp].Train[x+LOD][z-LOD]+
				TTile[DTWidth].Patch[DTp].Train[x-LOD][z+LOD]+
				TTile[DTWidth].Patch[DTp].Train[x+LOD][z+LOD] ) / 16;

				float sides = ( 
				TTile[DTWidth].Patch[DTp].Train[x-LOD][z]  +
				TTile[DTWidth].Patch[DTp].Train[x+LOD][z]  +
				TTile[DTWidth].Patch[DTp].Train[x][z-LOD]  +
				TTile[DTWidth].Patch[DTp].Train[x][z+LOD] ) /  8;

				float center = TTile[DTWidth].Patch[DTp].Train[x][z] / 4;
				TTile[DTWidth].Patch[DTp].Train[x][z] = (corners + sides + center);
			}
		}
	}
  }
 }
};


void Terrain::DrawTerrainT(int LOD)
{
LOD=2;
switch(LOD){

  case 1 : {

	for (int DTWidth = 0 ; DTWidth < 1 ; DTWidth+=1){
		TTile[DTWidth].x=DTWidth*20;
		int g=0;
		//TTile[DTWidth].Patch[DTp].x=y;
	 for (int DTp = 0 ; DTp < 16 ; DTp+=1){
		TTile[DTWidth].Patch[DTp].z=g;
	  for (int strip=0; strip < 24; strip+=6){
		TTile[DTWidth].Patch[DTp].x=strip;
	    for (int z = TTile[DTWidth].Patch[DTp].z; z < TTile[DTWidth].Patch[DTp].z+6; z+=1){
		int zp1= z+1;
	     for (int x = TTile[DTWidth].Patch[DTp].x; x < TTile[DTWidth].Patch[DTp].x+6; x+=1){
		int xp1= x+1;

	float xz=TTile[DTWidth].Patch[DTp].Train[x][z];
	float xzp1=TTile[DTWidth].Patch[DTp].Train[x][zp1];
	float xp1zp1=TTile[DTWidth].Patch[DTp].Train[xp1][zp1];
	float xp1z=TTile[DTWidth].Patch[DTp].Train[xp1][z];
//printf("%i",DTp);
		glBegin(GL_TRIANGLE_STRIP); 
				glColor3f(1, 1 , 1);
			glVertex3f(x, xz , z ); 
				glColor3f(1, xzp1, xzp1);
			glVertex3f(x, xzp1, zp1 );
				glColor3f(xp1zp1, xp1zp1, xp1zp1);
			glVertex3f(xp1, xp1zp1, zp1);
		glEnd();

		glBegin(GL_TRIANGLE_STRIP); 
				glColor3f(xz, xz, xz);
			glVertex3f(x, xz, z);
				glColor3f(xp1zp1, xp1zp1, xp1zp1);
			glVertex3f(xp1, xp1zp1, zp1);
				glColor3f(xp1z, xp1z, xp1z);
			glVertex3f(xp1, xp1z, z);
		glEnd();

}}}g=TTile[DTWidth].x+DTp+4;//im not yet sure why 4 works
}}
break;
}// end of case


  case 2 :{

	for (int DTWidth = 0 ; DTWidth < 3 ; DTWidth+=1){
		TTile[DTWidth].x=DTWidth*24;
		int g=0;
	 for (int DTp = 0 ; DTp < 16 ; DTp+=4){//every fn patch
//TTile[DTWidth].Patch[DTp].z=y;
TTile[DTWidth].Patch[DTp].z=g;
	  for (int strip=0; strip < 4; strip+=1){

		TTile[DTWidth].Patch[DTp].x=TTile[DTWidth].x+strip*6;//x location

	 glBegin(GL_TRIANGLE_FAN);
		glVertex3f( TTile[DTWidth].Patch[DTp].x+3,TTile[DTWidth].Patch[DTp].Train[3][3],TTile[DTWidth].Patch[DTp].z+3);
//bottom
glColor3f(0, 1, 1);
		glVertex3f( TTile[DTWidth].Patch[DTp].x+6,TTile[DTWidth].Patch[DTp].Train[6][6],TTile[DTWidth].Patch[DTp].z+6);
		 if (TTile[DTWidth].Patch[DTp].nLOD[0] > LOD){
			glVertex3f( TTile[DTWidth].Patch[DTp].x+6,TTile[DTWidth].Patch[DTp].Train[5][6],TTile[DTWidth].Patch[DTp].z+6);
			glVertex3f( TTile[DTWidth].Patch[DTp].x+4,TTile[DTWidth].Patch[DTp].Train[4][6],TTile[DTWidth].Patch[DTp].z+6);
		 }
		glVertex3f( TTile[DTWidth].Patch[DTp].x+3,TTile[DTWidth].Patch[DTp].Train[3][6],TTile[DTWidth].Patch[DTp].z+6);
		 if (TTile[DTWidth].Patch[DTp].nLOD[0] > LOD){
			glVertex3f( TTile[DTWidth].Patch[DTp].x+2,TTile[DTWidth].Patch[DTp].Train[2][6],TTile[DTWidth].Patch[DTp].z+6);
			glVertex3f( TTile[DTWidth].Patch[DTp].x+1,TTile[DTWidth].Patch[DTp].Train[1][6],TTile[DTWidth].Patch[DTp].z+6);
		 }
//left
		glVertex3f( TTile[DTWidth].Patch[DTp].x+0,TTile[DTWidth].Patch[DTp].Train[0][6],TTile[DTWidth].Patch[DTp].z+6);
		 if (TTile[DTWidth].Patch[DTp].nLOD[1] > LOD){
			glVertex3f( TTile[DTWidth].Patch[DTp].x+0,TTile[DTWidth].Patch[DTp].Train[0][5],TTile[DTWidth].Patch[DTp].z+5);
			glVertex3f( TTile[DTWidth].Patch[DTp].x+0,TTile[DTWidth].Patch[DTp].Train[0][4],TTile[DTWidth].Patch[DTp].z+4);
		 }
glColor3f(0, 1, 0);
		glVertex3f( TTile[DTWidth].Patch[DTp].x+0,TTile[DTWidth].Patch[DTp].Train[0][3],TTile[DTWidth].Patch[DTp].z+3);
		 if (TTile[DTWidth].Patch[DTp].nLOD[1] > LOD){
			glVertex3f( TTile[DTWidth].Patch[DTp].x+0,TTile[DTWidth].Patch[DTp].Train[0][2],TTile[DTWidth].Patch[DTp].z+2);
			glVertex3f( TTile[DTWidth].Patch[DTp].x+0,TTile[DTWidth].Patch[DTp].Train[0][1],TTile[DTWidth].Patch[DTp].z+1);
		 }
//top
		glVertex3f( TTile[DTWidth].Patch[DTp].x+0,TTile[DTWidth].Patch[DTp].Train[0][0],TTile[DTWidth].Patch[DTp].z+0);
		 if (TTile[DTWidth].Patch[DTp].nLOD[2] > LOD){
			glVertex3f( TTile[DTWidth].Patch[DTp].x+1,TTile[DTWidth].Patch[DTp].Train[1][0],TTile[DTWidth].Patch[DTp].z+0);
			glVertex3f( TTile[DTWidth].Patch[DTp].x+2,TTile[DTWidth].Patch[DTp].Train[2][0],TTile[DTWidth].Patch[DTp].z+0);
		 }
glColor3f(1, 1, 1);
		glVertex3f( TTile[DTWidth].Patch[DTp].x+3,TTile[DTWidth].Patch[DTp].Train[3][0],TTile[DTWidth].Patch[DTp].z+0);
		 if (TTile[DTWidth].Patch[DTp].nLOD[2] > LOD){
			glVertex3f( TTile[DTWidth].Patch[DTp].x+4,TTile[DTWidth].Patch[DTp].Train[4][0],TTile[DTWidth].Patch[DTp].z+0);
			glVertex3f( TTile[DTWidth].Patch[DTp].x+5,TTile[DTWidth].Patch[DTp].Train[5][0],TTile[DTWidth].Patch[DTp].z+0);
		 }
//right side
		glVertex3f( TTile[DTWidth].Patch[DTp].x+6,TTile[DTWidth].Patch[DTp].Train[6][0],TTile[DTWidth].Patch[DTp].z+0);
		 if (TTile[DTWidth].Patch[DTp].nLOD[3] > LOD){
			glVertex3f( TTile[DTWidth].Patch[DTp].x+6,TTile[DTWidth].Patch[DTp].Train[6][1],TTile[DTWidth].Patch[DTp].z+1);
			glVertex3f( TTile[DTWidth].Patch[DTp].x+6,TTile[DTWidth].Patch[DTp].Train[6][2],TTile[DTWidth].Patch[DTp].z+2);

		 }
		glVertex3f( TTile[DTWidth].Patch[DTp].x+6,TTile[DTWidth].Patch[DTp].Train[6][3],TTile[DTWidth].Patch[DTp].z+3);
		 if (TTile[DTWidth].Patch[DTp].nLOD[3] > LOD){
			glVertex3f( TTile[DTWidth].Patch[DTp].x+6,TTile[DTWidth].Patch[DTp].Train[6][4],TTile[DTWidth].Patch[DTp].z+4);
			glVertex3f( TTile[DTWidth].Patch[DTp].x+6,TTile[DTWidth].Patch[DTp].Train[6][5],TTile[DTWidth].Patch[DTp].z+5);
		 }
		glVertex3f( TTile[DTWidth].Patch[DTp].x+6,TTile[DTWidth].Patch[DTp].Train[6][6],TTile[DTWidth].Patch[DTp].z+6);
	 glEnd();
}g+=6;}}
break;
}

 case 3 : { 
	for (int DTWidth = 0 ; DTWidth < 3 ; DTWidth+=1){
		TTile[DTWidth].x=DTWidth*24;
		int g=0;
	 for (int DTp = 0 ; DTp < 16 ; DTp+=4){//every fn patch
//TTile[DTWidth].Patch[DTp].z=y;
TTile[DTWidth].Patch[DTp].z=g;
	  for (int strip=0; strip < 4; strip+=1){

		TTile[DTWidth].Patch[DTp].x=TTile[DTWidth].x+strip*6;//x location



	glBegin(GL_TRIANGLE_FAN);
glColor3f(0, 1, 0);
		glVertex3f( TTile[DTWidth].Patch[DTp].x+3,TTile[DTWidth].Patch[DTp].Train[3][3],TTile[DTWidth].Patch[DTp].z+3);
		glVertex3f( TTile[DTWidth].Patch[DTp].x+6,TTile[DTWidth].Patch[DTp].Train[6][6],TTile[DTWidth].Patch[DTp].z+6);

			if (TTile[DTWidth].Patch[DTp].nLOD[0] > LOD){
				glVertex3f( TTile[DTWidth].Patch[DTp].x+3,TTile[DTWidth].Patch[DTp].Train[3][6],TTile[DTWidth].Patch[DTp].z+6);
			} //bottom extra
glColor3f(1, 1, 0);
		glVertex3f( TTile[DTWidth].Patch[DTp].x+0,TTile[DTWidth].Patch[DTp].Train[0][6],TTile[DTWidth].Patch[DTp].z+6);

			if (TTile[DTWidth].Patch[DTp].nLOD[1] > LOD){
				glVertex3f( TTile[DTWidth].Patch[DTp].x+0,TTile[DTWidth].Patch[DTp].Train[0][3],TTile[DTWidth].Patch[DTp].z+3);
			} //left middle
glColor3f(0, 1, 1);
		glVertex3f( TTile[DTWidth].Patch[DTp].x+0,TTile[DTWidth].Patch[DTp].Train[0][0],TTile[DTWidth].Patch[DTp].z+0);

			if (TTile[DTWidth].Patch[DTp].nLOD[2] > LOD){
				glVertex3f( TTile[DTWidth].Patch[DTp].x+3,TTile[DTWidth].Patch[DTp].Train[3][0],TTile[DTWidth].Patch[DTp].z+0);
			} //middle top
glColor3f(1, 1, 0);
		glVertex3f( TTile[DTWidth].Patch[DTp].x+6,TTile[DTWidth].Patch[DTp].Train[6][0],TTile[DTWidth].Patch[DTp].z+0);

			if (TTile[DTWidth].Patch[DTp].nLOD[3] > LOD){
				glVertex3f(TTile[DTWidth].Patch[DTp].x+6,TTile[DTWidth].Patch[DTp].Train[6][3],TTile[DTWidth].Patch[DTp].z+3);
			} //right middle

		glVertex3f( TTile[DTWidth].Patch[DTp].x+6,TTile[DTWidth].Patch[DTp].Train[6][6],TTile[DTWidth].Patch[DTp].z+6);
	glEnd();
}g+=6;}}
 break;
}//endCase

}//End Switch
//glEndList();

}


