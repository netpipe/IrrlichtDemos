#ifndef __AZADI
#define __AZADI

#include "masterheader.h"
#include "model.h"
#include "vector.h"
#include "console.h"

#define PI 3.1415f






enum mov
{
    FORWARD=0,
    BACKWARD,
    LEFT,
    RIGHT
};




class Azadi
{
    public:
        Azadi(int argc, char** argv);
        int Run();
        void setConsoleObject(Console* cons);
    private:
        bool Init();
        bool Draw();
        void ProcessMessages();


        //! Screen size
        int screen[2];

        //! Window SDL-Handler
        SDL_Surface* window;

        //! Program done?
        bool done;

        //! Mouse position
        int mouse[2];

        //! Koordinates of the center
        int center[2];

        GLfloat CamPos[3];

        bool MoveKey[4];

        Model *modeldata;


};


#endif
