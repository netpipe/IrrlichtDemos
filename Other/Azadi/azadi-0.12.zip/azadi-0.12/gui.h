#ifndef __GUI
#define __GUI

#include "filesystem.h"
#include "stack"

class Gui
{
    public:
        Gui(char * menufile=0);
        void LoadMenu(char * menufile);
        void Draw();
    private:
        void parseMenu();
        bool findNextTag();
        void parseTag();

        int pos;
        int size;
        char* menudata;
        bool insideTag;
        std::stack<char *> tags;
};


#endif
