#ifndef __MODEL
#define __MODEL

#include "masterheader.h"
#include "filestructs.h"
#include "filesystem.h"





class Model
{
    public:
        Model(char * filename=0);
        bool LoadModel(char * filename);
        bool isValid(); //! Returns weather the data is accessible or not
        void Draw();

    protected:
        bool valid;

        bool drawSkeleton;  //! Draw the skelet or not
        bool drawMeshes;    //! Draw the meshes or not

        workingBone * bones;  //! Array of bones
        fileVertex * vertices;
        workingFace * faces;
        unsigned int numBones;
        unsigned int numVerts;
        unsigned int numFaces;

};

#endif
