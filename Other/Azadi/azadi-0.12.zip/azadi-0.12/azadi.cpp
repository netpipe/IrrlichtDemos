#include "azadi.h"
#include "terrain.h"
Terrain TP;
Azadi::Azadi(int argc, char** argv)
{
    modeldata = new Model;    modeldata->LoadModel("data.azm");

    screen[0]=640,screen[1]=480;

};



bool Azadi::Init()
{
    if ( SDL_Init( SDL_INIT_VIDEO ) < 0 )
    {
        printf( "Unable to init SDL: %s\n", SDL_GetError() );
        return false;
    }

    atexit(SDL_Quit);

    SDL_GL_SetAttribute( SDL_GL_RED_SIZE, 5 );
    SDL_GL_SetAttribute( SDL_GL_GREEN_SIZE, 5 );
    SDL_GL_SetAttribute( SDL_GL_BLUE_SIZE, 5 );
    SDL_GL_SetAttribute( SDL_GL_DEPTH_SIZE, 16 );
    SDL_GL_SetAttribute( SDL_GL_DOUBLEBUFFER, 1 );

    SDL_ShowCursor(SDL_DISABLE);

    center[0]=screen[0]/2;
    center[1]=screen[1]/2;

    CamPos[0]=0.0f;
    CamPos[1]=0.0f;
    CamPos[2]=0.0f;

    MoveKey[0]=false;
    MoveKey[1]=false;
    MoveKey[2]=false;
    MoveKey[3]=false;

    // create a new window
    window = SDL_SetVideoMode(screen[0], screen[1], 32,
                                           SDL_OPENGL);
    if ( !window )
    {
        printf("Unable to set %ix%i video: %s\n",screen[0],screen[1], SDL_GetError());
        return false;
    }

    // Nice Colorflow
    glShadeModel(GL_SMOOTH);
    glEnable(GL_DEPTH_TEST);

    glViewport (0, 0, (GLsizei) screen[0], (GLsizei) screen[1]);

//	glEnable(GL_CULL_FACE);
//	glCullFace(GL_BACK);
    return true;
}



int Azadi::Run()
{
    if(!Init())
        return 1;

    done = false;
    while (!done)
    {
        ProcessMessages();
        Draw();
        SDL_Delay(15);
    }

    return 0;
}



bool Azadi::Draw()
{
    //glFrustum (-1.0, 1.0, -1.0, 1.0, 1.5, 20.0);
    //glFrustum(0,width,0,height,1.0,1.0);
    //glFrustum( GLdouble left, GLdouble right, GLdouble bottom, GLdouble top, GLdouble near, GLdouble far )

    glMatrixMode (GL_PROJECTION);
    glLoadIdentity ();
    gluPerspective(60, screen[0]/screen[1], 0.1, 200);

    GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 }; GLfloat mat_shininess[] = { 50.0 };

    GLfloat light_position[] = {0.0, 1.5 ,-2.0, 1};

    glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, 2.0);
    glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, 1.0);
    glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, 0.5);


    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
/* */
    glMatrixMode (GL_MODELVIEW);
    glLoadIdentity ();

    //! Setup Cam
    // Rotation Vars
    static float ix=0;
    static float iy=0;

    vector<GLfloat> forward;
    vector<GLfloat> side;

    //Keep the angles small
    while(iy>360)
        iy-=360;

    while(iy<0)
        iy+=360;

    while(ix>360)
        ix-=360;

    while(ix<0)
        ix+=360;

    //! <Cheery>s calcs
    float Xangle = iy/180*PI;
    float Yangle = ix/180*PI;

    forward.Y = -sin(Xangle);
    forward.X = cos(Xangle)*sin(Yangle);
    forward.Z = cos(Xangle)*-cos(Yangle);

    forward.Normalize();


    char buf[100];
    sprintf( buf,"X:%f Y:%f Z:%f iy:%f ix:%f ",forward.X,forward.Y,forward.Z,iy,ix );
    SDL_WM_SetCaption(buf, NULL);

    side=forward.normcrossprod(vector<GLfloat> (0.0f,1.0f,0.0f));

    if(MoveKey[FORWARD])
    {
        CamPos[0]-=forward.X*0.1;
        CamPos[1]-=forward.Y*0.1;
        CamPos[2]-=forward.Z*0.1;
    }
    if(MoveKey[BACKWARD])
    {
        CamPos[0]+=forward.X*0.1;
        CamPos[1]+=forward.Y*0.1;
        CamPos[2]+=forward.Z*0.1;
    }
    if(MoveKey[LEFT])
    {
        CamPos[0]+=side.X*0.1;
        CamPos[1]+=side.Y*0.1;
        CamPos[2]+=side.Z*0.1;
    }
    if(MoveKey[RIGHT])
    {
        CamPos[0]-=side.X*0.1;
        CamPos[1]-=side.Y*0.1;
        CamPos[2]-=side.Z*0.1;
    }


    iy-=(center[1]-mouse[1])*0.1;
    ix-=(center[0]-mouse[0])*0.1;

    // We DO need light !

//    glEnable(GL_LIGHT0);


    // Move the cam
    glRotatef(iy,1,0,0);
    glRotatef(ix,0,1,0);
    glTranslatef(CamPos[0],CamPos[1],CamPos[2]);


    // Center Mouse after each movment
    SDL_WarpMouse(center[0],center[1]);
    //! Cam SetUp End
    glClearColor (0.0, 0.0, 0.0, 0.0);
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );


    //! 3 achses
    glBegin(GL_LINES);
        glColor3f(0.0,0.0,1.0);
        glVertex3f(0.0,0.0,0.0);
        glVertex3f(0.0,0.0,20.0);

        glColor3f(1.0,0.0,0.0);
        glVertex3f(0.0,0.0,0.0);
        glVertex3f(0.0,20.0,0.0);

        glColor3f(0.0,1.0,0.0);
        glVertex3f(0.0,0.0,0.0);
        glVertex3f(20.0,0.0,0.0);

        glColor3f(1.0,1.0,1.0);
        glVertex3f(-3,1.0,0.0);
        glVertex3f(3,1.0,0.0);

        glColor3f(1.0,1.0,1.0);
        glVertex3f(1,-3.0,0.0);
        glVertex3f(1,3.0,0.0);
    glEnd();								///glCallList(ListID);

//    glEnable(GL_LIGHTING);					//seed, smooth, LOD, rough, tzpe, TNum
						//TP.fillnoise(123,1,1,1,1,1);
							TP.DrawTerrainT(1);
  modeldata->Draw();
//    glDisable(GL_LIGHTING);

    //! Menu drawing starts here
    glMatrixMode (GL_PROJECTION);
    glLoadIdentity ();
    glOrtho( 0, screen[0],screen[1], 0, 0, 1 );
    //gluOrtho2D (0.0, (GLdouble) screen[0], 0.0, (GLdouble) screen[1]);

    glMatrixMode (GL_MODELVIEW);
    glLoadIdentity ();

    glBegin(GL_POLYGON);
        glColor4f(1.0,1.0,0.0,0.5);
        glVertex2d(20,20);
        glVertex2d(200,20);
        glVertex2d(mouse[0]/3,mouse[1]/3);
        glVertex2d(20,200);
        glVertex2d(20,20);
    glEnd();



    glFlush();

    SDL_GL_SwapBuffers( );

    return true;
};





/*! \brief Processes the messages
 */
void Azadi::ProcessMessages()
{
     // message processing loop
    SDL_Event event;
    while (SDL_PollEvent(&event))
    {
        // check for messages
        switch (event.type)
        {
                // exit if the window is closed
            case SDL_QUIT:
                done = true;
                break;

                // check for keypresses
            case SDL_KEYDOWN:
                {
                    // exit if ESCAPE is pressed
                    if (event.key.keysym.sym == SDLK_ESCAPE)
                        done = true;

                    //! Temp Soloution to enable us moving
                    if (event.key.keysym.sym == SDLK_w)
                        MoveKey[FORWARD]=true;
                    if (event.key.keysym.sym == SDLK_s)
                        MoveKey[BACKWARD]=true;
                    if (event.key.keysym.sym == SDLK_a)
                        MoveKey[LEFT]=true;
                    if (event.key.keysym.sym == SDLK_d)
                        MoveKey[RIGHT]=true;

                    break;
                }
            case SDL_KEYUP:
                {

                     //! Temp Soloution to enable us moving
                    if (event.key.keysym.sym == SDLK_w)
                        MoveKey[FORWARD]=false;
                    if (event.key.keysym.sym == SDLK_s)
                        MoveKey[BACKWARD]=false;
                    if (event.key.keysym.sym == SDLK_a)
                        MoveKey[LEFT]=false;
                    if (event.key.keysym.sym == SDLK_d)
                        MoveKey[RIGHT]=false;
                   break;
                }
            case SDL_VIDEORESIZE:
                {
                   //    glViewport (0, 0, (GLsizei) event.resize.w, (GLsizei) event.resize.h);
                  //     glMatrixMode (GL_PROJECTION);
                 //      glLoadIdentity ();
                //       gluOrtho2D (0.0, (GLdouble) event.resize.h, 0.0, (GLdouble) event.resize.h);
                    break;
                }
            case SDL_MOUSEMOTION:
                {
                    mouse[0]=event.motion.x ;
                    mouse[1]=event.motion.y ;
                    break;
                }
            case SDL_MOUSEBUTTONDOWN:
                {


                    break;
                }
            case SDL_MOUSEBUTTONUP:
                {

                    break;
                }


        } // end switch
    } // end of message processing
};
