#!BPY

"""
Name: 'Azadi Exporter'
Blender: 242
Group: 'Export'
Tip: 'Exports animation, mesh and bone data to Azadis Modelformat'
"""

__version__ = "0.2"
__author__  = "Mathias L. Baumann"
__email__   = "anonym001@supradigital.org"
__url__     = "http://supradigital.org"


# Struct Module
from struct import *


#Blender things
import Blender
from Blender import Armature, Mesh, Window
from Blender.Mathutils import *




bones = list()
vertices = list()
vertexGroups = list()
faces = list()



class face:
    def __init__(self):
        self.ID = int(-1)
        self.normal = int(-1)
        self.Vertices = list()
        self.packed = str()

    def prepare(self):
        tmp = list()
        tmp.append(self.ID)
        tmp.append(self.normal)
        tmp.append(len(self.Vertices))
        tmp.extend(self.Vertices)
        print "face: ",tmp
        self.packed = pack ("III"+str(len(self.Vertices))+"I",*tmp) 





class VertexGroup:
    def __init__(self):
        self.vertices = list()
        self.detailsm = int(-1)
        self.boneID = int(-1)
        self.ID = int(-1)
        self.packed = 0
        self.name = str()

    def prepare(self):
        tmp = list()
        tmp.append(self.ID)
        tmp.append(self.detailsm)
        tmp.append(self.boneID)
        tmp.append(int(len(self.vertices)))
        tmp.extend(self.vertices)        
        self.packed = pack("IIII"+str(len(self.vertices))+"I",*tmp)
              



class Vertex:
    def __init__(self):
        self.x=float(0)
        self.y=float(0)
        self.z=float(0)
        self.id=int(0)
        self.packed = 0
        
    def prepare(self):        
        tmp = list()
        tmp.append(self.id)
        tmp.append(self.x)
        tmp.append(self.y)
        tmp.append(self.z)        
        self.packed = pack("Ifff",*tmp)
        

#### BONE STUFF


class Bone:
    def __init__(self):   
        self.ID = int(-1)
        self.fRotation= list() # Quaternion (4 floats)
        self.fOffset  = list() # Vector (3 Floats)
        self.qRotation = 0
        self.vOffset   = 0
        self.fLength  = float(0)
        self.jType   = int(0)
        self.iChildren = list() # Integer List
        self.sChildren = list()
        self.iParent   = int(0)
        self.sParent   = str()
        self.fWeight   = float(0)
        self.name    = str()
        self.packed = str()
        self.options = -1
        self.vergrpID = int(-1)

    # Prepares the Bone to get written to file
    def prepare(self):
        self.fRotation=[self.qRotation.angle,self.qRotation.x,self.qRotation.y,self.qRotation.z]
        self.fOffset  =[self.vOffset.x,self.vOffset.y,self.vOffset.z]
        tmp = self.fRotation
        tmp.extend(self.fOffset)
        tmp.append(self.fLength)
        tmp.append(self.jType)
        tmp.extend(self.iChildren)
        tmp.append(self.iParent)
        tmp.append(self.fWeight)
        tmp.append(self.options)
        tmp.append(self.ID)
        tmp.append(len(self.name))
        tmp.append(self.name)
        self.packed = pack("4f 3f f i 8i i f b i i"+str(len(self.name))+"s",*tmp)

    # Prints all Info for debugging
    def echo(self):
        print "ID: ",self.ID
        print "##Name: ",self.name
        print "##Quaternion: ",[self.qRotation.angle,self.qRotation.x,self.qRotation.y,self.qRotation.z]
        print "##Offset Vector: ",[self.vOffset.x,self.vOffset.y,self.vOffset.z]
        print "##Length: ",self.fLength
        print "##Joint Types: ",self.jType
        print "##Childrens IDs: ",self.iChildren
        print "##Parent ID: ",self.iParent
        print "##Options: ",self.options
        print "##VertexGroup: ",self.vergrpID        
        print "\n"

    # Gets the IDs for parent, childrens and vertexGroup
    def getIDs(self):
        self.iChildren = list()
        self.iParent =int(-1)
        for bb in bones:
            if bb.name == self.sParent:
                self.iParent = bb.ID
            for ch in self.sChildren:
                if bb.name == ch:
                    self.iChildren.append(bb.ID)

        while len(self.iChildren) < 8:
            self.iChildren.append(-1) # It have to be 8

        for grp in vertexGroups:
            if grp.name == self.name:
                grp.boneID = self.ID              



## Adds the bone to the list
def processBone(pbone):
    print "Processing bone ",pbone.name 
    tmp = Bone()
    tmp.ID = len(bones)
    tmp.qRotation = pbone.matrix['ARMATURESPACE'].toQuat()
    tmp.vOffset =   pbone.matrix['ARMATURESPACE'].translationPart()       
    tmp.fWeight = pbone.weight
    tmp.name    = pbone.name         
    tmp.fLength  = pbone.length
    
    # Setting the Options ( we need only HINGE and CONNECTED)
    con=False
    hing=False
    for opt in pbone.options:
        if opt == Armature.CONNECTED:
            con=True
        if opt == Armature.HINGE:
            hing=True

    if con and hing:
        tmp.options=int(2)
    elif con:
        tmp.options=int(0)
    else:
        tmp.options=int(1)
        
    tmp.sChildren = list()    #Reset Childrens
    if pbone.children:
        for pchild in pbone.children:
            if len(tmp.sChildren) > 8:
                 exit("Not more then 8 Children are possible!!")   
            tmp.sChildren.append(pchild.name) # Add the Name of every Child
           
    if(bone.parent):
        tmp.sParent = bone.parent.name
    else:
        tmp.sParent = str()
       
    bones.append(tmp)
    tmp = 0  # Paraniod


###################################################
##  The Functions, Classes and globals end here  ##
###################################################





Window.EditMode(0) # leave edit mode before getting the mesh


objects = Blender.Scene.GetCurrent().getChildren()
for obj in objects:
    if obj.getType() == 'Armature':
        #add Bones
        for bone in obj.getData().bones.values():
            processBone(bone)
    if obj.getType() == 'Mesh':
        # Add vertex groups
        for grpname in obj.getData(False,True).getVertGroupNames():
            verts = list() #vertices in this group
            meshverts  = obj.getData(False,True).verts
            for vertex in obj.getData(False,True).getVertsFromGroup(grpname, False):
                
                #first we check if we got already a vertex with this coordiantes
                got_it = False
                for savedvertex in vertices:
                    if meshverts[vertex].co.x == savedvertex.x and meshverts[vertex].co.y == savedvertex.y and meshverts[vertex].co.y == savedvertex.y:
                        #we got this vertex already
                        verts.append(savedvertex.id)
                        got_it = True

                if got_it == False: #we havent got it?
                    # add it.
                    newvertex = Vertex()
                    newvertex.x = meshverts[vertex].co.x
                    newvertex.y = meshverts[vertex].co.y
                    newvertex.z = meshverts[vertex].co.z
                    newvertex.id = len(vertices)
                    vertices.append(newvertex)
                    # and also add it to the list of our vertex group
                    verts.append(newvertex.id)

            # all vertices of the group are now in verts, so lets create the group and add it
            grp = VertexGroup()
            grp.ID = len(vertexGroups)
            grp.name = grpname
            grp.vertices = verts
            grp.detailsm = int(obj.layers[0])
            vertexGroups.append(grp)
            
        # Add faces
        for faceElement in obj.getData(False,True).faces:
            tmpface = face()
            tmpface.ID = len(faces)
            normal_written = False
            for savedvertex in vertices:
                # check for normal                
                if faceElement.no.x == savedvertex.x and faceElement.no.y == savedvertex.y and faceElement.no.y == savedvertex.y:
                    tmpface.normal = savedvertex.id
                    normal_written = True
                    print "Found normal: ",savedvertex.id
                # add the vertices to the index
                for edge in faceElement.verts:
                    if edge.co.x == savedvertex.x and edge.co.y == savedvertex.y and edge.co.y == savedvertex.y:
                        print "Found edge: ",savedvertex.id
                        tmpface.Vertices.append(savedvertex.id)

            
            if normal_written == False: # Not writteN?
                norm = Vertex() #than we need to add it
                norm.id = len(vertices)
                norm.x = faceElement.no.x
                norm.y = faceElement.no.y
                norm.z = faceElement.no.z
                vertices.append(norm)                
                tmpface.normal = norm.id
                
            faces.append(tmpface)
            
            
 
# we need to translate the parent and Children names to IDs
for bone in bones:
    bone.getIDs()
    bone.echo()
    bone.prepare() # we will write them soon




# Struct of header
version= int(2)
numBones=int(len(bones))
numVertices = len(vertices)
numFaces = len(faces)
numGroups = len(vertexGroups)
head = pack("IIIII",version,numBones,numVertices,numFaces,numGroups)




def save(filename):
    fhandler=file(filename,"wb")    
    fhandler.write(head)
    for bone in bones:
        fhandler.write(bone.packed)

    for vert in vertices:
        vert.prepare()
        fhandler.write(vert.packed)

    for face in faces:
        face.prepare()
        fhandler.write(face.packed)

    for grp in vertexGroups:
        grp.prepare()
        fhandler.write(grp.packed)
        
    fhandler.close()




Blender.Window.FileSelector (save, 'Export Bones, Vertices, VertexGroups and Faces',"data.azm")
