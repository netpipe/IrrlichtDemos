#include "masterheader.h"
GLuint ListID;

float Train[30][30];

double Noise(int x, int y){
	int n;
	n = x * y * 2;
	n = (n << 10)^n;
	n = n * n / 1337073843;
	//if (n<0){n=0;} // Thold
    return ( n );
};

double smoothNoise(int x,int y){
    double corners = ( Noise(x-1, y-1)+Noise(x+1, y-1)+Noise(x-1, y+1)+Noise(x+1, y+1) ) / 16;
    double sides   = ( Noise(x-1, y)  +Noise(x+1, y)  +Noise(x, y-1)  +Noise(x, y+1) ) /  8;
    double center  =  Noise(x, y) / 4;
    return (corners + sides + center);
};

inline void fillnoise(){
	for (int z = 1; z < 30; z+=1){
		for (int x = 1; x < 30; x++){ 
			Train[x][z] = smoothNoise(x,z);
		}
	}

}


inline float GetHeight(int x, int z){
 //file = fopen( FName , "rb");
int AmplitudeMultiplier=4;
float fFrequency=0.0167;
//return(  AmplitudeMultiplier*  sin( (x)*(z - cos(x*z))*fFrequency));
//return ( smoothNoise(x,z)*7 );
return ( Train[x][z] * 8 );
}



inline void CreateList()
{
	ListID = glGenLists(1);
	glNewList(ListID, GL_COMPILE);		
	for (int z = 1; z < 30; z+=1){
		for (int x = 1; x < 30; x++){ 
			int zp1= z+1;
			int xp1= x+1;
float xz=GetHeight(x,z);
float xzp1=GetHeight(x,(zp1));
float xp1zp1=GetHeight((xp1),(zp1));
float xp1z=GetHeight((xp1),z);
// use this for less monkeying
//float xz=Train[x][z];
//float xzp1=Train[x][zp1];
//float xp1zp1=Train[xp1][zp1];
//float xp1z=Train[xp1][z];

		glBegin(GL_TRIANGLE_STRIP); 
				glColor3f(xz, xz, xz);
			glVertex3f(x, xz , z ); 
				glColor3f(xzp1, xzp1, xzp1);
			glVertex3f(x, xzp1, zp1 );
				glColor3f(xp1zp1, xp1zp1, xp1zp1);
			glVertex3f(xp1, xp1zp1, zp1);
		glEnd();

		glBegin(GL_TRIANGLE_STRIP); 
				glColor3f(xz, xz, 1);
			glVertex3f(x, xz, z);
				glColor3f(xp1zp1, xp1zp1, xp1zp1);
			glVertex3f(xp1, xp1zp1, zp1);
				glColor3f(xp1z, xp1z, xp1z);
			glVertex3f(xp1, xp1z, z);
		glEnd();
	
		}
	}
glEndList();
}
