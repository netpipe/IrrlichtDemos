#ifndef __CONSOLE
#define __CONSOLE
#include "masterheader.h"



class Console
{
    public:
        void echoMessage(char* Message);
    private:
};

#endif
