#include "masterheader.h"

template<class T>
class vector
{
    public:
        vector(T x=0,T y=0,T z=0)
        {
            this->X=x;
            this->Y=y;
            this->Z=z;
        };


        T length()
        {
            T t = sqrt((this->X*this->X) + (this->Y*this->Y) + (this->Z*this->Z));
            return t;
        };


        void Normalize()
        {
            T l=length();
            if(l != 0)
            {
                this->X /= l;
                this->Y /= l;
                this->Z /= l;
            }else
                printf("Warning, length is 0!\n");
        };



        vector<T> operator*(T rhs)
        {
            vector<T> tmp(this->X,this->Y,this->Z);

            tmp.X,tmp.Y,tmp.Z *= rhs;
            return tmp;
        };


        //! crossproduct
        vector<T> crossproduct(vector<T> bb)
        {
            vector<T> cc;
            cc.X= this->Y*bb.Z - this->Z*bb.Y;
            cc.Y= this->Z*bb.X - this->X*bb.Z;
            cc.Z= this->X*bb.Y - this->Y*bb.X;
            return cc;
        };


        vector<T> normcrossprod(vector<T> bb)
        {
             vector<T> tmp = crossproduct(bb);
             tmp.Normalize();
             return tmp;
        };

        vector<T> operator-(vector<T> rhs)
        {
            vector<T> tmp(this->X,this->Y,this->Z);
            //tmp.print();
            printf("Sub\n");
            //rhs.print();
            tmp.X-=rhs.X;
            tmp.Y-=rhs.Y;
            tmp.Z-=rhs.Z;
            return tmp;
        };

        vector<T> operator+(vector<T> rhs)
        {
            vector<T> tmp(this->X,this->Y,this->Z);
            tmp.print();
            printf("Add\n");
            rhs.print();
            tmp.X+=rhs.X;
            tmp.Y+=rhs.Y;
            tmp.Z+=rhs.Z;
            return tmp;
        };

        //! Dotproduct
        T dotproduct(vector<T> rhs)
        {
           return (this->X*rhs->X + this->Y*rhs->Y + this->Z*rhs->Z);
        }

        void getArray(T *array[])
        {
            array=new T[3];
            *array[0]=X;
            *array[1]=Y;
            *array[2]=Z;
        }

        void print()
        {
            printf("%i: %f | %f | %f \n",this,X,Y,Z);
        }

        T X,Y,Z;

};


/*
void normalize(float v[3]) {
   GLfloat d = sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);
   if (d == 0.0) {
      printf("zero length vector",stderr);
      return;
   }
   v[0] /= d; v[1] /= d; v[2] /= d;
}

void normcrossprod(float v1[3], float v2[3], float out[3])
{
   GLint i, j;
   GLfloat length;

   out[0] = v1[1]*v2[2] - v1[2]*v2[1];
   out[1] = v1[2]*v2[0] - v1[0]*v2[2];
   out[2] = v1[0]*v2[1] - v1[1]*v2[0];
   normalize(out);
}
*/



