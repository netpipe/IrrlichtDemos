#include "gui.h"


Gui::Gui(char * menufile)
:tags()
{
    if( menufile != 0 )
        LoadMenu(menufile);

}


void Gui::LoadMenu(char * menufile)
{
    fileSystem menuf(menufile);
    size=menuf.getFilesize();
    menudata = new char[size];

    menuf.read(menudata,size);

    pos=0;
    insideTag=false;

    parseMenu();
}

//!
void Gui::parseMenu()
{
    for(;pos < size;pos++)
    {
        if(!findNextTag()) // Jump to the next tag
            return;


    }
}



bool Gui::findNextTag()
{
    for(;pos < size;pos++)
        if(menudata[pos] == '<') // We found a new start
            return true;
    return false; // no more tags
}



void Gui::parseTag()
{
    // Find name of the Tag
//    start=pos;
 //   end=0;
    //! Change this! You can access and check pos the same time!
    //this is a parse error so you notice this!

 //   while(menudata[pos] != ' ' && pos < size && menudata[pos] !=)
   //     end++;


 //   char * tmpname = new char[end-pos];

}
