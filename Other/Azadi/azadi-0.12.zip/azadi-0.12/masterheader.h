#ifndef __MASTERHEADER
    #define __MASTERHEADER

    #include <SDL/SDL.h>
    #include <GL/gl.h>
    #include <GL/glu.h>
    #include <math.h>
    #include <cstdlib>
#endif

