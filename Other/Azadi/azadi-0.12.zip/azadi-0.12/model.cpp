#include "model.h"



/*! \brief Loads Model Data if name provided
 */
Model::Model(char * filename)
{
    drawSkeleton=true;
    if(filename != 0)
        LoadModel(filename);
};


bool Model::LoadModel(char * filename)
{
    //! Inputfile Object
    fileSystem file;
    file.open(filename,BIN | IN);

    if(!file)
    {
        valid=false;
        return false;
    }
    else
        valid=true;

    //! Create File Header Object
    fileHeader header;

    //! Read Header from file
    file.read( (char*)&header, sizeof(header));

    //! Check for correct file version.
    if(header.version != 2)
    {
        valid=false;
        return false;
    }


    numBones= header.numBones;
    //! Create an array for the bones
    if(header.numBones > 0)
    {
        bones = new workingBone[header.numBones];



        fileBone *tmpbone = new fileBone;

        //! Read all bones
        for(unsigned int i=0;i < header.numBones;i++)
        {
            // Read fileBone struct
            file.read((char*)tmpbone, sizeof(fileBone));
            // Put information in workingBone struct
            memcpy(bones[i].children,tmpbone->children,8*sizeof(int));
            bones[i].fLength    = tmpbone->fLength;
            bones[i].id         = tmpbone->id;
            bones[i].nJointType = tmpbone->nJointType;
            bones[i].options    = tmpbone->options;
            bones[i].Parent     = tmpbone->Parent;

            memcpy(bones[i].qRotate,tmpbone->qRotate,4*sizeof(float));
            memcpy(bones[i].vOffset,tmpbone->vOffset,3*sizeof(float));
            bones[i].weight     = tmpbone->weight;
            bones[i].name       = new char[tmpbone->nameL];
            // now read the name
            file.read(bones[i].name,tmpbone->nameL);

            printf("Name: %s\nqRotate: %f %f %f %f\nvOffset: %f %f %f\n",bones[i].name, bones[i].qRotate[0],
                                                                                        bones[i].qRotate[1],
                                                                                        bones[i].qRotate[2],
                                                                                        bones[i].qRotate[3],
                                                                                        bones[i].vOffset[0],
                                                                                        bones[i].vOffset[1],
                                                                                        bones[i].vOffset[2]);

        }
        delete tmpbone;
    }

    numVerts = header.numVertices;
    if(header.numVertices > 0)
    {
        vertices = new fileVertex[header.numVertices];


        for (unsigned int i =0; i < numVerts;i++)
        {
            file.read((char*) vertices+sizeof(fileVertex)*i,sizeof(fileVertex));
            printf("Vertex %i(%i) : %f %f %f\n",vertices[i].id,i,vertices[i].vPos[0],vertices[i].vPos[1],vertices[i].vPos[2]);
        }

    }

    numFaces = header.numFaces;
    printf("Numfaces: %u",numFaces);
    if(header.numFaces > 0)
    {
        faces = new workingFace[header.numFaces];
        numFaces = header.numFaces;

        fileFace* tmpface = new fileFace;

        for( unsigned int i=0; i < numFaces;i++)
        {
            file.read((char*) tmpface,sizeof(fileFace));
            faces[i].id = tmpface->id;
            faces[i].normal = tmpface->normal;
            faces[i].numVertices = tmpface->numVertices;
            if(tmpface->numVertices > 0)
            {
                printf("Id: %u, normal: %u Numverts: %u\n",tmpface->id,tmpface->normal,tmpface->numVertices);
                faces[i].vertices = new unsigned int[tmpface->numVertices];
                file.read((char*) faces[i].vertices,tmpface->numVertices*sizeof(unsigned int));
            }
        }

    }

    file.close();
    return true;
};


void Model::Draw()
{

    if(drawSkeleton && valid)
    {
        for(unsigned int i=0; i < numBones;i++)
        {
            glPushMatrix(); // Save the Matrix

            glTranslatef(bones[i].vOffset[0],bones[i].vOffset[1],bones[i].vOffset[2]);
            glRotatef(bones[i].qRotate[0],bones[i].qRotate[1],bones[i].qRotate[2],bones[i].qRotate[3]);

            glBegin(GL_LINES);
                glColor3f(1.0,1.0,0.0);
                glVertex3f(0 ,0,0);
                glVertex3f(0 ,bones[i].fLength,0);
            glEnd();
           glPopMatrix();
        }
        for(unsigned int i=0; i < numVerts;i++)
        {
            glPushMatrix(); // Save the Matrix
            glBegin(GL_POINTS);
                glVertex3f(vertices[i].vPos[0],vertices[i].vPos[1],vertices[i].vPos[2]);
            glEnd();
            glPopMatrix();
        }
        glColor3f(1.0,0.5,0.0);
        for (unsigned int i=0; i < numFaces;i++)
        {
            glPushMatrix(); // Save the Matrix
                glBegin(GL_POLYGON);

                if( faces[i].normal < numVerts)
                    glNormal3fv(vertices[faces[i].normal].vPos);

                for(unsigned int vi=0; vi < faces[i].numVertices;vi++)
                    if( faces[i].vertices[vi] < numVerts)
                        glVertex3fv(vertices[faces[i].vertices[vi]].vPos);

                glEnd();
            glPopMatrix();
        }
    }

};

