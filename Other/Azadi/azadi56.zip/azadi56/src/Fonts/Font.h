#ifndef FONT_H
#define FONT_H

#include <map>
#include <vector>
#include <cassert>

#ifdef __OSX__
#include <OpenGL/gl.h>
#else
#include <GL/gl.h>
#endif

#include "ft2build.h"
#include FT_FREETYPE_H
#include FT_GLYPH_H

typedef struct fontSet
{
    FT_Face face;
    std::map<unsigned int, std::vector<GLuint> > displayList;
    std::map<unsigned int, std::vector<long> > advancex;
    std::map<unsigned int, std::vector<long> > bearingx;
    std::map<unsigned int, std::vector<long> > bearingy;
    std::map<unsigned int, std::vector<GLfloat> > x;
    std::map<unsigned int, std::vector<GLfloat> > y;
    std::map<unsigned int, std::vector<int> > tops;
    std::map<unsigned int, long > height;
};

class Font
{
	public:
		Font();
		~Font();
		void drawText(const std::string&, const std::string& font, float pt);
		void drawText(float, const std::string& font, float pt);
		void drawText(int, const std::string& font, float pt);
		void loadFont(const std::string&);
		void genPointSize(std::string font, unsigned int size);
	private:
        FT_Library library;
        std::map<std::string, fontSet> faces;
        std::map<std::string, std::vector<unsigned int> > loadedSizes;
        char alphabet[94];
};

extern Font text_engine;

#endif
