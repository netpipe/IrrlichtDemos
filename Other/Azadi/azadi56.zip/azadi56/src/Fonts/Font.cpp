#include "Font.h"
#include "../GUI/Console.h"
#include "../GUI/Drawing.h"

using GUI::Console;

inline unsigned int next_p2(unsigned int x)
{
    unsigned int res = 1;
    while(res<x) res*=2;
    return res;
}

Font::Font()
{
    bool ret;
    ret = FT_Init_FreeType(&library);
    if (ret)
    {
        console << Console::error << Console::highish << "Error initializing the Freetype library" << Console::endl();
        assert(!ret);
    }
    else
    {
        #ifndef NDEBUG
        console << Console::normal << Console::highish << "Initializing Font engine" << Console::endl();
        #endif
    }
    
    // loads the alphabet array with the printable alphanumeric characters
    for (int i=32; i< 126; i++)
        alphabet[i-32] = i;
}

Font::~Font()
{
    
}

void Font::loadFont(const std::string& fontname)
{
    std::string fontName("./data/Fonts/");
    
    
    fontName += fontname;
    
    std::map<std::string, fontSet>::iterator val = faces.find(fontname);
    if (val != faces.end())
        return;
    
    #ifndef NDEBUG
    console << Console::log << Console::highish << "TextEngine->Loading : " << fontName << Console::endl();
    #endif
    
    int ret;
    
    fontSet tempo;
    
    ret = FT_New_Face( library, fontName.c_str(), 0, &tempo.face);
    if (ret)
    {
        console << Console::error << Console::highish << "TextEngine->Font " << fontname << " could not be loaded" << Console::endl();
        assert(!ret);
    }
    faces[fontname] = tempo;
    #ifndef NDEBUG
    console << Console::log << Console::highish << "TextEngine->" << fontname << " loaded" << Console::endl();
    #endif
}

void Font::drawText(const std::string& text, const std::string& font, float pt)
{
    float accTrans = 0;
    float advance;
    bool kern;
    unsigned int old_glyph;
    unsigned int cur_glyph;
    
    glDisable(GL_CULL_FACE);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glPushMatrix();
    
    kern = FT_HAS_KERNING(faces[font].face);
    
    for(unsigned int i=0; i< text.size(); i++)
    {
        if (text[i] == '\n')
        {
            glTranslatef(-accTrans, (float)faces[font].height[(int)pt], 0);
            accTrans = 0;
            continue;
        }
        else if ((text[i] - 32) != 0)
        {
            glCallList(faces[font].displayList[(int)pt][text[i]-32]);
        }
        if (kern && i>0)
        {
            old_glyph = FT_Get_Char_Index(faces[font].face, text[i-1]);
            cur_glyph = FT_Get_Char_Index(faces[font].face, text[i]);
            FT_Vector newPos;
            FT_Get_Kerning(faces[font].face, old_glyph, cur_glyph, ft_kerning_default, &newPos);
            advance = (faces[font].advancex[(int)pt][text[i]-32]/64)-(faces[font].bearingx[(int)pt][text[i]-32]/64)+(newPos.x/64);
        }
        else
            advance = (faces[font].advancex[(int)pt][text[i]-32]/64)-(faces[font].bearingx[(int)pt][text[i]-32]/64);
        glTranslatef(advance, 0.0f, 0.0f);
        accTrans+=advance;
    }
    glPopMatrix();
    glEnable(GL_CULL_FACE);
}


void Font::drawText(float number, const std::string& font, float pt)
{
    std::string temp;
    char buff[12];
    sprintf(buff, "%f", number);
    temp = buff;
    drawText(temp, font, pt);
}

void Font::drawText(int number, const std::string& font, float pt)
{
    std::string temp;
    char buff[12];
    sprintf(buff, "%d", number);
    temp = buff;
    drawText(temp, font, pt);
}

void Font::genPointSize(std::string fontname, unsigned int pt)
{
    for (unsigned int check = 0; check < loadedSizes[fontname].size(); check++)
        if (loadedSizes[fontname][check] == pt)
            return;
    int ret = FT_Set_Char_Size(faces[fontname].face, 0, pt*64, 72, 72);
    if (ret)
        return;
    int width;
    int height;
    char tempoa;
    GLuint glyphTexID;
    FT_GlyphSlot slot;
    unsigned int i;
    faces[fontname].height[(int)pt]=0;
    for (i = 0; i < unsigned(94); i++)
    {
        tempoa = alphabet[i];
        ret = FT_Load_Glyph( faces[fontname].face, FT_Get_Char_Index(faces[fontname].face, alphabet[i]), FT_LOAD_DEFAULT);
        if (ret)
            break;
        
        FT_Glyph glyph;
        FT_Get_Glyph( faces[fontname].face->glyph, &glyph);
        
        FT_Glyph_To_Bitmap(&glyph, ft_render_mode_normal, 0, 1);
        FT_BitmapGlyph glyphbit = (FT_BitmapGlyph)glyph;
        
        width = next_p2(glyphbit->bitmap.width);
        height = next_p2(glyphbit->bitmap.rows);
        
        unsigned char *tex = new unsigned char[2 * width * height];
        
        slot = faces[fontname].face->glyph;
        
        for (unsigned int ii=0; ii < unsigned(height); ii++)
            for (unsigned int iii=0; iii< unsigned(width); iii++)
            {
                tex[2*(iii + ii *width)] = tex[2*(iii + ii * width) + 1] = ((iii >= unsigned(glyphbit->bitmap.width)) || (ii >= unsigned(glyphbit->bitmap.rows)))? 0 : glyphbit->bitmap.buffer[iii + glyphbit->bitmap.width * ii];
            }
        
        glGenTextures(1, &glyphTexID);
        
        faces[fontname].advancex[(int)pt].push_back(faces[fontname].face->glyph->metrics.horiAdvance);
        faces[fontname].bearingx[(int)pt].push_back(faces[fontname].face->glyph->metrics.horiBearingX);
        faces[fontname].bearingy[(int)pt].push_back(faces[fontname].face->glyph->metrics.horiBearingY);
        faces[fontname].tops[(int)pt].push_back(glyphbit->top-glyphbit->bitmap.rows);
        faces[fontname].x[(int)pt].push_back((float)glyphbit->bitmap.width / (float)width);
        faces[fontname].y[(int)pt].push_back((float)glyphbit->bitmap.rows / (float)height);
        if (faces[fontname].height[(int)pt] < faces[fontname].face->glyph->metrics.height/64)
            faces[fontname].height[(int)pt] = faces[fontname].face->glyph->metrics.height/64;
        
        glBindTexture(GL_TEXTURE_2D, glyphTexID);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_LUMINANCE_ALPHA, GL_UNSIGNED_BYTE, tex);
        
        faces[fontname].displayList[(int)pt].push_back(glGenLists(1));
        
        glNewList(faces[fontname].displayList[(int)pt][i], GL_COMPILE);
        
        glPushMatrix();
        glTranslatef(0.0f, (faces[fontname].tops[(int)pt][i]/4)-faces[fontname].bearingy[(int)pt][i]/64, 0.0f);
        glBindTexture(GL_TEXTURE_2D, glyphTexID);
        glBegin(GL_QUADS);
        {
            glTexCoord2f(0.0f, 0.0f);
            glVertex2f(0.0f, 0.0f);
            glTexCoord2f(1.0, 0.0f);
            glVertex2f(width, 0.0f);
            glTexCoord2f(1.0, 1.0);
            glVertex2f(width, height);
            glTexCoord2f(0.0f, 1.0);
            glVertex2f(0.0f, height);
        }
        glEnd();
        glPopMatrix();
        
        glEndList();
        
        delete [] tex;
    }
    #ifndef NDEBUG
    console << Console::log << Console::highish << "TextEngine->Loaded " << fontname << " - " << pt << " point glyphs" << Console::endl();
    #endif
    loadedSizes[fontname].push_back(pt);
}
