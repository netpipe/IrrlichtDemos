#ifndef MATRIX_H
#define MATRIX_H

#include "vector.h"
template<class T>
class matrix4;
template<class T>
class matrix3;
template<class T>
class vector3;

#include "quaternion.h"

template<class T>
class matrix4
{
public:
        matrix4 (const T& w1=1, const T& w2=0, const T& w3=0, const T& w4=0,
                 const T& x1=0, const T& x2=1, const T& x3=0, const T& x4=0,
                 const T& y1=0, const T& y2=0, const T& y3=1, const T& y4=0,
                 const T& z1=0, const T& z2=0, const T& z3=0, const T& z4=1)
        {
		this->W1=w1; this->W2=w2; this->W3=w3; this->W4=w4;
		this->X1=x1; this->X2=x2; this->X3=x3; this->X4=x4;
		this->Y1=y1; this->Y2=y2; this->Y3=y3; this->Y4=y4;
		this->Z1=z1; this->Z2=z2; this->Z3=z3; this->Z4=z4;
        }

        matrix4 (const matrix4<T>& rhs)
        {
		(*this) = rhs;
        }

        T determinant(void) const
        {
		return (this->W1*( this->X2*((this->Y3*this->Z4) - (this->Z3*this->Y4)) - this->X3*((this->Y2*this->Z4) - (this->Z2*this->Y4)) + this->X4*((this->Y2*this->Z3) - (this->Z2*this->Y3))) -
			this->W2*(-this->X1*((this->Y3*this->Z4) - (this->Z3*this->Y4)) - this->X3*((this->Y2*this->Z4) - (this->Z2*this->Y4)) + this->X4*((this->Y2*this->Z3) - (this->Z2*this->Y3))) +
			this->W3*(-this->X1*((this->Y2*this->Z4) - (this->Z4*this->Y2)) + this->X2*((this->Y1*this->Z4) - (this->Z1*this->Y4)) + this->X4*((this->Y1*this->Z2) - (this->Z1*this->Y2))) -
			this->W4*(-this->X1*((this->Y2*this->Z3) - (this->Z2*this->Y3)) + this->X2*((this->Y1*this->Z3) - (this->Z1*this->Y3)) - this->X3*((this->Y1*this->Z2) - (this->Z1*this->Y2))));
        }

        void transpose(void)
        {
		matrix4<T> temp;
		temp.W1=this->W1; temp.W2=this->X1; temp.W3=this->Y1; temp.W4=this->Z1;
		temp.X1=this->W2; temp.X2=this->X2; temp.X3=this->Y2; temp.X4=this->Z2;
		temp.Y1=this->W3; temp.Y2=this->X3; temp.Y3=this->Y3; temp.Y4=this->Z3;
		temp.Z1=this->W4; temp.Z2=this->X4; temp.Z3=this->Y4; temp.Z4=this->Z4;
		*this = temp;
        }

        void setIdentity(void)
        {
		this->W1=1; this->W2=0; this->W3=0; this->W4=0;
		this->X1=0; this->X2=1; this->X3=0; this->X4=0;
		this->Y1=0; this->Y2=0; this->Y3=1; this->Y4=0;
		this->Z1=0; this->Z2=0; this->Z3=0; this->Z4=1;
        }

        inline void multiplyRow(int x, float coeff)
        {
		if (x==1)
		{
			this->W1*=coeff; this->W2*=coeff; this->W3*=coeff; this->W4*=coeff;
		}
		else if (x==2)
		{
			this->X1*=coeff; this->X2*=coeff; this->X3*=coeff; this->X4*=coeff;
		}
		else if (x==3)
		{
			this->Y1*=coeff; this->Y2*=coeff; this->Y3*=coeff; this->Y4*=coeff;
		}
		else if (x==4)
		{
			this->Z1*=coeff; this->Z2*=coeff; this->Z3*=coeff; this->Z4*=coeff;
		}
        }

        inline void addRows(int x, int y, T temp)
        {
		if (x==1)
		{
			if (y==2)
			{
				this->X1+=(temp*this->W1); this->X2+=(temp*this->W2); this->X3+=(temp*this->W3); this->X4+=(temp*this->W4);
			}
			if (y==3)
			{
				this->Y1+=(temp*this->W1); this->Y2+=(temp*this->W2); this->Y3+=(temp*this->W3); this->Y4+=(temp*this->W4);
			}
			if (y==4)
			{
				this->Z1+=(temp*this->W1); this->Z2+=(temp*this->W2); this->Z3+=(temp*this->W3); this->Z4+=(temp*this->W4);
			}
		}
		if (x==2)
		{
			if (y==3)
			{
				this->Y1+=(temp*this->X1); this->Y2+=(temp*this->X2); this->Y3+=(temp*this->X3); this->Y4+=(temp*this->X4);
			}
			if (y==4)
			{
				this->Z1+=(temp*this->X1); this->Z2+=(temp*this->X2); this->Z3+=(temp*this->X3); this->Z4+=(temp*this->X4);
			}
			if (y==1)
			{
				this->W1+=(temp*this->X1); this->W2+=(temp*this->X2); this->W3+=(temp*this->X3); this->W4+=(temp*this->X4);
			}
		}
		if (x==3)
		{
			if (y==1)
			{
				this->W1+=(temp*this->Y1); this->W2+=(temp*this->Y2); this->W3+=(temp*this->Y3); this->W4+=(temp*this->Y4);
			}
			if (y==2)
			{
				this->X1+=(temp*this->Y1); this->X2+=(temp*this->Y2); this->X3+=(temp*this->Y3); this->X4+=(temp*this->Y4);
			}
			if (y==4)
			{
				this->Z1+=(temp*this->Y1); this->Z2+=(temp*this->Y2); this->Z3+=(temp*this->Y3); this->Z4+=(temp*this->Y4);
			}
		}
		if (x==4)
		{
			if (y==1)
			{
				this->W1+=(temp*this->Z1); this->W2+=(temp*this->Z2); this->W3+=(temp*this->Z3); this->W4+=(temp*this->Z4);
			}
			if (y==2)
			{
				this->X1+=(temp*this->Z1); this->X2+=(temp*this->Z2); this->X3+=(temp*this->Z3); this->X4+=(temp*this->Z4);
			}
			if (y==3)
			{
				this->Y1+=(temp*this->Z1); this->Y2+=(temp*this->Z2); this->Y3+=(temp*this->Z3); this->Y4+=(temp*this->Z4);
			}
		}
        }

        void exchangeRows(const int x, const int y)
        {
		matrix4<T> temp;
		temp=*this;
		if (x==1)
		{
			switch (y)
			{
			default:
			case 0:
			case 1:
				return;
			case 2:
				temp.X1=this->W1; temp.X2=this->W2; temp.X3=this->W3; temp.X4=this->W4;
				temp.W1=this->X1; temp.W2=this->X2; temp.W3=this->X3; temp.W4=this->X4;
			case 3:
				temp.Y1=this->Y1; temp.Y2=this->Y2; temp.Y3=this->W3; temp.Y4=this->W4;
				temp.W1=this->Y1; temp.W2=this->Y2; temp.W3=this->Y3; temp.W4=this->Y4;
			case 4:
				temp.X1=this->W1; temp.X2=this->W2; temp.X3=this->W3; temp.X4=this->W4;
				temp.W1=this->X1; temp.W2=this->X2; temp.W3=this->X3; temp.W4=this->X4;
			}
		}
		else if (x==2)
		{
			switch (y)
			{
			default:
			case 0:
			case 2:
				return;
			case 1:
				temp.X1=this->W1; temp.X2=this->W2; temp.X3=this->W3; temp.X4=this->W4;
				temp.W1=this->X1; temp.W2=this->X2; temp.W3=this->X3; temp.W4=this->X4;
				break;
			case 3:
				temp.X1=this->Y1; temp.X2=this->Y2; temp.X3=this->Y3; temp.Y4=this->X4;
				temp.Y1=this->X1; temp.Y2=this->X2; temp.Y3=this->X3; temp.X4=this->Y4;
				break;
			case 4:
				temp.X1=this->Z1; temp.X2=this->Z2; temp.X3=this->Z3; temp.Z4=this->X4;
				temp.Z1=this->X1; temp.Z2=this->X2; temp.Z3=this->X3; temp.X4=this->Z4;
				break;
			}
		}
		else if (x==3)
		{
			switch (y)
			{
			default:
			case 0:
			case 3:
				return;
			case 1:
				temp.Y1=this->Y1; temp.Y2=this->Y2; temp.Y3=this->W3; temp.Y4=this->W4;
				temp.W1=this->Y1; temp.W2=this->Y2; temp.W3=this->Y3; temp.W4=this->Y4;
				break;
			case 2:
				temp.X1=this->Y1; temp.X2=this->Y2; temp.X3=this->Y3; temp.X4=this->Y4;
				temp.Y1=this->X1; temp.Y2=this->X2; temp.Y3=this->X3; temp.Y4=this->X4;
				break;
			case 4:
				temp.Y1=this->Z1; temp.Y2=this->Z2; temp.Y3=this->Z3; temp.Y4=this->Z4;
				temp.Z1=this->Y1; temp.Z2=this->Y2; temp.Z3=this->Y3; temp.Z4=this->Y4;
				break;
			}
		}
		else if (x==4)
		{
			switch (y)
			{
			default:
			case 0:
			case 4:
				return;
			case 1:
				temp.X1=this->W1; temp.X2=this->W2; temp.X3=this->W3; temp.X4=this->W4;
				temp.W1=this->X1; temp.W2=this->X2; temp.W3=this->X3; temp.W4=this->X4;
				break;
			case 2:
				temp.X1=this->Z1; temp.X2=this->Z2; temp.X3=this->Z3; temp.X4=this->Z4;
				temp.Z1=this->X1; temp.Z2=this->X2; temp.Z3=this->X3; temp.Z4=this->X4;
				break;
			case 3:
				temp.Y1=this->Z1; temp.Y2=this->Z2; temp.Y3=this->Z3; temp.Y4=this->Z4;
				temp.Z1=this->Y1; temp.Z2=this->Y2; temp.Z3=this->Y3; temp.Z4=this->Y4;
				break;
			}
		}
		else
			return;

		*this=temp;
        }

	// Gauss-Jordan matrix inverse function
        void inverse(void)
        {
		matrix4<T> temp;
		T temp2;
		bool done;

		done=true;

		// check if invertable
		if (determinant()==0)
			return; // not invertable


		matrix4<T> inv(1, 0, 0, 0, 1, 0, 0, 0, 1);

		// first order of business
		while(done)
		{
			done=false;
			if (this->X1>this->W1)
			{
				exchangeRows(1, 2);
				inv.exchangeRows(1, 2);
				done=true;
			}
			if (this->Y1>this->X1)
			{
				exchangeRows(2, 3);
				inv.exchangeRows(2, 3);
				done=true;
			}
			else if (this->Z1>this->Y1)
			{
				exchangeRows(3, 4);
				inv.exchangeRows(3, 4);
				done=true;
			}
		}

		temp2=this->W1;

		multiplyRow(1, (1/temp2));
		inv.multiplyRow(1, (1/temp2));
		inv.addRows(1, 2, (-this->X1));
		addRows(1, 2, (-this->X1));
		inv.addRows(1, 3, (-this->Y1));
		addRows(1, 3, (-this->Y1));
		inv.addRows(1, 4, (-this->Z1));
		addRows(1, 4, (-this->Z1));

		temp2=this->X2;

		multiplyRow(2, (1/temp2));
		inv.multiplyRow(2, (1/temp2));
		inv.addRows(2, 3, (-this->Y2));
		addRows(2, 3, (-this->Y2));
		inv.addRows(2, 4, (-this->Z2));
		addRows(2, 4, (-this->Z2));
		inv.addRows(2, 1, (-this->W2));
		addRows(2, 1, (-this->W2));

		temp2=this->Y3;

		multiplyRow(3, (1/temp2));
		inv.multiplyRow(3, (1/temp2));
		inv.addRows(3, 1, (-this->W3));
		addRows(3, 1, (-this->W3));
		inv.addRows(3, 2, (-this->X3));
		addRows(3, 2, (-this->X3));
		inv.addRows(3, 4, (-this->Z3));
		addRows(3, 4, (-this->Z3));

		temp2=this->Z3;

		multiplyRow(4, (1/temp2));
		inv.multiplyRow(4, (1/temp2));
		inv.addRows(4, 1, (-this->W3));
		addRows(4, 1, (-this->W3));
		inv.addRows(4, 2, (-this->X3));
		addRows(4, 2, (-this->X3));
		inv.addRows(4, 3, (-this->Y3));
		addRows(4, 3, (-this->Y3));

		*this=inv;
        }

        // This one too
        inline vector3<T> multiplyVector(const vector3<T> &temp) const
        { // inlined that one --blub
		vector3<T> result;
		result.X = (this->X1 * temp.X) + (this->X2 * temp.X) + (this->X3 * temp.X) + (this->X4* temp.X);
		result.Y = (this->Y1 * temp.Y) + (this->Y2 * temp.Y) + (this->Y3 * temp.Y) + (this->Y4* temp.Y);
		result.Z = (this->Z1 * temp.Z) + (this->Z2 * temp.Z) + (this->Z3 * temp.Z) + (this->Z4* temp.Z);

		return result;
        }
	
	
        // Operators
        //
        // Below here
	
        matrix4<T>& operator=(const matrix4<T> &temp)
	{
		this->W1=temp.W1; this->W2=temp.W2; this->W3=temp.W3; this->W4=temp.W4;
		this->X1=temp.X1; this->X2=temp.X2; this->X3=temp.X3; this->X4=temp.X4;
		this->Y1=temp.Y1; this->Y2=temp.Y2; this->Y3=temp.Y3; this->Y4=temp.Y4;
		this->Z1=temp.Z1; this->Z2=temp.Z2; this->Z3=temp.Z3; this->Z4=temp.Z4;
		return (*this);
	}

        void operator*=(const matrix4<T> &temp)
        {
		this->W1*=temp.W1; this->W2*=temp.W2; this->W3*=temp.W3; this->W4*=temp.W4;
		this->X1*=temp.X1; this->X2*=temp.X2; this->X3*=temp.X3; this->X4*=temp.X4;
		this->Y1*=temp.Y1; this->Y2*=temp.Y2; this->Y3*=temp.Y3; this->Y4*=temp.Y4;
		this->Z1*=temp.Z1; this->Z2*=temp.Z2; this->Z3*=temp.Z3; this->Z4*=temp.Z4;
        }

        void operator*=(const T temp)
        {
		this->W1*=temp; this->W2*=temp; this->W3*=temp; this->W4*=temp;
		this->X1*=temp; this->X2*=temp; this->X3*=temp; this->X4*=temp;
		this->Y1*=temp; this->Y2*=temp; this->Y3*=temp; this->Y4*=temp;
		this->Z1*=temp; this->Z2*=temp; this->Z3*=temp; this->Z4*=temp;
        }

        void operator/=(const T temp)
        {
		this->W1/=temp; this->W2/=temp; this->W3/=temp; this->W4/=temp;
		this->X1/=temp; this->X2/=temp; this->X3/=temp; this->X4/=temp;
		this->Y1/=temp; this->Y2/=temp; this->Y3/=temp; this->Y4/=temp;
		this->Z1/=temp; this->Z2/=temp; this->Z3/=temp; this->Z4/=temp;
        }

        void operator+=(const T temp)
        {
		this->W1+=temp; this->W2+=temp; this->W3+=temp; this->W4+=temp;
		this->X1+=temp; this->X2+=temp; this->X3+=temp; this->X4+=temp;
		this->Y1+=temp; this->Y2+=temp; this->Y3+=temp; this->Y4+=temp;
		this->Z1+=temp; this->Z2+=temp; this->Z3+=temp; this->Z4+=temp;
        }

        void operator-=(const T temp)
        {
		this->W1-=temp; this->W2-=temp; this->W3-=temp; this->W4-=temp;
		this->X1-=temp; this->X2-=temp; this->X3-=temp; this->X4-=temp;
		this->Y1-=temp; this->Y2-=temp; this->Y3-=temp; this->Y4-=temp;
		this->Z1-=temp; this->Z2-=temp; this->Z3-=temp; this->Z4-=temp;
        }

	matrix4<T> operator*(const matrix4<T> &temp) const
	{
		return matrix4<T>(
			W1*temp.W1, W2*temp.W2, W3*temp.W3, W4*temp.W4,
			X1*temp.X1, X2*temp.X2, X3*temp.X3, X4*temp.X4,
			Y1*temp.Y1, Y2*temp.Y2, Y3*temp.Y3, Y4*temp.Y4,
			Z1*temp.Z1, Z2*temp.Z2, Z3*temp.Z3, Z4*temp.Z4
			);
	}

	matrix4<T> operator/(const T temp) const
	{
		return matrix4<T>(
			W1/temp, W2/temp, W3/temp, W4/temp,
			X1/temp, X2/temp, X3/temp, X4/temp,
			Y1/temp, Y2/temp, Y3/temp, Y4/temp,
			Z1/temp, Z2/temp, Z3/temp, Z4/temp
			);
	}

	matrix4<T> operator+(const T temp) const
	{
		return matrix4<T>(
			W1+temp, W2+temp, W3+temp, W4+temp,
			X1+temp, X2+temp, X3+temp, X4+temp,
			Y1+temp, Y2+temp, Y3+temp, Y4+temp,
			Z1+temp, Z2+temp, Z3+temp, Z4+temp
			);
	}

	matrix4<T> operator-(const T temp) const
	{
		return matrix4<T>(
			W1-temp, W2-temp, W3-temp, W4-temp,
			X1-temp, X2-temp, X3-temp, X4-temp,
			Y1-temp, Y2-temp, Y3-temp, Y4-temp,
			Z1-temp, Z2-temp, Z3-temp, Z4-temp
			);
	}
	vector3<T> operator*(const vector3<T> &v) const
	{
		return multiplyVector(v);
	}

	vector3<T> translationVector() const
	{
		return vector3<T>(W4,X4,Y4);
	}

	quaternion<T> rotationQuaternion() const
	{
		quaternion<T> q;

		float trace = W1 + X2 + Y3 + 1.0f;

		if( trace > 0.0000001 )
		{
			float s = 0.5f / sqrtf(trace);
			q.W = 0.25f / s;
			q.X = ( Y2 - X3 ) * s;
			q.Y = ( W3 - Y1 ) * s;
			q.Z = ( X1 - W2 ) * s;
		}
		else
		{
			if ( W1 > X2 && W1 > Y3 )
			{
				float s = 2.0f * sqrtf( 1.0f + W1 - X2 - Y3 );
				q.X = 0.25f * s;
				q.Y = (W2 + X1 ) / s;
				q.Z = (W3 + Y1 ) / s;
				q.W = (X3 - Y2 ) / s;

			}
			else if (X2 > Y3)
			{
				float s = 2.0f * sqrtf( 1.0f + X2 - W1 - Y3 );
				q.X = (W2 + X1 ) / s;
				q.Y = 0.25f * s;
				q.Z = (X3 + Y2 ) / s;
				q.W = (W3 - Y1 ) / s;

			}
			else
			{
				float s = 2.0f * sqrtf( 1.0f + Y3 - W1 - X2 );
				q.X = (W3 + Y1 ) / s;
				q.Y = (X3 + Y2 ) / s;
				q.Z = 0.25f * s;
				q.W = (W2 - X1 ) / s;
			}
		}

		return q;
	}

	void setTranslation(T x,T y,T z)
	{
		W4=x;
		X4=y;
		Y4=z;
	}

	void setTranslation(vector3<T> v)
	{
		W4=v.X;
		X4=v.Y;
		Y4=v.Z;
	}

	void setRotation(T w,T x,T y,T z)
	{
		/*       W1 = 1 - 2*q.Y*q.Y - 2*q.Z*q.Z;     W2 = 2*q.X*q.Y - 2*q.Z*q.W;	        W3 = 2*q.X*q.Z + 2*q.Y*q.W
			 X1 = 2*q.X*q.Y + 2*q.Z*q.W	;       X2 = 1 - 2*q.X*q.X - 2*q.Z*q.Z; 	X3 = 2*q.Y*q.Z - 2*q.X*q.W
			 Y1 = 2*q.X*q.Z - 2*q.Y*q.W;     	Y2 = 2*q.Y*q.Z + 2*q.X*q.W;         Y3 = 1 - 2*q.X*q.X - 2*q.Y*q.Y;
		*/
		setRotation(quaternion<T> (w,x,y,z));
	}

	void setRotation(quaternion<T> q)
	{
		W1 = 1 - 2*q.Y*q.Y - 2*q.Z*q.Z;     W2 = 2*q.X*q.Y - 2*q.Z*q.W;	        W3 = 2*q.X*q.Z + 2*q.Y*q.W;
		X1 = 2*q.X*q.Y + 2*q.Z*q.W	;       X2 = 1 - 2*q.X*q.X - 2*q.Z*q.Z; 	X3 = 2*q.Y*q.Z - 2*q.X*q.W;
		Y1 = 2*q.X*q.Z - 2*q.Y*q.W;     	Y2 = 2*q.Y*q.Z + 2*q.X*q.W;         Y3 = 1 - 2*q.X*q.X - 2*q.Y*q.Y;
	}


        T W1, W2, W3, W4;
        T X1, X2, X3, X4;
        T Y1, Y2, Y3, Y4;
        T Z1, Z2, Z3, Z4;
};

//! Matrix 3x3 template class
template<class T>
class matrix3
{
public:
        matrix3(const T& x1=1, const T& x2=0, const T& x3=0, const T& y1=0, const T& y2=1, const T& y3=0, const T& z1=0, const T& z2=0, const T& z3=1)
        {
		this->X1=x1; this->X2=x2; this->X3=x3;
		this->Y1=y1; this->Y2=y2; this->Y3=y3;
		this->Z1=z1; this->Z2=z2; this->Z3=z3;
        }

        matrix3(const matrix3<T>& rhs)
        {
		(*this) = rhs;
        }

        T determinant(void) const
        {
		T result;
		result=(this->X1*((this->Y2*this->Z3) - (this->Y3*this->Z2))) - (this->X2*((this->Y1*this->Z3) - (this->Y3*this->Z1))) + (this->X3*((this->Y1*this->Z2) - (this->Y2*this->Z1)));
		return result;
        }

        void transpose(void)
        {
		matrix3<T> temp;
		temp.X1=this->X1; temp.X2=this->Y1; temp.X3=this->Z1;
		temp.Y1=this->X2; temp.Y2=this->Y2; temp.Y3=this->Z2;
		temp.Z1=this->X3; temp.Z2=this->Y3; temp.Z3=this->Z3;
		*this=temp;
        }

        void setIdentity(void)
        {
		this->X1=1; this->X2=0; this->X3=0;
		this->Y1=0; this->Y2=1; this->Y3=0;
		this->Z1=0; this->Z2=0; this->Z3=1;
        }

        void exchangeRows(const int x, const int y)
        {
		matrix3<T> temp;
		temp=*this;
		if (x==1)
		{
			switch (y)
			{
			default:
			case 0:
			case 1:
				return;
			case 2:
				temp.X1=this->Y1; temp.X2=this->Y2; temp.X3=this->Y3;
				temp.Y1=this->X1; temp.Y2=this->X2; temp.Y3=this->X3;
				break;
			case 3:
				temp.X1=this->Z1; temp.X2=this->Z2; temp.X3=this->Z3;
				temp.Z1=this->X1; temp.Z2=this->X2; temp.Z3=this->X3;
				break;
			}
		}
		else if (x==2)
		{
			switch (y)
			{
			default:
			case 0:
			case 2:
				return;
			case 1:
				temp.X1=this->Y1; temp.X2=this->Y2; temp.X3=this->Y3;
				temp.Y1=this->X1; temp.Y2=this->X2; temp.Y3=this->X3;
				break;
			case 3:
				temp.Y1=this->Z1; temp.Y2=this->Z2; temp.Y3=this->Z3;
				temp.Z1=this->Y1; temp.Z2=this->Y2; temp.Z3=this->Y3;
				break;
			}
		}
		else if (x==3)
		{
			switch (y)
			{
			default:
			case 0:
			case 3:
				return;
			case 1:
				temp.X1=this->Z1; temp.X2=this->Z2; temp.X3=this->Z3;
				temp.Z1=this->X1; temp.Z2=this->X2; temp.Z3=this->X3;
				break;
			case 2:
				temp.Y1=this->Z1; temp.Y2=this->Z2; temp.Y3=this->Z3;
				temp.Z1=this->Y1; temp.Z2=this->Y2; temp.Z3=this->Y3;
				break;
			}
		}
		else
			return;

		*this=temp;
        }

        inline void multiplyRow(int x, float coeff)
        {
		if (x==1)
		{
			this->X1*=coeff; this->X2*=coeff; this->X3*=coeff;
		}
		else if (x==2)
		{
			this->Y1*=coeff; this->Y2*=coeff; this->Y3*=coeff;
		}
		else if (x==3)
		{
			this->Z1*=coeff; this->Z2*=coeff; this->Z3*=coeff;
		}
        }

        inline void addRows(int x, int y, T temp)
        {
		if (x==1)
		{
			if (y==2)
			{
				this->Y1+=(temp*this->X1); this->Y2+=(temp*this->X2); this->Y3+=(temp*this->X3);
			}
			if (y==3)
			{
				this->Z1+=(temp*this->X1); this->Z2+=(temp*this->X2); this->Z3+=(temp*this->X3);
			}
		}
		if (x==2)
		{
			if (y==3)
			{
				this->Z1+=(temp*this->Y1); this->Z2+=(temp*this->Y2); this->Z3+=(temp*this->Y3);
			}
			if (y==1)
			{
				this->X1+=(temp*this->Y1); this->X2+=(temp*this->Y2); this->X3+=(temp*this->Y3);
			}
		}
		if (x==3)
		{
			if (y==1)
			{
				this->X1+=(temp*this->Z1); this->X2+=(temp*this->Z2); this->X3+=(temp*this->Z3);
			}
			if (y==2)
			{
				this->Y1+=(temp*this->Z1); this->Y2+=(temp*this->Z2); this->Y3+=(temp*this->Z3);
			}
		}
        }

        // Gauss-Jordan matrix inverse function
        void inverse(void)
        {
		matrix3<T> temp;
		T temp2;
		bool done;

		done=true;

		// check if invertable
		if (determinant()==0)
			return; // not invertable


		matrix3<T> inv(1, 0, 0, 0, 1, 0, 0, 0, 1);

		// first order of business
		while(done)
		{
			done=false;
			if (this->Y1>this->X1)
			{
				exchangeRows(1, 2);
				inv.exchangeRows(1, 2);
				done=true;
			}
			else if (this->Z1>this->Y1)
			{
				exchangeRows(2, 3);
				inv.exchangeRows(2, 3);
				done=true;
			}
		}

		temp2=this->X1;

		multiplyRow(1, (1/temp2));
		inv.multiplyRow(1, (1/temp2));
		inv.addRows(1, 2, (-this->Y1));
		addRows(1, 2, (-this->Y1));
		inv.addRows(1, 3, (-this->Z1));
		addRows(1, 3, (-this->Z1));

		temp2=this->Y2;

		multiplyRow(2, (1/temp2));
		inv.multiplyRow(2, (1/temp2));
		inv.addRows(2, 3, (-this->Z2));
		addRows(2, 3, (-this->Z2));
		inv.addRows(2, 1, (-this->X2));
		addRows(2, 1, (-this->X2));

		temp2=this->Z3;

		multiplyRow(3, (1/temp2));
		inv.multiplyRow(3, (1/temp2));
		inv.addRows(3, 1, (-this->X3));
		addRows(3, 1, (-this->X3));
		inv.addRows(3, 2, (-this->Y3));
		addRows(3, 2, (-this->Y3));

		*this=inv;
        }

        // This one too
	inline vector3<T> multiplyVector(const vector3<T> &temp) const
        { // inlining that to be used in operator* --blub
		vector3<T> result;
		result.X = (this->X1 * temp.X) + (this->X2 * temp.X) + (this->X3 * temp.X);
		result.Y = (this->Y1 * temp.Y) + (this->Y2 * temp.Y) + (this->Y3 * temp.Y);
		result.Z = (this->Z1 * temp.Z) + (this->Z2 * temp.Z) + (this->Z3 * temp.Z);

		return result;
        }

        void print()
        {
		printf("%i: %f | %f | %f\n    %f | %f | %f\n    %f | %f | %f\n", this, X1, X2, X3, Y1, Y2, Y3, Z1, Z2, Z3);
        }


        /*========================================

	  Operators below here


	  =========================================*/

        matrix3<T> operator=(const matrix3<T> &temp)
		{
			this->X1=temp.X1; this->X2=temp.X2; this->X3=temp.X3;
			this->Y1=temp.Y1; this->Y2=temp.Y2; this->Y3=temp.Y3;
			this->Z1=temp.Z1; this->Z2=temp.Z2; this->Z3=temp.Z3;
			return *this;
		}

        void operator*=(const matrix3<T> &temp)
        {
		this->X1*=temp.X1; this->X2*=temp.X2; this->X3*=temp.X3;
		this->Y1*=temp.Y1; this->Y2*=temp.Y2; this->Y3*=temp.Y3;
		this->Z1*=temp.Z1; this->Z2*=temp.Z2; this->Z3*=temp.Z3;
        }

        void operator*=(const T temp)
        {
		this->X1*=temp; this->X2*=temp; this->X3*=temp;
		this->Y1*=temp; this->Y2*=temp; this->Y3*=temp;
		this->Z1*=temp; this->Z2*=temp; this->Z3*=temp;
        }

        void operator/=(const T temp)
        {
		this->X1/=temp; this->X2/=temp; this->X3/=temp;
		this->Y1/=temp; this->Y2/=temp; this->Y3/=temp;
		this->Z1/=temp; this->Z2/=temp; this->Z3/=temp;
        }

        void operator+=(const T temp)
        {
		this->X1+=temp; this->X2+=temp; this->X3+=temp;
		this->Y1+=temp; this->Y2+=temp; this->Y3+=temp;
		this->Z1+=temp; this->Z2+=temp; this->Z3+=temp;
        }

        void operator-=(const T temp)
        {
		this->X1-=temp; this->X2-=temp; this->X3-=temp;
		this->Y1-=temp; this->Y2-=temp; this->Y3-=temp;
		this->Z1-=temp; this->Z2-=temp; this->Z3-=temp;
        }

	matrix3<T> operator*(const matrix3<T> &temp) const
	{
		return matrix3<T>(
			X1*temp.X1, X2*temp.X2, X3*temp.X3,
			Y1*temp.Y1, Y2*temp.Y2, Y3*temp.Y3,
			Z1*temp.Z1, Z2*temp.Z2, Z3*temp.Z3
			);
	}

	matrix3<T> operator/(const T temp) const
	{
		return matrix3<T>(
			X1/temp, X2/temp, X3/temp,
			Y1/temp, Y2/temp, Y3/temp,
			Z1/temp, Z2/temp, Z3/temp
			);
	}

	matrix3<T> operator+(const T temp) const
	{
		return matrix3<T>(
			X1+temp, X2+temp, X3+temp,
			Y1+temp, Y2+temp, Y3+temp,
			Z1+temp, Z2+temp, Z3+temp
			);
	}

	matrix3<T> operator-(const T temp) const
	{
		return matrix3<T>(
			X1-temp, X2-temp, X3-temp,
			Y1-temp, Y2-temp, Y3-temp,
			Z1-temp, Z2-temp, Z3-temp
			);
	}

	vector3<T> operator*(const vector3<T> &v) const
	{
		return multiplyVector(v);
	}

        T X1, X2, X3;
        T Y1, Y2, Y3;
        T Z1, Z2, Z3;
};

#endif
