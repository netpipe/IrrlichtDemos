#ifndef TEXTUREFACTORY_H_04112006
#define TEXTUREFACTORY_H_04112006

#ifndef __OSX__
	#include <GL/gl.h>
	#include <GL/glu.h>
#else
	#include <OpenGL/gl.h>
	#include <OpenGL/glu.h>
#endif

#include "../FileSystem/FileSystem.h"
#include "../Scripting/ScriptEngine.h"
#include <map>

#define PNG_OK		 0
#define PNG_FILEIOERROR  1
#define PNG_MALLOCERROR  2
#define PNG_JUMPSETERROR 3

typedef struct Texture
{
    int TextureID;
    int width;
    int height;
};

//! Texture factory class, globalised with texture_factory
class TextureFactory
{
	public:
		TextureFactory();
		~TextureFactory();
		int loadTexture(const std::string& filename);
		int applyTexture(int texNumber);
		void flushFactory();
		void useExtensions();
	private:
		bool useExts;
		std::map<std::string,unsigned> textures;
		std::map<unsigned,GLuint> references;
		int loadPNG(const std::string& filename);
		int loadJPEG(const std::string& filename);
};

extern TextureFactory texture_factory;

// Intermediary class for lua
class TextureLua
{
	public:
		TextureLua(lua_State *);
		~TextureLua();
		int loadTexture(lua_State *);
		int textureID(lua_State *);
		static const char className[];
		static AzLua<TextureLua>::RegType methods[];
	private:
		unsigned int TextureID;
};

#endif

