#include "Physics.h"

// How many times the world space gets subdivided
const int subdivisions = 5;

using GUI::Console;

#ifndef WIN32
void strreverse(char* begin, char* end)
{
    
    char aux;
    
    while(end>begin)
        
        aux=*end, *end--=*begin, *begin++=aux;
    
}

void itoa(int value, char* str, int base)
{
    
    static char num[] = "0123456789abcdefghijklmnopqrstuvwxyz";
    
    char* wstr=str;
    
    int sign;
    
    
    
    // Validate base
    
    if (base<2 || base>35)
    { *wstr='\0'; return; }
    
    
    
    // Take care of sign
    
    if ((sign=value) < 0) value = -value;
    
    
    
    // Conversion. Number is reversed.
    
    do *wstr++ = num[value%base]; while(value/=base);
    
    if(sign<0) *wstr++='-';
    
    *wstr='\0';
    
    
    
    // Reverse string
    strreverse(str, wstr-1);
}

#endif

// Floating absolute
float fabs(float x)
{
    if (x < 0)
        x*=-1;
    return x;
}

Physics::Physics()
{
    
}

Physics::~Physics()
{
    
}

PhysicsObject::~PhysicsObject()
{
    
}

//! Registers an object into the physics engine
void Physics::RegisterObject(PhysicsObject *obj)
{
    Objects[obj->name] = obj;
    ObjectKeys[unsigned(ObjectKeys.size())] = obj->name;
    #ifndef NDEBUG
    console << Console::high << Console::highish << "Physics->Registered a " << obj->type << " object called: " << obj->name << Console::endl();
    #endif
}

void Physics::RegisterObject(ForceObject *obj)
{
    
}

void Physics::RegisterObject(GravityObject *obj)
{
    
}

unsigned long Physics::GetNumObjects()
{
    return unsigned(ObjectKeys.size());
}

void Physics::doGravity(const double& fps)
{
    unsigned int i, ii;
    for (i = 0; i < unsigned(Gravs.size()); ++i)
    {
        vector3<float> temp, newPos;
        float range, strength;
        temp = Gravs[i]->position;
        range = Gravs[i]->range;
        strength = Gravs[i]->strength;
        for (ii = 0; ii < ObjectKeys.size(); ii++)
        {
            if (!Objects[ObjectKeys[ii]]->atRest)
            {
                if ( (fabs(Objects[ObjectKeys[ii]]->position.X - temp.X) < range) &&
                (fabs(Objects[ObjectKeys[ii]]->position.Y - temp.Y) < range) &&
                (fabs(Objects[ObjectKeys[ii]]->position.Z - temp.Z) < range))
                {
                    vector3<float> temp2 = temp - Objects[ObjectKeys[ii]]->position;
                    vector3<float> temp3 = temp2;
                    temp2.Normalize();
                    temp2 *= strength/(fps+1);
                    if (fabs(temp3.X) < strength && fabs(temp3.Y) < strength && fabs(temp3.Z) < strength)
                    {
                        Objects[ObjectKeys[ii]]->velocity.X = 0;
                        Objects[ObjectKeys[ii]]->velocity.Y = 0;
                        Objects[ObjectKeys[ii]]->velocity.Z = 0;
                        continue;
                    }
                    else
                    {
                        Objects[ObjectKeys[ii]]->velocity.X += temp2.X;
                        Objects[ObjectKeys[ii]]->velocity.Y += temp2.Y;
                        Objects[ObjectKeys[ii]]->velocity.Z += temp2.Z;
                    }
                    newPos = Objects[ObjectKeys[ii]]->position + Objects[ObjectKeys[ii]]->velocity;
                    if (!colliding(newPos))
                    {
                        Objects[ObjectKeys[ii]]->position = newPos;
                        Objects[ObjectKeys[ii]]->updateModel();
                    }
                    else
                    {
                        newPos = newPos * -1;
                        if (!colliding(newPos))
                        {
                            Objects[ObjectKeys[ii]]->position = newPos;
                            Objects[ObjectKeys[ii]]->updateModel();
                        }
                    }
                }
            }
        }
    }
}

void Physics::doForces(const double& fps)
{
    unsigned int i;
    for(i = 0; i < unsigned(Forces.size()); ++i)
    {
        
    }
}

//! should be called each loop of the engine
void Physics::tick(const double& fps)
{
    doGravity(fps);
    doForces(fps);
}

bool Physics::colliding(const vector3<float>& dir)
{
    // First division
    vector3<float> temp;
    for (unsigned int ii=0; ii < ObjectKeys.size(); ii++)
    {
        temp = Objects[ObjectKeys[ii]]->position;
        unsigned iteration = 0;
        unsigned size = 1024;
        for(int iii=0; iii < subdivisions; iii++)
        {
            if ((dir.X < (-iteration) && temp.X < (-iteration)) ||
            (dir.X >= iteration && temp.X >= iteration))
                if ((dir.Y < (-iteration) && temp.Y < (-iteration)) ||
                (dir.Y >= iteration && temp.Y <= iteration))
                    if ((dir.Z < (-iteration) && temp.Z < (-iteration)) ||
                    (dir.Z >= iteration && temp.Z >= iteration))
                    {
                        iteration += size * (iii+1);
                    }
                    else
                        break;
                else
                    break;
            else
                break;
        }
    }
    
    return false;
}
