#ifndef __PHYSICS_H__
#define __PHYSICS_H__

#include "../vector.h"
#include "../GUI/Console.h"
#include "../vector.h"
#include "../GUI/Drawing.h"
#include "../SceneGraph/SceneGraph.h"
#include <string>
#include <map>
#include <stdlib.h>

class PhysicsObject;
class ForceObject;
class GravityObject;

#ifndef WIN32
void itoa(int value, char* str, int base);
#endif

//! The physics engine class
class Physics
{
	/*!
	  The physics engine is designed to work by having objects register themselves to the engine before they can be affected by physics<br>
	  This helps in that we can choose to only let certain classes become physics involved.<br>
	  What needs to be implemented now is a scene graph as well as the physics themselves.<br>
	  Finally, collision detection is needed.
	*/
public:
	Physics();
	~Physics();
        void RegisterObject(PhysicsObject *obj);
        void RegisterObject(ForceObject *obj);
        void RegisterObject(GravityObject *obj);
        unsigned long GetNumObjects();
	void tick(const double& fps);
	bool colliding(const vector3<float>&);
private:
        void doGravity(const double& fps);
        void doForces(const double& fps);
	std::map<std::string, PhysicsObject*> Objects;
	std::vector<ForceObject*> Forces;
	std::vector<GravityObject*> Gravs;
	std::map<unsigned int, std::string> ObjectKeys;
};

extern Physics physics_engine;

class PhysicsObject
{
public:
        PhysicsObject()
        {
		this->position.X=0;
		this->position.Y=0;
		this->position.Z=0;
		this->velocity.X=0;
		this->velocity.Y=0;
		this->velocity.Z=0;
		this->atRest=false;
        }
        virtual ~PhysicsObject();
        vector3<float> position;
        vector3<float> velocity;
        float acceleration;
        float mass;
        bool atRest;

        std::string type;
        std::string name;

        char * tostring(unsigned long x)
        {
		char *buff;
		buff = new char[8];
		itoa(x, buff, 8);
		return buff;
        }

        char * mangle(const std::string& namae)
        {
		std::string temp;
		temp +=type + "_" + namae + "#" + tostring(physics_engine.GetNumObjects());
		return (char*)temp.c_str();
        }

        virtual void updateModel(){};
};

class ForceObject
{
public:
        ForceObject();
        ~ForceObject();
        vector3<float> position;
        vector3<float> direction;
        float range;
        float strength;

        int type;
};

class GravityObject
{
public:
        GravityObject();
        ~GravityObject();
        vector3<float> position;
        float range;
        float strength;
};

#endif
