#ifndef INPUT_H
#define INPUT_H

#include <SDL/SDL.h>
#include <map>
#include <string>
#include <vector>

#define MOD_NONE 0x0004

class Input;
class eventListener
{
	friend class Input;
protected:
	virtual ~eventListener();
	virtual void cmdTriggered(std::string cmd) {};
	virtual void cmdReleased(std::string cmd) {};
	virtual void charEntered(SDLKey sym, unsigned short int ch) {};
	virtual void charReleased(SDLKey sym, unsigned short int ch) {};
};

class Input
{
public:
	Input();
	//~Input();
	void get(); // process events
	bool registerKeyListener(
		std::string cmdName,
		unsigned short defKey,
		eventListener *caller,
		unsigned short mod=MOD_NONE|KMOD_NUM,
		unsigned char layout = 0,
		bool registerATconsole = false);

	bool registerOverrideKeyListener(
		std::string cmdName,
		unsigned short defKey, // default key
		eventListener *caller,
		unsigned short mod=MOD_NONE|KMOD_NUM,
		unsigned char layout = 0,
		bool registerATconsole = false);

	bool setLayout(unsigned char);
	unsigned char getLayout();
	unsigned char addLayout();
	inline bool getKeyMode() { return mode; }
	inline void KeyMode() { mode = true; }
	inline void TextMode(eventListener *tl) { textListener = tl; mode = false; }

	// just there to prevent breaking old code
	inline bool isKeyDepressed(int no) { return keys[no]; }
	inline bool isMouseButtonDepressed(int no) { return mouse[no]; }
	inline int getTimesPressed(int no) { return keysp[no]; }
	inline int removeKeyPress(int no) { return --keysp[no]; }
	inline void removeDepressed(int no) { keys[no] = 0; }
	inline bool getKeyPress(int no) {
		if(!keysp[no])
			return false;
		--keysp[no];
		return true;
	}
	inline bool getMouseClick(int no) {
		if(!mousep[no])
			return false;
		--mousep[no];
		return true;
	}
	inline bool getMouseDown(int no) {
        return (mouse[no]==1)?true:false;
	}
	inline bool getMouseScroll(int no) {
        if(!mousep[no+3])
            return false;
        --mousep[no+3];
        return true;
	}
	inline int getMouseX() { return mouseX; }
	inline int getMouseY() { return mouseY; }
	inline bool isQuit() { return quit; }
	void flush();
	void flushMouseButtons();

private:
	bool keys[512];
	unsigned char keysp[512];
	bool quit;
	int mouseX;
	int mouseY;
	bool mouse[8];
	int mousep[8];

	bool mode; // ? keymode : string mode
	unsigned char active_layout;

	eventListener *textListener;
	std::map<std::string, eventListener*> listeners;

	/*typedef std::map<
		unsigned short, // key
		std::map<
		 unsigned short // modifier
		 std::string> // command
		>
		> binding;*/
	typedef std::map<unsigned short, std::string> modbind; // mod + command
	typedef std::map<unsigned short, modbind> binding; // key + modbind
	std::vector<binding> layouts, override_layouts; // just to keep what was there earlier --blub
};
#endif

/*
//!  Vector Contains Layouts
//!     |          Map Contains Keys
//!     |                |                 Map Contains Key-Modifers(like shift,alt,ctrl)
//!     V                V                       V                 And here we save the corresponding cmd name
std::vector< std::map<unsigned short,std::map<unsigned short,std::string> > > layouts;
std::vector< std::map<unsigned short,std::map<unsigned short,std::string> > > override_layouts;*/ /* the same for override-key combinations
												     which only differ that they still work in
												     text mode */
