#include "Input.h"
#include "../GUI/Console.h"
#include "../Azadi.h"

Input::Input()
 :layouts(1),override_layouts(1)
{
	mode=true; // KeyMode at start
	active_layout=0;
	flush();
	quit=false;
}


bool Input::registerKeyListener(
	std::string cmdName,
	unsigned short defkey,
	eventListener *caller,
	unsigned short mod,
	unsigned char layout,
	bool registerATconsole) // Use this to register Functions to keys
{
	if(layout >= layouts.size()) // Invalid Layout
		return false;

	listeners[cmdName] = caller;
	layouts[layout][defkey][mod] = cmdName;
	return true;
}


bool Input::registerOverrideKeyListener(
	std::string cmdName,
	unsigned short defkey,
	eventListener *caller,
	unsigned short mod,
	unsigned char layout,
	bool registerATconsole) // Use this to register Functions to keys
{
	if(layout >= override_layouts.size()) // Invalid Layout
		return false;

	if(layout >= layouts.size()) // Invalid Layout
		return false;

	listeners[cmdName] = caller;
	override_layouts[layout][defkey][mod] = cmdName;
	layouts[layout][defkey][mod] = cmdName;
	return true;
}

bool Input::setLayout(unsigned char ly)
{
	if(ly < layouts.size())
		active_layout = ly;
	else
		return false;
	return true;
}

unsigned char Input::addLayout()
{
	layouts.resize(layouts.size()+1);
	return layouts.size()-1;
}

void Input::get()
{
	SDL_Event event;

	while (SDL_PollEvent(&event))
	{
		short int mod_tmp = (KMOD_NONE == event.key.keysym.mod) ? MOD_NONE : event.key.keysym.mod;

		if ( event.type == SDL_QUIT )  { quit = true; }
		else if ( event.type == SDL_KEYDOWN )
		{
			keys[event.key.keysym.sym] = 1;
			keysp[event.key.keysym.sym]++;

			if(mode)
			{
				for(Input::binding::iterator key_iterator = layouts[active_layout].begin();
				    key_iterator != layouts[active_layout].end();
				    ++key_iterator)
				{
					for(Input::modbind::iterator mod_iterator = key_iterator->second.begin();
					    mod_iterator != key_iterator->second.end();
					    ++mod_iterator)
					{
						if(key_iterator->first == event.key.keysym.unicode && mod_iterator->first & mod_tmp)
							listeners[mod_iterator->second]->cmdTriggered(mod_iterator->second);
					}
				}
			} else {
				bool key = false;
				for(Input::binding::iterator key_iterator = override_layouts[active_layout].begin();
				    key_iterator != override_layouts[active_layout].end();
				    ++key_iterator)
				{
					for(Input::modbind::iterator mod_iterator = key_iterator->second.begin();
					    mod_iterator != key_iterator->second.end();
					    ++mod_iterator)
					{
						if(key_iterator->first == event.key.keysym.unicode && mod_iterator->first & mod_tmp) {
							listeners[mod_iterator->second]->cmdTriggered(mod_iterator->second);
							key = true;
						}
					}
				}
				if(!key && (
					   event.key.keysym.sym == SDLK_DELETE ||
					   event.key.keysym.sym == SDLK_LEFT ||
					   event.key.keysym.sym == SDLK_RIGHT ||
					   event.key.keysym.sym == SDLK_BACKSPACE ||
					   event.key.keysym.sym == SDLK_UP ||
					   event.key.keysym.sym == SDLK_DOWN ||
					   event.key.keysym.sym == SDLK_END ||
					   event.key.keysym.sym == SDLK_HOME ||
					   event.key.keysym.unicode
					   )
					)
					textListener->charEntered(event.key.keysym.sym, event.key.keysym.unicode);
			}
		}
		else if ( event.type == SDL_KEYUP )
		{
			keys[event.key.keysym.sym] = 0;

			if(mode) {
				for(Input::binding::iterator key_iterator = layouts[active_layout].begin();
				    key_iterator != layouts[active_layout].end();
				    ++key_iterator)
				{
					for(Input::modbind::iterator mod_iterator = key_iterator->second.begin();
					    mod_iterator != key_iterator->second.end();
					    ++mod_iterator)
					{
						if(key_iterator->first == event.key.keysym.sym && mod_iterator->first & mod_tmp)
							listeners[mod_iterator->second]->cmdReleased(mod_iterator->second);
					}
				}
			}
		}
		else if (event.type ==  SDL_MOUSEMOTION)
		{
			mouseX = event.motion.x;
			mouseY = event.motion.y;
		}
		else if (event.type ==  SDL_MOUSEBUTTONDOWN ) {
			mousep[event.button.button]++;
			mouse[event.button.button] = 1;
		}

		else if (event.type ==  SDL_MOUSEBUTTONUP ) {
			mouse[event.button.button] = 0;
		}
	}

}

void Input::flush()
{
    for (int i=0; i<512; i++)
    	keys[i] = 0;
    for (int i=0; i<512; i++)
    	keysp[i] = 0;
    for (int i=0; i<8; i++)
    	mouse[i] = 0;
    for (int i=0; i<8; i++)
    	mousep[i] = 0;
    mouseX = Azadi::screen[0]/2;
    mouseY = Azadi::screen[1]/2;
}

void Input::flushMouseButtons()
{
    for (int i=0; i<8; i++)
    	mouse[i] = 0;
    for (int i=0; i<8; i++)
    	mousep[i] = 0;
}
