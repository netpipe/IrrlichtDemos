#ifndef CLIENT_H
#define CLIENT_H

#include "SupraSocket.h"
#include <sys/time.h>

enum direction
{
    CHAT,
    GAME,
    AUTH,
    HEART
};

//! Class that contains the functions to connect to the master server
class Client
{
	public:
		Client();
		~Client();
		bool Connect();
		bool Connect(const std::string&, unsigned int);
		bool Disconnect();
		bool Pushdata(int direction, const char*);
        bool Pushdata(int direction, const char*, unsigned int size);
		int Receivedata(int direction, char*);
	private:
        char *aenc(char *buffer, int size);
		SupraSocket authSock;
        SupraSocket chatSock;
        SupraSocket gameSock;
        SupraSocket heartSock;
};

#endif

