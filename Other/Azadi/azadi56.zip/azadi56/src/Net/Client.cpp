#include "Client.h"
#include "../GUI/Console.h"
#include "../CustomFunctions.h"
#include "../Azadi.h"

using GUI::Console;

static void sig_func(int);

//! Client constructor
Client::Client()
{
    
}

//! Client destructor
Client::~Client()
{
    authSock.Disconnect();
    gameSock.Disconnect();
    chatSock.Disconnect();
}

//! Connects to the master server
bool Client::Connect()
{
    char *buff = new char[100];
    std::string buffer;
    unsigned int authPort = 7672;
    unsigned int chatPort = 7673;
    unsigned int gamePort = 7674;
    unsigned int heartPort = 7672;
    std::string server1("ame.yomogi-soft.com");
    std::string server2("127.0.0.1");
    
    char ack[] = "AZSERV001AACK";
    char req[] = "AZCLIENV001AREQ";
    char auth[] = "ACK: AUTH";
    char key[] = "AUTH: sldfv-98EFJLSD9aPauLJW";
    char fin[] = "Authenticated";
    
    // Really need to get a server list or something
    authSock.Settype(1); // set the socket to SOCK_STREAM
    chatSock.Settype(2); // set the sock to SOCK_DGRAM
    gameSock.Settype(2); // set the sock to SOCK_DGRAM
    heartSock.Settype(2); // set the sock to SOCK_DGRAM
    
    if ((authSock.Connect((char*)server1.c_str(), authPort)<0) &&
    (authSock.Connect((char*)server2.c_str(), authPort, true) <0))
        //if ((sock.Connect((char*)testy.c_str(), port, true) <0))
    {
        printf("Error connecting to host\n");
        return false;
    }
    // This should all be done under encryption
    Receivedata(AUTH, buff);
    if (strcmp(buff, ack)!=0)
        return false;
    
    // Request for authentication
    Pushdata(AUTH, req);
    Receivedata(AUTH, buff);
    
    if (strcmp(buff, auth)==0)
    {
        Pushdata(AUTH, key);
        Receivedata(AUTH, buff);
        if (strcmp(buff, fin) == 0)
        {
            printf("%s\n", buff);
            
            // Connect the chat
            if ((chatSock.Connect((char*)server1.c_str(), chatPort) < 0) &&
            (chatSock.Connect((char*)server2.c_str(), chatPort, true) < 0))
                return false;
            
            // Connect the gamedata
            if ((gameSock.Connect((char*)server1.c_str(), gamePort) < 0) &&
            (gameSock.Connect((char*)server2.c_str(), gamePort, true) < 0))
                return false;
            
            // Connect the heartbeat
            if ((heartSock.Connect((char*)server1.c_str(), heartPort) < 0) &&
            (heartSock.Connect((char*)server2.c_str(), heartPort, true) < 0))
                return false;
            
            Pushdata(CHAT, (Azadi::playerName + " logged in").c_str());
            
            return true;
        }
        printf("Authentication failure\n");
        return false;
    }
    else
        printf("Authentication failure\n");
    return false;
}

//! Connects to the specified server
bool Client::Connect(const std::string& server, unsigned int port)
{
    authSock.Settype(1);
    if ((authSock.Connect((char*)server.c_str(), port) < 0))
    {
        printf("Error connecting to host\n");
        return false;
    }
    return true;
}

//! Disconnects from the master server
bool Client::Disconnect()
{
    authSock.Disconnect();
    gameSock.Disconnect();
    chatSock.Disconnect();
    return true;
}

//! Send data down the wire
bool Client::Pushdata(int direction, const char *buffer)
{
    char secondBuff[strlen(buffer)+1];
    memset(secondBuff, 0, strlen(buffer)+1);
    secondBuff[0] = strlen(buffer);
    strcat(secondBuff, buffer);
    aenc(secondBuff, strlen(secondBuff));
    if (direction==AUTH)
        authSock.Send(secondBuff, strlen(secondBuff));
    else if (direction==CHAT)
        chatSock.Send(secondBuff, strlen(secondBuff));
    else if (direction==GAME)
        gameSock.Send(secondBuff, strlen(secondBuff));
    else if (direction==HEART)
        heartSock.Send(secondBuff, strlen(secondBuff));
    return true;
}

bool Client::Pushdata(int direction, const char *buffer, unsigned int size)
{
    char secondBuff[size+1];
    memset(secondBuff, 0, size+1);
    secondBuff[0] = size;
    strcat(secondBuff, buffer);
    aenc(secondBuff, size+1);
    if (direction==AUTH)
        authSock.Send(secondBuff, strlen(secondBuff));
    else if (direction==CHAT)
        chatSock.Send(secondBuff, strlen(secondBuff));
    else if (direction==GAME)
        gameSock.Send(secondBuff, strlen(secondBuff));
    else if (direction==HEART)
        heartSock.Send(secondBuff, strlen(secondBuff));
    return true;
}

//! Receive data from the wire
int Client::Receivedata(int direction, char* buffer)
{
    int dir = direction;
    char *sizeOfBuff = new char[256];
    int returned=0;
    if (dir==AUTH)
        authSock.Recv(sizeOfBuff, 1, true, false);
    else if(dir==CHAT)
        chatSock.Recv(sizeOfBuff, 1, true, true);
    else if(dir==GAME)
        gameSock.Recv(sizeOfBuff, 1, true, true);
    else
    {
        delete [] sizeOfBuff;
        return 0;
    }
    if (strlen(sizeOfBuff)==0)
    {
        delete [] sizeOfBuff;
        return 0;
    }
    sizeOfBuff = aenc(sizeOfBuff, 1);
    if (dir == CHAT || dir == GAME)
        sizeOfBuff[0]++;
    if (dir==AUTH)
        returned = authSock.Recv(buffer, (int)sizeOfBuff[0], true, false);
    else if(dir==CHAT)
        returned = chatSock.Recv(buffer, (int)sizeOfBuff[0], true, false);
    else if(dir==GAME)
        returned = gameSock.Recv(buffer, (int)sizeOfBuff[0], true, false);
    aenc(buffer, returned);
    buffer[returned]=0;
    if (dir == CHAT || dir == GAME)
    {
        char tempbuff[sizeOfBuff[0]];
        strscpy(tempbuff, buffer, 1, sizeOfBuff[0]);
        strcpy(buffer, tempbuff);
        buffer[sizeOfBuff[0]]=0;
    }
    delete [] sizeOfBuff;
    return returned;
}

char *Client::aenc(char *buff, int size)
{
    char buffer[size];
    memset(buffer, 0, size);
    strncpy(buffer, buff, size);
    char key[70] = "adsjf;la jdsflkajds f3q09v8b[0bt4hbg;lkrjlbnz,xv-a980c8vuwq3rjgjsfad";
    for (unsigned int i = 0; i < size; ++i)
    {
        for (unsigned int ii = 0; ii < strlen(key); ++ii)
        {
            int x, y, z;
            buffer[i] = buffer[i] ^ key[ii];
            x = 0x0000ff;
            buffer[i] = buffer[i] ^ x;
            x >>= 8;
            y = x & 0x0000ff;
            buffer[i] = buffer[i] ^ y;
            x >>= 8;
            z = y & 0x0000ff;
            buffer[i] = buffer[i] ^ z;
        }
    }
    strncpy(buff, buffer, size);
    return buff;
}
