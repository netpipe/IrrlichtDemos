#ifndef SHADER_H
#define SHADER_H

#include <string>
#include "../FileSystem/FileSystem.h"
#include "../GUI/Console.h"

//! Global that tells whether or not shaders are working
extern bool usingShaders;

/*! A class that has the sole purpose of setting up the Shader context
   Should be called once in the init only */
class ShaderContext
{
	public:
		ShaderContext();
};

//! GLSL vertex/pixel shader class
class Shader
{
	public:
		Shader();
		~Shader();
		void setType(int type);
		void loadShader(const std::string& filename);
		unsigned int shaderID();
	private:
		unsigned int ShaderID;
		std::string shaderSource;
		fileSystem shaderFile;
};

//! GLSL shader program class
class Program
{
	public:
		Program();
		~Program();
		unsigned int NewProgram();
		void Attach(unsigned int);
		void Link();
		void BindShader();
	private:
		unsigned int ProgramID;
};

class ShaderFactory
{
    public:
        ShaderFactory();
        ~ShaderFactory();
        unsigned int loadShaders(std::vector<std::string>);
        void removeProgram(unsigned int);
        void bindShader(unsigned int);
        void useShaders(bool);
    private:
        std::vector<Program> Programs;
        bool usingShaders;
};

extern ShaderFactory shader_factory;

#endif
