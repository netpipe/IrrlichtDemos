#include "Shader.h"
#include <cstdio>
#ifndef __OSX__
	#include <GL/gl.h>
	#include <GL/glext.h>
#else
	#include <OpenGL/gl.h>
	#include <OpenGL/glext.h>
#endif
#include <cassert>

#ifdef WIN32
#include <wtypes.h>
#include <wingdi.h>
#elif !defined(__APPLE__)
#include <GL/glx.h>
#endif

/*======================================================
  ======================================================

	Dynamically figures out which GLSlang your
	implementation supports and uses it!

  =====================================================
  =====================================================
*/

using GUI::Console;

#ifndef __OSX__
PFNGLCREATESHADERPROC glCreateShader = NULL;
PFNGLSHADERSOURCEPROC glShaderSource = NULL;
PFNGLCOMPILESHADERPROC glCompileShader = NULL;
PFNGLGETSHADERIVPROC glGetShaderiv = NULL;
PFNGLGETPROGRAMIVPROC glGetProgramiv = NULL;
PFNGLGETSHADERINFOLOGPROC glGetShaderInfoLog = NULL;
PFNGLCREATEPROGRAMPROC glCreateProgram = NULL;
PFNGLATTACHSHADERPROC glAttachShader = NULL;
PFNGLDETACHSHADERPROC glDetachShader = NULL;
PFNGLLINKPROGRAMPROC glLinkProgram = NULL;
PFNGLGETPROGRAMINFOLOGPROC glGetProgramInfoLog = NULL;
PFNGLUSEPROGRAMPROC glUseProgram = NULL;
PFNGLVALIDATEPROGRAMPROC glValidateProgram = NULL;

// OpenGL 1.5 specific
PFNGLGETOBJECTPARAMETERIVARBPROC glGetObjectParameteriv = NULL;
PFNGLGETOBJECTPARAMETERFVARBPROC glGetObjectParameterfv = NULL;
PFNGLGETINFOLOGARBPROC glGetInfoLog = NULL;
#endif

//! Sets up the shader context (The constructor is the only thing available in the ShaderContext class)
ShaderContext::ShaderContext()
{
    #ifdef WIN32
        #define uglGetProcAddress(x) wglGetProcAddress(x)
    #endif
    #if !defined(__APPLE__) && !defined(WIN32)
        #define uglGetProcAddress(x) (*glXGetProcAddress)((const GLubyte *)(x))
    #endif

	console << Console::log << Console::medium << "=====================================" << Console::endl();
	console << Console::log << Console::medium << (std::string)(const char*)glGetString(GL_VENDOR) << Console::endl();
	console << Console::log << Console::medium << (std::string)(const char*)glGetString(GL_RENDERER) << Console::endl();
	console << Console::log << Console::medium << "OpenGL " << (std::string)(const char*)glGetString(GL_VERSION) << Console::endl();
	console << Console::log << Console::medium << "=====================================" << Console::endl();

    #if defined(__APPLE__)
        // FUGLY
        goto skip;
    #endif

    #ifndef __OSX__
	
	bool usingShaders = false;
    float shaderVersion = 0.0;
	float gl_version;

	gl_version = atof((const char*)glGetString(GL_VERSION));

	if (gl_version >=1.5f)
	{
    	glCreateShader = (PFNGLCREATESHADERPROC) uglGetProcAddress("glCreateShader");
    	if (glCreateShader != NULL)
    	{
        	glShaderSource = (PFNGLSHADERSOURCEPROC) uglGetProcAddress("glShaderSource");
        	glCompileShader = (PFNGLCOMPILESHADERPROC) uglGetProcAddress("glCompileShader");
        	glGetShaderiv = (PFNGLGETSHADERIVPROC) uglGetProcAddress("glGetShaderiv");
        	glGetProgramiv = (PFNGLGETPROGRAMIVPROC) uglGetProcAddress("glGetProgramiv");
        	glGetProgramInfoLog = (PFNGLGETPROGRAMINFOLOGPROC) uglGetProcAddress("glGetProgramInfoLog");
        	glGetShaderInfoLog = (PFNGLGETSHADERINFOLOGPROC) uglGetProcAddress("glGetShaderInfoLog");
        	glCreateProgram = (PFNGLCREATEPROGRAMPROC) uglGetProcAddress("glCreateProgram");
        	glAttachShader = (PFNGLATTACHSHADERPROC) uglGetProcAddress("glAttachShader");
        	glDetachShader = (PFNGLDETACHSHADERPROC) uglGetProcAddress("glDetachShader");
        	glLinkProgram = (PFNGLLINKPROGRAMPROC) uglGetProcAddress("glLinkProgram");
        	glGetProgramInfoLog = (PFNGLGETPROGRAMINFOLOGPROC) uglGetProcAddress("glGetProgramInfoLog");
        	glUseProgram = (PFNGLUSEPROGRAMPROC) uglGetProcAddress("glUseProgram");
        	glValidateProgram = (PFNGLVALIDATEPROGRAMPROC) uglGetProcAddress("glValidateProgram");

        	shaderVersion = 110;
    	}
    	else
    	{
       		glCreateShader = (PFNGLCREATESHADEROBJECTARBPROC) uglGetProcAddress("glCreateShaderObjectARB");
        	glShaderSource = (PFNGLSHADERSOURCEARBPROC) uglGetProcAddress("glShaderSourceARB");
        	glCompileShader = (PFNGLCOMPILESHADERARBPROC) uglGetProcAddress("glCompileShaderARB");
        	glCreateProgram = (PFNGLCREATEPROGRAMOBJECTARBPROC) uglGetProcAddress("glCreateProgramObjectARB");
        	glGetObjectParameteriv = (PFNGLGETOBJECTPARAMETERIVARBPROC) uglGetProcAddress("glGetObjectParameterARB");
        	glGetInfoLog = (PFNGLGETINFOLOGARBPROC) uglGetProcAddress("glGetInfoLogARB");
        	glAttachShader = (PFNGLATTACHOBJECTARBPROC) uglGetProcAddress("glAttachObjectARB");
        	glDetachShader = (PFNGLDETACHOBJECTARBPROC) uglGetProcAddress("glDetachObjectARB");
        	glLinkProgram = (PFNGLLINKPROGRAMARBPROC) uglGetProcAddress("glLinkProgramARB");
        	glUseProgram = (PFNGLUSEPROGRAMOBJECTARBPROC) uglGetProcAddress("glUseProgramObjectARB");

        	shaderVersion = 100;
    	}
	}
    if (glCreateShader != NULL)
    {
        usingShaders = true;
#ifndef NDEBUG
        console << Console::log << Console::highish << "OpenGL Shading Language version " << shaderVersion << " supported" << Console::endl();
#endif
    }
    else
    {
#ifndef NDEBUG
        console << Console::log << Console::highish << "OpenGL Shading Language is unsupported on your platform" << Console::endl();
#endif
    }

    shader_factory.useShaders(usingShaders);
	#endif
#if defined(__APPLE__)
skip:;
#endif
}

Shader::Shader()
{

}

Shader::~Shader()
{

}

//! Returns the shader's ID number
unsigned int Shader::shaderID()
{
	return ShaderID;
}

void Shader::setType(int type)
{
    if (type == GL_VERTEX_SHADER)
        ShaderID = glCreateShader(GL_VERTEX_SHADER);
    else if (type == GL_FRAGMENT_SHADER)
        ShaderID = glCreateShader(GL_FRAGMENT_SHADER);
}

//! Loads a shader file into the class
void Shader::loadShader(const std::string& filename)
{
    std::string fileName("./data/Shaders/");
    fileName += filename;
    std::ifstream shaderfile;
    char temp[1000];
    std::string shader;
    int ret;

    console << Console::log << Console::highish << "Loading shader: " << filename << Console::endl();
    shaderfile.open((char*)fileName.c_str(), std::ios::in);
    if (shaderfile.fail())
    {
        console << Console::log << Console::medium << "Shader " << filename << " could not be opened" << Console::endl();
        assert(1==0);
    }
    while (!(shaderfile.eof()))
    {
        shaderfile.getline(temp, 1000);
        shader+=temp;
        shader+="\n";
    }
    shaderfile.close();
    GLchar *tempo = new GLchar[shader.size()];
    strcpy((char*)tempo, shader.c_str());
    glShaderSource(ShaderID, 1, (const GLchar**)&tempo, NULL);
    glCompileShader(ShaderID);
    glGetShaderiv(ShaderID, GL_COMPILE_STATUS, (GLint*)&ret);
    if (ret == GL_TRUE)
        console << Console::log << Console::highish << "Shader " << filename << " loaded" << Console::endl();
    else
    {
        GLchar *infolog = new char[300];
        GLsizei length;
        glGetShaderInfoLog(ShaderID, 300, &length, infolog);
        printf("Error occured: %s\n", infolog);
		delete [] infolog;
    }
    assert(ret==GL_TRUE);
}

//! Creates a GLSL program
Program::Program()
{
    ProgramID = glCreateProgram();
}

Program::~Program()
{

}

//! Does the same thing as the constructor. In case Program gets used in a std::vector or the such
unsigned int Program::NewProgram()
{
    ProgramID = glCreateProgram();
    return ProgramID;
}

//! Attaches either a vertex or a fragment shader to the program
void Program::Attach(unsigned int ShaderID)
{
    glAttachShader(ProgramID, ShaderID);
}

//! Links the shaders together to form an executable shader
void Program::Link()
{
    GLint ret;
    glValidateProgram(ProgramID);
    glGetProgramiv(ProgramID, GL_VALIDATE_STATUS, &ret);
    if (ret!=GL_TRUE)
    {
        char er[200];
        glGetProgramInfoLog(ProgramID, 200, NULL, er);
        printf("Error occured: %s\n", er);
    }
    assert(ret==GL_TRUE);
    glLinkProgram(ProgramID);
    glGetProgramiv(ProgramID, GL_LINK_STATUS, &ret);
    if (ret!=GL_TRUE)
    {
        char er[200];
        glGetProgramInfoLog(ProgramID, 200, NULL, er);
        printf("Error occured: %s\n", er);
    }
    assert(ret==GL_TRUE);
    console << Console::log << Console::highish << "Shaders compiled and linked" << Console::endl();
}

//! Binds the shader, causing following draw functions to use this shader program
void Program::BindShader()
{
    glUseProgram(ProgramID);
}

/*=============================================

    Shader factory implementation

==============================================*/

ShaderFactory::ShaderFactory()
{

}

ShaderFactory::~ShaderFactory()
{

}

unsigned int ShaderFactory::loadShaders(std::vector<std::string> shaders)
{
    if (usingShaders)
    {
        unsigned int size = shaders.size();
        if (size > 0)
        {
            Program temp2;
            Programs.push_back(temp2);
            unsigned int progs = Programs.size();
			Programs[progs].NewProgram();
			Shader temp[shaders.size()];
            for (unsigned int i=0; i < size; i++)
            {
                if (shaders[i].find(".vsh") != std::string::npos)
                    temp[i].setType(GL_VERTEX_SHADER);
                else if (shaders[i].find(".fsh") != std::string::npos)
                    temp[i].setType(GL_FRAGMENT_SHADER);
                else
                    return 0;
                temp[i].loadShader(shaders[i]);
                Programs[progs].Attach(temp[i].shaderID());
            }
            Programs[progs].Link();
            return progs;
        }
        else
        {
            return 0;
        }
    }
    return 0;
}

void ShaderFactory::useShaders(bool opt)
{
    usingShaders = opt;
}

void ShaderFactory::bindShader(unsigned int shaderID)
{
    if(usingShaders)
        Programs[shaderID].BindShader();
}

void ShaderFactory::removeProgram(unsigned int progID)
{

}

