#include "SceneGraph.h"

#include "../GUI/Console.h"

using GUI::Console;

GraphBranch::GraphBranch()
{
    
}

GraphBranch& GraphBranch::branchObj(const std::string& branchName)
{
    return *branch[branchName];
}

void GraphBranch::addObject(GraphChild* newObj)
{
    child[newObj->nodeName] = newObj;
    keys.push_back(newObj->nodeName);
}

void GraphBranch::addBranch(GraphBranch* newBranch, const std::string& name)
{
    branch[name]=newBranch;
}

void GraphBranch::addObject(GraphChild* newObj, std::list<std::string>& branches)
{
    std::string temp = branches.front();
    branches.pop_front();
    if (branches.size() > 1)
    {
        if (branch.count(branches.front()) == 0)
        {
            GraphBranch *newBranch = new GraphBranch;
            addBranch(newBranch, branches.front());
        }
        branch[temp]->addObject(newObj, branches);
    }
    else
        addObject(newObj);
    
    #ifndef NDEBUG
    console << Console::high << Console::normal << "SceneGraph->Registered an object " << newObj->nodeName << " on branch " << branchName << Console::endl();
    #endif
}

void GraphBranch::Draw(std::list<std::string> path)
{
    path.pop_front();
    if (path.size() > 1)
    {
        child[path.front()]->Draw();
        branch[path.front()]->Draw(path);
    }
    else
        child[path.front()]->Draw();
}

void GraphBranch::DrawBranch(std::list<std::string> path)
{
    path.pop_front();
    if (path.size() > 1)
        branch[path.front()]->DrawBranch(path);
    else
    {
        for (unsigned int i = 0; i < unsigned(keys.size()); ++i)
            child[keys[i]]->Draw();
    }
}

GraphChild& GraphBranch::retrieveNode(std::list<std::string> path)
{
    path.pop_front();
    if (path.size() > 1)
        branch[path.front()]->retrieveNode(path);
    else
        return *child[path.front()];
}

SceneGraph::SceneGraph()
{
    #ifndef NDEBUG
    console << Console::log << Console::highish << "Initializing Scene Graph" << Console::endl();
    #endif
}

SceneGraph::~SceneGraph()
{
    
}

long SceneGraph::addObject(GraphChild* newObj, std::list<std::string>& branches)
{
    std::string temp = branches.front();
    SceneGraphID.push_back(branches);
    
    if (branch.count(branches.front()) == 0)
    {
        GraphBranch *newBranch = new GraphBranch;
        addBranch(newBranch, branches.front());
    }
    
    branches.pop_front();
    
    branch[temp]->addObject(newObj, branches);
    
    #ifndef NDEBUG
    console << Console::high << Console::normal << "SceneGraph->Registered an object " << newObj->nodeName << " on the root level" << Console::endl();
    #endif
    
    return SceneGraphID.size();
}

void SceneGraph::addBranch(GraphBranch* newBranch, const std::string& name)
{
    branch[name]=newBranch;
}

void SceneGraph::Draw()
{
    for (unsigned i = 0; i < SceneGraphID.size(); ++i)
    { branch[SceneGraphID[i].front()]->Draw(SceneGraphID[i]); }
}

void SceneGraph::Draw(std::list<std::string> walk)
{
    if (walk.size() > 1)
        branch[walk.front()]->DrawBranch(walk);
    else
        Draw();
}

GraphChild& SceneGraph::getNode(long ID)
{
    std::list<std::string> temp = SceneGraphID[ID];
    return branch[temp.front()]->retrieveNode(temp);
}
