#ifndef SCENEGRAPH_H
#define SCENEGRAPH_H

#include "../vector.h"
#include "../matrix.h"
#include "../Texture/TextureFactory.h"

#include <vector>
#include <string>
#include <map>
#include <list>

class GraphChild
{
    public:
        virtual ~GraphChild(){};
        std::string nodeName;
        std::string nodeParent;
        virtual void Draw();
};

class GraphMeshChild : public GraphChild
{
    std::vector<vector3<GLfloat> > vertices;
    virtual void Draw(){};
};

class GraphTransformChild : public GraphChild
{
    public:
        matrix4<GLfloat> transformMatrix;
        void Draw()
        {
            matrix4<GLfloat> *tm = &transformMatrix;
            GLfloat m[16]={tm->W1, tm->X1, tm->Y1, tm->Z1,
                           tm->W2, tm->X2, tm->Y2, tm->Z2,
                           tm->W3, tm->X3, tm->Y3, tm->Z3,
                           tm->W4, tm->X4, tm->Y4, tm->Z4};
            glMultMatrixf(m);
        }
};

class GraphTranslateChild : public GraphChild
{
    public:
        vector3<GLfloat> translatev;
        void Draw()
        {
            glTranslatef(translatev.X, translatev.Y, translatev.Z);
        }
};

class GraphRotateChild : public GraphChild
{
    public:
        quaternion<GLfloat> rotatev;
        void Draw()
        {
            glRotatef(rotatev.W, rotatev.X, rotatev.Y, rotatev.Z);
        }
};

class GraphTextureChild : public GraphChild
{
    public:
        GraphTextureChild();
        unsigned int TextureID;
        void Draw()
        {
            texture_factory.applyTexture(TextureID);
        }
};

class GraphBranch
{
    public:
        GraphBranch();
        virtual ~GraphBranch(){};
        std::string branchName;
        void addObject(GraphChild*);
        void addObject(GraphChild*, std::list<std::string>& branch);
        void addBranch(GraphBranch*, const std::string& name);
        void addBranch(GraphBranch*, std::list<std::string>& branches);
        GraphBranch& branchObj(const std::string& branchName);
        void Draw(std::list<std::string> path);
        void DrawBranch(std::list<std::string> walk);
        GraphChild& retrieveNode(std::list<std::string>);
    private:
        std::map<std::string, GraphChild*> child;
        std::vector<std::string> keys;
        std::map<std::string, GraphBranch*> branch;
};

class SceneGraph
{
    public:
        SceneGraph();
        ~SceneGraph();
        long addObject(GraphChild*, std::list<std::string>& branches);
        void addBranch(GraphBranch*, const std::string& name);
        void Draw();
        void Draw(std::list<std::string> walk);
        GraphChild& getNode(long ID);
    private:
        std::vector<std::list<std::string> > SceneGraphID;
        std::map<std::string, GraphBranch*> branch;
};

extern SceneGraph scene_graph;

#endif
