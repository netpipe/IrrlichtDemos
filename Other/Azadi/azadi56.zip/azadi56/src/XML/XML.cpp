#include "XML.h"

using GUI::Console;

//! The xml parser construtor, specify a filename in the string argument for the parser to parse.
XMLParser::XMLParser(const std::string& filename)
{
    std::string temp("./data/");
    temp += filename;
    if (document.LoadFile(temp.c_str()) == false)
    {
        console << Console::error << Console::highish << "XMLParser->Could not load file: " << filename << Console::endl();
        loaded = false;
    }
    else
    {
        #ifndef NDEBUG
        console << Console::log << Console::highish << "XMLParser->Loaded: " << filename << Console::endl();
        #endif
        loaded = true;
    }
    TiXmlHandle handle(&document);
    TiXmlElement *version = handle.FirstChild("Azadi").Element();
    if (version)
    {
        azadiversion = (float)atof(version->Attribute("version"));
        #ifndef NDEBUG
        console << Console::log << Console::highish << "XMLParser->File parsed for Azadi version " << azadiversion << Console::endl();
        #endif
    }
    else
    {
        console << Console::error << Console::highish << "XMLParser->Invalid XML file " << filename << Console::endl();
    }
}

XMLParser::~XMLParser()
{
    
}

//! Returns the screen template of the specified resolution
screenTemplate XMLParser::GetTemplate(unsigned int x, unsigned int y)
{
    screenTemplate *temp;
    temp = new screenTemplate();
    TiXmlHandle handle(&document);
    unsigned int iterator=0;
    unsigned int panelIterator=0;
    unsigned int messageIterator=0;
    unsigned int textureIterator=0;
    unsigned int numericIterator=0;
    unsigned int buttonIterator=0;
    bool done;
    
    done = false;
    iterator = 0;
    temp = new screenTemplate();
    while (!done)
    {
        TiXmlElement *resolution = handle.FirstChild("Azadi").Child("Screen", iterator).Element();
        if (resolution)
        {
            if (unsigned(atoi(resolution->Attribute("x"))) == x)
            {
                if (unsigned(atoi(resolution->Attribute("y"))) == y)
                {
                    panelIterator = 0;
                    TiXmlElement *pan = handle.FirstChild("Azadi").Child("Screen", iterator).Child("Panel", panelIterator).Element();
                    while (pan)
                    {
                        Panel tempPanel;
                        try
                        {
                            tempPanel.name = pan->Attribute("name");
                            tempPanel.x = atoi(pan->Attribute("x"));
                            tempPanel.y = atoi(pan->Attribute("y"));
                            tempPanel.w = atoi(pan->Attribute("width"));
                            tempPanel.h = atoi(pan->Attribute("height"));
                        }
                        catch(...)
                        {
                            console << Console::error << Console::medium << "Malformed Panel element in XML file" << Console::endl();
                            assert(1==0);
                        }
                        
                        textureIterator = 0;
                        TiXmlElement *tex = handle.FirstChild("Azadi").Child("Screen", iterator).Child("Panel", panelIterator).Child("Texture", textureIterator).Element();
                        while (tex)
                        {
                            LayTex panTex;
                            try
                            {
                                panTex.name = tex->Attribute("name");
                            }
                            catch(...)
                            {
                                console << Console::error << Console::medium << "Malformed Texture element in Panel element of XML file" << Console::endl();
                                assert(1==0);
                            }
                            tempPanel.textures.push_back(panTex);
                            
                            textureIterator ++;
                            tex = handle.FirstChild("Azadi").Child("Screen", iterator).Child("Panel", panelIterator).Child("Texture", textureIterator).Element();
                        }
                        
                        temp->panels.push_back(tempPanel);
                        
                        panelIterator ++;
                        pan = handle.FirstChild("Azadi").Child("Screen", iterator).Child("Panel", panelIterator).Element();
                    }
                    messageIterator = 0;
                    TiXmlElement *mes = handle.FirstChild("Azadi").Child("Screen", iterator).Child("MessageArea", messageIterator).Element();
                    while(mes)
                    {
                        MessageArea messArea;
                        try
                        {
                            messArea.name = mes->Attribute("name");
                            messArea.x = atoi(mes->Attribute("x"));
                            messArea.y = atoi(mes->Attribute("y"));
                            messArea.w = atoi(mes->Attribute("width"));
                            messArea.h = atoi(mes->Attribute("height"));
                            messArea.font = mes->Attribute("font");
                            messArea.fontpt = atoi(mes->Attribute("point"));
                            messArea.maxLines = atoi(mes->Attribute("maxlines"));
                            TiXmlElement *offsets = handle.FirstChild("Azadi").Child("Screen", iterator).Child("MessageArea", messageIterator).FirstChild("TextOffset").Element();
                            messArea.textoffsetx = (offsets)?atoi(offsets->Attribute("x")):0;
                            messArea.textoffsety = (offsets)?atoi(offsets->Attribute("y")):0;
                        }
                        catch(...)
                        {
                            console << Console::error << Console::medium << "Malformed MessageArea element in XML file" << Console::endl();
                            assert(1==0);
                        }
                        
                        text_engine.loadFont(messArea.font);
                        text_engine.genPointSize(messArea.font, messArea.fontpt);
                        
                        textureIterator = 0;
                        TiXmlElement *tex = handle.FirstChild("Azadi").Child("Screen", iterator).Child("MessageArea", messageIterator).Child("Texture", textureIterator).Element();
                        while (tex)
                        {
                            LayTex mesTex;
                            try
                            {
                                mesTex.name = tex->Attribute("name");
                            }
                            catch(...)
                            {
                                console << Console::error << Console::medium << "Malformed Texture element in MessageArea element of XML file" << Console::endl();
                                assert(1==0);
                            }
                            messArea.textures.push_back(mesTex);
                            
                            textureIterator ++;
                            tex = handle.FirstChild("Azadi").Child("Screen", iterator).Child("MessageArea", panelIterator).Child("Texture", textureIterator).Element();
                        }
                        
                        temp->messageAreas.push_back(messArea);
                        
                        messageIterator ++;
                        mes = handle.FirstChild("Azadi").Child("Screen", iterator).Child("MessageArea", messageIterator).Element();
                    }
                    numericIterator = 0;
                    TiXmlElement *num = handle.FirstChild("Azadi").Child("Screen", iterator).Child("NumericArea", numericIterator).Element();
                    while(num)
                    {
                        NumericArea numArea;
                        try
                        {
                            numArea.name = num->Attribute("name");
                            numArea.x = atoi(num->Attribute("x"));
                            numArea.y = atoi(num->Attribute("y"));
                            numArea.w = atoi(num->Attribute("width"));
                            numArea.h = atoi(num->Attribute("height"));
                            numArea.type = (strcmp(num->Attribute("type"), "integer") == 0) ?0:1;
                            numArea.font = num->Attribute("font");
                            numArea.fontpt = atoi(num->Attribute("point"));
                            TiXmlElement *offsets = handle.FirstChild("Azadi").Child("Screen", iterator).Child("NumericArea", numericIterator).FirstChild("TextOffset").Element();
                            numArea.textoffsetx = (offsets!=NULL)?atoi(offsets->Attribute("x")):0;
                            numArea.textoffsety = (offsets!=NULL)?atoi(offsets->Attribute("y")):0;
                        }
                        catch(...)
                        {
                            console << Console::error << Console::medium << "Malformed NumericArea element in XML file" << Console::endl();
                            assert(1==0);
                        }
                        
                        text_engine.loadFont(numArea.font);
                        text_engine.genPointSize(numArea.font, numArea.fontpt);
                        
                        textureIterator = 0;
                        TiXmlElement *tex = handle.FirstChild("Azadi").Child("Screen", iterator).Child("NumericArea", numericIterator).Child("Texture", textureIterator).Element();
                        while (tex)
                        {
                            LayTex numTex;
                            try
                            {
                                numTex.name = tex->Attribute("name");
                                
                            }
                            catch(...)
                            {
                                console << Console::error << Console::medium << "Malformed Texture element in NumericArea element of XML file" << Console::endl();
                                assert(1==0);
                            }
                            numArea.textures.push_back(numTex);
                            
                            textureIterator ++;
                            tex = handle.FirstChild("Azadi").Child("Screen", iterator).Child("NumericArea", panelIterator).Child("Texture", textureIterator).Element();
                        }
                        
                        temp->numericAreas.push_back(numArea);
                        
                        numericIterator ++;
                        num = handle.FirstChild("Azadi").Child("Screen", iterator).Child("NumericArea", numericIterator).Element();
                    }
                    buttonIterator=0;
                    TiXmlElement *but = handle.FirstChild("Azadi").Child("Screen", iterator).Child("ButtonArea", buttonIterator).Element();
                    while (but)
                    {
                        ButtonArea tempb;
                        try
                        {
                            tempb.name = but->Attribute("name");
                            tempb.x = atoi(but->Attribute("x"));
                            tempb.y = atoi(but->Attribute("y"));
                            tempb.w = atoi(but->Attribute("width"));
                            tempb.h = atoi(but->Attribute("height"));
                            tempb.command = but->Attribute("command");
                        }
                        catch(...)
                        {
                            console << Console::error << Console::medium << "Malformed ButtonArea element in XML file" << Console::endl();
                            assert(1==0);
                        }
                        textureIterator=0;
                        TiXmlElement *tex = handle.FirstChild("Azadi").Child("Screen", iterator).Child("ButtonArea", buttonIterator).Child("Texture", textureIterator).Element();
                        while (tex)
                        {
                            LayTex butTex;
                            try
                            {
                                butTex.name = tex->Attribute("name");
                                
                            }
                            catch(...)
                            {
                                console << Console::error << Console::medium << "Malformed Texture element in ButtonArea element of XML file" << Console::endl();
                                assert(1==0);
                            }
                            tempb.textures.push_back(butTex);
                            
                            textureIterator++;
                            tex = handle.FirstChild("Azadi").Child("Screen", iterator).Child("ButtonArea", buttonIterator).Child("Texture", textureIterator).Element();
                        }
                        temp->buttonAreas.push_back(tempb);
                        
                        buttonIterator++;
                        but = handle.FirstChild("Azadi").Child("Screen", iterator).Child("ButtonArea", buttonIterator).Element();
                    }
                    TiXmlElement *juk = handle.FirstChild("Azadi").Child("Screen", iterator).FirstChild("JukeBox").Element();
                    if (juk)
                    {
                        JukePanel juke;
                        try
                        {
                            juke.x = atoi(juk->Attribute("x"));
                            juke.y = atoi(juk->Attribute("y"));
                            juke.w = atoi(juk->Attribute("width"));
                            juke.h = atoi(juk->Attribute("height"));
                            juke.font = juk->Attribute("font");
                            juke.ps1 = atoi(juk->Attribute("pointsize1"));
                            juke.ps2 = atoi(juk->Attribute("pointsize2"));
                            juke.ps3 = atoi(juk->Attribute("pointsize3"));
                            juke.maxVisible = atoi(juk->Attribute("maxvis"));
                            TiXmlElement *playOffset = handle.FirstChild("Azadi").Child("Screen", iterator).FirstChild("JukeBox").FirstChild("NowPlayingOffset").Element();
                            if (playOffset)
                            {
                                juke.nowPlayingx = atoi(playOffset->Attribute("x"));
                                juke.nowPlayingy = atoi(playOffset->Attribute("y"));
                                juke.playMaxWidth = atoi(playOffset->Attribute("maxwidth"));
                            }
                            TiXmlElement *texOffset = handle.FirstChild("Azadi").Child("Screen", iterator).FirstChild("JukeBox").FirstChild("TextOffset").Element();
                            if (texOffset)
                            {
                                juke.textoffsetx = atoi(texOffset->Attribute("x"));
                                juke.textoffsety = atoi(texOffset->Attribute("y"));
                                juke.textMaxWidth = atoi(texOffset->Attribute("maxwidth"));
                            }
                            TiXmlElement *volOffset = handle.FirstChild("Azadi").Child("Screen", iterator).FirstChild("JukeBox").FirstChild("Volume").Element();
                            if (volOffset)
                            {
                                juke.volumeOffsetx = atoi(volOffset->Attribute("x"));
                                juke.volumeOffsety = atoi(volOffset->Attribute("y"));
                                juke.volumeWidth = atoi(volOffset->Attribute("width"));
                                juke.volumeHeight = atoi(volOffset->Attribute("height"));
                            }
                        }
                        catch(...)
                        {
                            console << Console::error << Console::medium << "Malformed JukeBox element in XML file" << Console::endl();
                            assert(1==0);
                        }
                        TiXmlElement *juktex = handle.FirstChild("Azadi").Child("Screen", iterator).FirstChild("JukeBox").FirstChild("Texture").Element();
                        if (juktex)
                        {
                            try
                            {
                                juke.texture = juktex->Attribute("name");
                            }
                            catch(...)
                            {
                                console << Console::error << Console::medium << "Malformed Texture element in JukeBox panel of XML file" << Console::endl();
                                assert(1==0);
                            }
                        }
                        temp->jukePanel = juke;
                    }
                    done = true;
                }
            }
        }
        else
        {
            break;
        }
        iterator++;
    }
    #ifndef NDEBUG
    if (done)
    {
        console << Console::log << Console::highish << "XMLParser->Layout loaded for resolution: " << x << "x" << y << Console::endl();
    }
    else
    {
        console << Console::error << Console::highish << "XMLParser->Could not load layout for resolution: " << x << "x" << y << Console::endl();
    }
    #endif
    return *temp;
}
