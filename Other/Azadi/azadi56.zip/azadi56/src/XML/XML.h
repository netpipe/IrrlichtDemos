#ifndef __XML_H__
#define __XML_H__
#include "tinyxml.h"
#include <string>
#include <cstdlib>

#include "../GUI/Console.h"
#include "../Fonts/Font.h"

typedef struct LayTex
{
	std::string name;
	unsigned int x;
	unsigned int y;
	unsigned int w;
	unsigned int h;
	int textureID;
};

typedef struct Panel
{
	std::string name;
	unsigned int x;
	unsigned int y;
	unsigned int w;
	unsigned int h;
	std::vector<LayTex> textures;
	bool active;
};

typedef struct MessageArea
{
	std::string name;
	unsigned int x;
	unsigned int y;
	unsigned int w;
	unsigned int h;
	std::string font;
	unsigned int fontpt;
	unsigned int textoffsetx;
	unsigned int textoffsety;
    unsigned int maxLines;
	std::vector<LayTex> textures;
	bool active;
};

typedef struct NumericArea
{
	std::string name;
	unsigned int x;
	unsigned int y;
	unsigned int w;
	unsigned int h;
	unsigned int type;
	std::string font;
	unsigned int fontpt;
	unsigned int textoffsetx;
	unsigned int textoffsety;
	std::vector<LayTex> textures;
	bool active;
};

typedef struct ButtonArea
{
    std::string name;
    unsigned int x;
    unsigned int y;
    unsigned int w;
    unsigned int h;
    std::string command;
    std::vector<LayTex> textures;
    bool active;
};

typedef struct JukePanel
{
    unsigned int x;
    unsigned int y;
    unsigned int w;
    unsigned int h;
    unsigned int nowPlayingx;
    unsigned int nowPlayingy;
    unsigned int textoffsetx;
    unsigned int textoffsety;
    unsigned int volumeOffsetx;
    unsigned int volumeOffsety;
    unsigned int volumeWidth;
    unsigned int volumeHeight;
    unsigned int maxVisible;
    std::string texture;
    std::string font;
    unsigned int ps1;
    unsigned int ps2;
    unsigned int ps3;
    unsigned int playMaxWidth;
    unsigned int textMaxWidth;
};

typedef struct screenTemplate
{
	std::vector<Panel> panels;
	std::vector<MessageArea> messageAreas;
	std::vector<NumericArea> numericAreas;
	std::vector<ButtonArea> buttonAreas;
	JukePanel jukePanel;
};

//! XML Parser using the TinyXML library (BSD LICENSE)
class XMLParser
{
	public:
		XMLParser(const std::string&);
		~XMLParser();
		screenTemplate GetTemplate(unsigned int x, unsigned int y);
	private:
		bool loaded;
		TiXmlDocument document;
		float azadiversion;
};


#endif

