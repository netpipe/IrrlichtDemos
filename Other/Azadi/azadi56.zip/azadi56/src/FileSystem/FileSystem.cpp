#include "FileSystem.h"

#ifndef __BIG_ENDIAN__
#define __BIG_ENDIAN__ false
#endif

fileSystem::fileSystem(char* filename,unsigned char flags)
{
    if(filename!=0)
        open(filename,flags);

}


/*! \brief Opens a file

 Access files in archives and dirs
 Use \ to access archivs, e.g data.zip\models/test.azm
 You can access archivs in archivs using data.zip\somedir/some.zip\somefile.amd
 Only relative paths yet (i don't see any reason why this should change --Ano)
 */
void fileSystem::open(char* filename,unsigned char flags)
{
    //! File inside a compressed file? (compressed files are accessed using \)
    //..
    //..
    // Not done yet

    #ifdef WIN32

    //! Convert any / back to \ for Windows
    for(int i=0;filename[i]!='\0';i++)
        if(filename[i] == '/')
            filename[i]='\\';

    #endif

    // Convert the flags to fstream flags
    unsigned char flg=0x00;;
    if(flags & APP)
        flg |= std::ios::app;
    if(flags & ATE)
        flg |= std::ios::ate;
    if(flags & BIN)
        flg |= std::ios::binary;
    if(flags & INP)
        flg |= std::ios::in;
    if(flags & OUTP)
        flg |= std::ios::out;
    if(flags & TRUNC)
        flg |= std::ios::trunc;

	#ifndef __VISCPP__
    file.open(filename,(std::_Ios_Openmode)flg);
	#else
	file.open(filename, flg);
	#endif

    valid = (file) ? true : false;
}



void fileSystem::read(char* buffer, unsigned int num, bool bigendian)
{
	file.read(buffer,num);

	if(__BIG_ENDIAN__ && num >3 && bigendian)
	{
		int size = num;
		while((size/4)!=(int)(size/4)) size++;
		unsigned int i, ii;
		char* buff2 = new char[size];
		// Fixes endian problems between Intel <> PowerPC endianess
		// This only fixes integer/float errors O_o

        for (i=0; i<unsigned((size/4)); i++)
                for(ii=0; ii<4; ii++)
                {
                        buff2[(i * 4) + ii] = buffer[(i *4) + (3-ii)];
                }
        memcpy(buffer,buff2, num);
	}
}

void fileSystem::close(bool destroy)
{
    file.close();
    if(destroy)
        delete this;
}

int fileSystem::getFilesize()
{
    int oldpos = file.tellp(); // Save position
	file.seekp(0, std::ios::end); // Jump to the end
    int size=file.tellp();  // init size var
    file.seekp(oldpos); // jump to prev pos
    return size; // Return size
}


int fileSystem::tellg()
{
    return file.tellg();
}



fileSystem::operator bool()
{
    return valid;
}


void fileSystem::openCompressed(char* filename,unsigned char flags)
{

}


