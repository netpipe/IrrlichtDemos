#ifndef EXTENSIONS_H
#define EXTENSIONS_H

#include <map>
#include <string>

#ifndef __OSX__
#include <GL/gl.h>
#include <GL/glext.h>
#else
#include <OpenGL/gl.h>
#include <OpenGL/glext.h>
#endif

class Extensions
{
    public:
        Extensions();
        ~Extensions();
        void Init();
        bool hasExtension(const std::string& extension);
    private:
        void ParseExtensions();
        void InstantiateExtensions();
        std::map<std::string, bool> extensions;
};

extern Extensions extensions_handler;

#endif
