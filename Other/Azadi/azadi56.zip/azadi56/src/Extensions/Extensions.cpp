#include "Extensions.h"
#include "../GUI/Console.h"

using GUI::Console;

/*=============================================================

 Extension handler function prototypes






 ==============================================================*/

#ifndef __OSX__

PFNGLGENFRAMEBUFFERSEXTPROC glGenFrameBuffersEXT = NULL;
PFNGLGENRENDERBUFFERSEXTPROC glGenRenderBuffersEXT = NULL;
PFNGLBINDRENDERBUFFEREXTPROC glBindRenderBufferEXT = NULL;
PFNGLBINDFRAMEBUFFEREXTPROC glBindFramebufferEXT = NULL;
PFNGLRENDERBUFFERSTORAGEEXTPROC glRenderbufferStorageEXT = NULL;
PFNGLFRAMEBUFFERTEXTURE2DEXTPROC glFramebufferTexture2DEXT = NULL;

#endif









Extensions::Extensions()
{
    console << Console::log << Console::highish << "Extensions handler initializing" << Console::endl();
}

Extensions::~Extensions()
{
    
}

void Extensions::Init()
{
    ParseExtensions();
    InstantiateExtensions();
}

void Extensions::ParseExtensions()
{
    char *extens = new char[1024];
    char *temp = NULL;
    extens = (char*)glGetString(GL_EXTENSIONS);
    temp = strtok(extens, " ");
    while (temp!=NULL)
    {
        extensions[(std::string)temp] = true;
        temp = strtok(NULL, " ");
    }
    #ifndef NDEBUG
    console << GUI::Console::log << GUI::Console::highish << extensions.size() << " opengl extensions available" << GUI::Console::endl();
    #endif
    //    delete extens;
}

void Extensions::InstantiateExtensions()
{
    
}

bool Extensions::hasExtension(const std::string& extension)
{
    if (extensions.count(extension) > 0)
        return true;
    else
        return false;
}
