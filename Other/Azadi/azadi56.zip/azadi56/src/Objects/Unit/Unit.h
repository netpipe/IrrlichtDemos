#ifndef UNIT_H
#define UNIT_H

#include <string>
#include <map>
#include "../../Scripting/ScriptEngine.h"
#include "../../GUI/Console.h"
#include "../../ModelFactory/ModelFactory.h"
#include "../../Physics/Physics.h"

namespace Unit
{
	enum PartType
	{
		WEAPON,
		PROPULSION,
		BODY,
		GENERATOR,
		WING
	};

	enum WeaponType
	{
		INSTANT,
		BALLISTIC,
		CONTROLLABLE,
		INDIRECT
	};

	enum PropulsionType
	{
		WHEEL,
		JET
	};

	class Weapon
	{
		public:
			Weapon();
			Weapon(std::string&);
			void setModel(std::string&);
			void setAttributes(WeaponType type, int damage, int delay, int weight, int powerConsumption);
			void setType(WeaponType type);
			void setDamage(int damage);
			void setDelay(int delay);
			void setWeight(int weight);
			void setPowerConsumption(int powerConsumption);
			~Weapon();

			std::string name;
			WeaponType type;
			int damage;
			int delay;
			int weight;
			int powerConsumption;
			std::string modelname;
			int modelid;
	};

	class Propulsion
	{
		public:
			Propulsion();
			~Propulsion();
			std::string name;
			int powerConsumption;
			int speed;
			int weight;
			std::string modelname;
			int modelid;
	};

	class Body
	{
		public:
			Body();
			~Body();
			std::string name;
			int power;
			int weight;
			int weightThreshold;
			std::string modelname;
			int modelid;
	};

	class Generator
	{
		public:
			Generator();
			~Generator();
			std::string name;
			int power;
			int weight;
			std::string modelname;
			int modelid;
	};

	class Wing
	{
		public:
			Wing();
			~Wing();
			std::string name;
			int powerConsumption;
			int weight;
			std::string modelname;
			int modelid;
	};
}

using namespace Unit;

//! Lua to C++ method interface
class UnitLua : public PhysicsObject
{
	public:
		UnitLua(lua_State *L);
		~UnitLua();
		int loadModel(lua_State *L);
		int attachModel(lua_State *L);
		int removeModel(lua_State *L);

		void updateModel();

		static const char className[];
		static AzLua<UnitLua>::RegType methods[];
	private:
		std::map<int, Weapon> weapons;
		std::map<int, Propulsion> propulsions;
		std::map<int, Generator> generators;
		std::map<int, Wing> wings;
		Body body;

		unsigned int ownerID; // the owner of the unit
		int health;
		int strength;
		int armor;
		int speed;
		int weight;
		int power;

		unsigned long sceneGraphID;
};

#endif
