#include "Unit.h"

using GUI::Console;

namespace Unit
{
    Weapon::Weapon()
    { }
    
    Weapon::Weapon(std::string& modelName)
    {
        model_factory.LoadModel((char*)modelName.c_str());
        modelname=modelName;
    }
    
    Weapon::~Weapon()
    { }
    
    void Weapon::setModel(std::string& modelName)
    {
        model_factory.LoadModel((char*)modelName.c_str());
        modelname=modelName;
    }
    
    void Weapon::setAttributes(WeaponType type, int damage, int delay, int weight, int powerConsumption)
    { }
    
    void Weapon::setType(WeaponType type)
    { }
    
    void Weapon::setDamage(int damage)
    {	}
    
    void Weapon::setDelay(int delay)
    { }
    
    void Weapon::setWeight(int weight)
    {	}
    
    void Weapon::setPowerConsumption(int powerConsumption)
    {	}
    
    Propulsion::Propulsion()
    { }
    
    Propulsion::~Propulsion()
    { }
    
    Body::Body()
    { }
    
    Body::~Body()
    { }
    
    Generator::Generator()
    {	}
    
    Generator::~Generator()
    { }
    
    Wing::Wing()
    { }
    
    Wing::~Wing()
    { }
}

UnitLua::UnitLua(lua_State *L)
{
    type = "Unit";
    name = mangle((std::string)lua_checkstring(L, 1));
    physics_engine.RegisterObject(this);
    console << Console::log << Console::highish << "Instantiated a UnitLua Object named: " << name << Console::endl();
}

UnitLua::~UnitLua()
{
    
}

void UnitLua::updateModel()
{
    
}

int UnitLua::loadModel(lua_State *L)
{
    int temp;
    unsigned int currentRecord;
    int ID;
    temp = (int)lua_checknumber(L, 1);
    ID = model_factory.LoadModel((char*)lua_checkstring(L, 2));
    if (temp==WEAPON)
    {
        currentRecord=unsigned(weapons.size());
        weapons[currentRecord].modelname=lua_tostring(L, 2);
        weapons[currentRecord].modelid = ID;
        return 1;
    }
    else if (temp==PROPULSION)
    {
        currentRecord=unsigned(propulsions.size());
        propulsions[currentRecord].modelname=lua_tostring(L, 2);
        propulsions[currentRecord].modelid=ID;
        return 1;
    }
    else if (temp==BODY)
    {
        body.modelname=lua_tostring(L, 2);
        body.modelid=ID;
        return 1;
    }
    else if (temp==GENERATOR)
    {
        currentRecord=unsigned(generators.size());
        generators[currentRecord].modelname=lua_tostring(L, 2);
        generators[currentRecord].modelid=ID;
        return 1;
    }
    else if (temp==WING)
    {
        currentRecord=unsigned(wings.size());
        wings[currentRecord].modelname=lua_tostring(L, 2);
        wings[currentRecord].modelid=ID;
    }
    return 0;
}

int UnitLua::attachModel(lua_State *L)
{
    return 1;
}

int UnitLua::removeModel(lua_State *L)
{
    return 1;
}

const char UnitLua::className[] = "Unit";
AzLua<UnitLua>::RegType UnitLua::methods[] =
{
    { "loadModel", &UnitLua::loadModel },
    { "attachModel", &UnitLua::attachModel },
    { "removeModel", &UnitLua::removeModel },
    { 0, 0 },
};
