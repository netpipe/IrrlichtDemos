#include "Planet.h"
#include "../../Scripting/ScriptEngine.h"
#include "../../GUI/Console.h"

using GUI::Console;

//! Instantiates a planet
PlanetFactory::PlanetFactory()
{
    console << Console::log << Console::highish << "Initializing Planet Generator" << Console::endl();
}

PlanetFactory::~PlanetFactory()
{
    
}

//! Generates a planet using a seed
unsigned int PlanetFactory::newPlanet(int seed)
{
    noPlanets = unsigned(planets.size());
    // What in the world is the initializing procedure for terrain???
    return 0;
}

//! updates the planets. Should be called quite often
void PlanetFactory::tick()
{
    
}

//! Draws all the planets. Should be called each cycle
void PlanetFactory::draw()
{
    unsigned int i;
    for (i=0; i<noPlanets; i++);
    //		planets[i].Draw();
}

PlanetLua::PlanetLua(lua_State *L)
{
    
}

PlanetLua::~PlanetLua()
{
    
}

int PlanetLua::newPlan(lua_State *L)
{
    
    return 1;
}

const char PlanetLua::className[] = "Planet";
AzLua<PlanetLua>::RegType PlanetLua::methods[] =
{
    { "new" , &PlanetLua::newPlan },
    { 0, 0 }
};
