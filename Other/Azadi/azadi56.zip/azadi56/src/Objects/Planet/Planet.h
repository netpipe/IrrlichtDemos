#ifndef PLANET_H
#define PLANET_H

#include <string>
#include "../../Terrain/Terrain.h"
#include "../../Scripting/ScriptEngine.h"

class PlanetFactory
{
public:
	PlanetFactory();
	~PlanetFactory();
	unsigned int newPlanet(int seed);
	void tick();
	void draw();

private:
	std::map<unsigned int, Terrain> planets;
	unsigned int noPlanets;
};

//! Interface between lua and the Planet class
class PlanetLua
{
public:
	PlanetLua(lua_State *L);
	~PlanetLua();
	int newPlan(lua_State *L);
	static const char className[];
	static AzLua<PlanetLua>::RegType methods[];
};

extern PlanetFactory planet_factory;

#endif
