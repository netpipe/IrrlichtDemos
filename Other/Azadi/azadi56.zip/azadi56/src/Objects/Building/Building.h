#ifndef __BUILDING_H__
#define __BUILDING_H__

#include <string>
#include "../../GUI/Console.h"
#include "../../Scripting/ScriptEngine.h"
#include "../../ModelFactory/ModelFactory.h"
#include "../../vector.h"
#include "../../Physics/Physics.h"
#include "../../SceneGraph/SceneGraph.h"

class BuildingLua : public PhysicsObject, public GraphChild
{
	public:
		BuildingLua(lua_State *L);
		~BuildingLua();
		void applyPhysics();
		int loadModel(lua_State *L);
		int setRotation(lua_State *L);
		int setPosition(lua_State *L);

		static const char className[];
		static AzLua<BuildingLua>::RegType methods[];
		void updateModel();
    private:
		int ModelID;
		int health;
		int armor;
		unsigned long sceneGraphID; // ID number for the scene graph
};

#endif

