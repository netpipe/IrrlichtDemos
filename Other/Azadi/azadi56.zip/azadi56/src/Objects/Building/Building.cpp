#include "Building.h"

using GUI::Console;

BuildingLua::BuildingLua(lua_State *L)
{
    std::list<std::string> nodeHeirarchy;
    unsigned int iterate = (unsigned int)lua_checknumber(L, 2);
    
    type = "Building";
    nodeName = lua_checkstring(L, 1);
    
    for (unsigned int i = 0; i < iterate; ++i)
    {
        nodeHeirarchy.push_back((std::string)lua_checkstring(L, i+2));
    }
    
    name = mangle(nodeName);
    physics_engine.RegisterObject(this);
    //scene_graph.addObject((GraphChild*)this, nodeHeirarchy);
    #ifndef NDEBUG
    console << Console::log << Console::highish << "Instantiated a BuildingLua object named: " << name << Console::endl();
    #endif
}

BuildingLua::~BuildingLua()
{
    
}

// Currently empty need to add the proper things later on when ano finishes up the animation code.
void BuildingLua::GraphChild::Draw()
{
    
}

int BuildingLua::loadModel(lua_State *L)
{
    std::string filename;
    filename = lua_checkstring(L, 1);
    ModelID = model_factory.LoadModel((char*)filename.c_str());
    return 1;
}

void BuildingLua::updateModel()
{
    model_factory.Move(ModelID, position.X, position.Y, position.Z);
}

int BuildingLua::setRotation(lua_State *L)
{
    model_factory.Rotate(ModelID, lua_checknumber(L, 1), lua_checknumber(L, 2), lua_checknumber(L, 3), lua_checknumber(L, 4));
    return 1;
}

int BuildingLua::setPosition(lua_State *L)
{
    position.X = lua_checknumber(L, 1);
    position.Y = lua_checknumber(L, 2);
    position.Z = lua_checknumber(L, 3);
    model_factory.Move(ModelID, position.X, position.Y, position.Z);
    return 1;
}

const char BuildingLua::className[] = "Building";
AzLua<BuildingLua>::RegType BuildingLua::methods[] =
{
    { "Model", &BuildingLua::loadModel },
    { "Rotation", &BuildingLua::setRotation },
    { "Position", &BuildingLua::setPosition },
    { 0, 0 },
};
