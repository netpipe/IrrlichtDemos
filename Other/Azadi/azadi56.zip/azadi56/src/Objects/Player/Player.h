#ifndef PLAYER_H
#define PLAYER_H

#include "../../Physics/Physics.h"
#include "../../GUI/Console.h"
#include "../../vector.h"

class Player : public PhysicsObject
{
    public:
        Player();
        Player(lua_State *L);
        ~Player();
        void setLocation(float x, float y, float z);
        void updateModel();
        void Draw();
        
        std::string name;
        unsigned int sessionId;
    private:
        vector3<float> position;
};

#endif
