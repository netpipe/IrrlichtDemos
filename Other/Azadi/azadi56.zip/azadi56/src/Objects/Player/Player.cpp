#include "Player.h"

using GUI::Console;

Player::Player()
{
    type = "Player";
    name = "Unknown";
}

Player::Player(lua_State *L)
{
    type = "Player";
    name = mangle((std::string)lua_checkstring(L, 1));
    physics_engine.RegisterObject(this);
    console << Console::high << Console::highish << "Instantiated a Player class" << Console::endl();
}

Player::~Player()
{
    
}

void Player::setLocation(float x, float y, float z)
{
    printf("%f - %f - %f\n", x, y, z);
    position.X = x; position.Y = y; position.Z = z;
}

void Player::updateModel()
{
    // Do nothing, as the player doesn't get drawn
}

void Player::Draw()
{
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glTranslatef(position.X, position.Y, position.Z);
    glBegin(GL_TRIANGLES);
    {
        glVertex3f(-1.0, -1.0, 0.0);
        glVertex3f(1.0, -1.0, 0.0);
        glVertex3f(0.0, 1.0, 0.0);
    }
    glEnd();
}
