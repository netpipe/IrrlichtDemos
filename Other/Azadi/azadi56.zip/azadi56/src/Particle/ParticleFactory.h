#ifndef __PARTICLEFACTORY_H__
#define __PARTICLEFACTORY_H__

#include "Particle.h"
#include "../GUI/Console.h"
#include "../Scripting/ScriptEngine.h"
#include <map>

#ifndef __OSX__
	#include <GL/gl.h>
#else
	#include <OpenGL/gl.h>
#endif

//! Generates particles (to do->use sprites as well as points)
class ParticleGenerator
{
	/*!
		This is the particle generator. It differs from the factory that it's the one that generates the particles itself,
		whereas the particle factory generates generators.
	*/
	public:
		ParticleGenerator();
		~ParticleGenerator();
		bool init(vector3<GLfloat> pos, vector3<GLfloat> dir, vector3<GLfloat> color, GLfloat alpha, GLfloat life, GLfloat duration, unsigned int numParts, GLfloat psize, GLfloat spd, GLfloat speeddc);
		int tick();	// Updates particle positions, returns  1 if all the particles are dead
		void draw(float, float, float);
	private:
		std::map<unsigned int,Particle> particles;
		GLfloat size;
		vector3<GLfloat> position;
		vector3<GLfloat> direction;
		vector3<GLfloat> col;
		GLfloat pAlpha;
		GLfloat pLife;
		GLfloat speed;
		GLfloat decayrate;
		unsigned int lastErased;
		unsigned int numParticles;
		unsigned int lastBorn;
};

//!	The particle factory that generates particle generators
class ParticleFactory
{
	public:
		ParticleFactory();
		~ParticleFactory();
		unsigned int newPart(vector3<float> position, vector3<float> direction, vector3<float> color, GLfloat alpha, GLfloat life, GLfloat duration, unsigned int numParts, GLfloat psize, GLfloat spd, GLfloat speeddc);
		void tick();
		void draw(float x, float y, float z);
	private:
		std::map<unsigned int, ParticleGenerator> PartGens;
};

extern ParticleFactory particle_factory;

//! Interface between azadi and lua to generate particles using the scripting engine
class ParticleLua
{
	public:
		ParticleLua(lua_State *L);
		~ParticleLua();
		static const char className[];
		static AzLua<ParticleLua>::RegType methods[];
	private:
		ParticleGenerator particle;
};

#endif
