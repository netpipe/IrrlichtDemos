#include "../vector.h"

class Particle
{
	public:
		Particle();
		~Particle();
		bool isDead();
		bool init(vector3<GLfloat> pos, vector3<GLfloat> dir, vector3<GLfloat> col, GLfloat alpha, GLfloat life, GLfloat spd, GLfloat speeddecay);
		void draw();
		char update();
	private:
		GLfloat position[3];
		GLfloat direction[3];
		GLfloat color[4];
		GLfloat coef;
		GLfloat speed;
		GLfloat decay;
};
