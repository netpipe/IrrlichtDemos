#include "Particle.h"

Particle::Particle()
{
    color[3] = 0.0;
}

Particle::~Particle()
{
    
}

bool Particle::isDead()
{
    return (color[3] <= 0.0);
}

//! Initializes the particle itself
bool Particle::init(vector3<GLfloat> pos, vector3<GLfloat> dir, vector3<GLfloat> col, GLfloat alpha, GLfloat life, GLfloat spd, GLfloat speeddecay)
{
    #ifdef __VEC__
    position[0] = *pos.X;
    position[1] = *pos.Y;
    position[2] = *pos.Z;
    
    direction[0] = *dir.X - *pos.X;
    direction[1] = *dir.Y - *pos.Y;
    direction[2] = *dir.Z - *pos.Z;
    
    color[0] = *col.X;
    color[1] = *col.Y;
    color[2] = *col.Z;
    color[3] = alpha;
    #else
    position[0] = pos.X;
    position[1] = pos.Y;
    position[2] = pos.Z;
    
    direction[0] = dir.X - pos.X;
    direction[1] = dir.Y - pos.Y;
    direction[2] = dir.Z - pos.Z;
    
    color[0] = col.X;
    color[1] = col.Y;
    color[2] = col.Z;
    color[3] = alpha;
    
    #endif
    speed = spd;
    decay = speeddecay;
    
    coef = alpha/life;
    return false;
}

//! Draws the particle
void Particle::draw()
{
    if (color[3] > 0)
    {
        glColor4f(color[0], color[1], color[2], color[3]);
        glVertex3f(position[0], position[1], position[2]);
    }
}

//! Updates the particle's position and color
char Particle::update()
{
    position[0]+=(direction[0] * speed);
    position[1]+=(direction[1] * speed);
    position[2]+=(direction[2] * speed);
    
    if (speed !=0)
        speed *=decay;
    
    if (color[0] > 0)
        color[0] -= coef;
    if (color[1] > 0)
        color[1] -= coef;
    if (color[2] > 0)
        color[2] -= coef;
    color[3] -= coef;
    if (color[3] <=0.0)
        return 1;
    return 0;
}
