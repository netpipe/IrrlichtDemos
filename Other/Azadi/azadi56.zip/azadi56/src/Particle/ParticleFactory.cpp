#include "ParticleFactory.h"

using GUI::Console;

//! Particle generator constructor. Just initializes some values
ParticleGenerator::ParticleGenerator()
{
    lastBorn = 0;
    lastErased = 0;
    
}

ParticleGenerator::~ParticleGenerator()
{
    
}

//! This is a big fat function O_O   Underdocumented at the moment
bool ParticleGenerator::init(vector3<GLfloat> pos, vector3<GLfloat> dir, vector3<GLfloat> color, GLfloat alpha,
                             GLfloat life, GLfloat duration, unsigned int numParts, GLfloat psize, GLfloat spd, GLfloat speeddc)
{
    numParticles = numParts;
    size = psize;
    position = pos;
    direction = dir;
    col = color;
    pAlpha = alpha;
    pLife = life;
    speed = spd;
    decayrate = speeddc;
    
    return true;
}

//! Updates the position of the particles as well as creates new ones
int ParticleGenerator::tick()
{
    unsigned int i;
    unsigned int birthRate;
    vector3<GLfloat> temp;
    
    srand( SDL_GetTicks() );
    
    birthRate = unsigned(lastBorn) + 1;
    
    if (lastBorn < numParticles)
    {
        i = lastBorn;
        lastBorn = birthRate;
    }
    else
    {
        i = 0;
        lastBorn = 0;
    }
    for (; i< birthRate; i++)
    {
        if (particles[i].isDead())
        {
            // Should turn this random generator function into a simplified function for myself
            temp.X = (direction.X + ( rand() / ((double)RAND_MAX + 1) ) ); temp.X -= (rand()/((double)RAND_MAX + 1));
            temp.Y = (direction.Y + ( rand() / ((double)RAND_MAX + 1) ) ); temp.Y -= (rand()/((double)RAND_MAX + 1));
            temp.Z = (direction.Z + ( rand() / ((double)RAND_MAX + 1) ) ); temp.Z -= (rand()/((double)RAND_MAX + 1));
            particles[i].init(position, temp, col, pAlpha, pLife, speed, decayrate);
        }
    }
    
    for(i=0; i<unsigned(particles.size()); i++)
    {
        particles[i].update();
    }
    return 0;
}

//! Draws the particles themselves
void ParticleGenerator::draw(float x, float y, float z)
{
    unsigned int i;
    float dist;
    dist = sqrt(fabs(position.X - x) + fabs(position.Y - y) + fabs(position.Z - z));
    dist *=1.7;
    
    glPointSize((size - dist));
    glBegin(GL_POINTS);
    {
        for (i=0; i< unsigned(particles.size()); i++)
        {
            particles[i].draw();
        }
    }
    glEnd();
}

ParticleFactory::ParticleFactory()
{
    console << Console::highish << Console::log << "Initializing Particle Factory" << Console::endl();
}

ParticleFactory::~ParticleFactory()
{
    
}

//! Creates a new particle generator as the specified position (There has to be a way to make the arguments smaller)
unsigned int ParticleFactory::newPart(vector3<float> position, vector3<float> direction, vector3<float> color, GLfloat alpha, GLfloat life, GLfloat duration, unsigned int numParts, GLfloat psize, GLfloat spd, GLfloat speeddc)
{
    unsigned int iterator;
    iterator = unsigned(PartGens.size());
    PartGens[iterator].init(position, direction, color, alpha, life, duration, numParts, psize, spd, speeddc);
    return iterator;
}

//! Should be called each cycle, as it updates every particle generator
void ParticleFactory::tick()
{
    unsigned int iterator;
    for (iterator=0; iterator < PartGens.size(); iterator ++)
    {
        PartGens[iterator].tick();
    }
}

//! Should be called each cycle as well, calls each particle generator to draw (expensive operation!!!)
void ParticleFactory::draw(float x, float y, float z)
{
    unsigned int iterator;
    for (iterator=0; iterator < PartGens.size(); iterator ++)
    {
        PartGens[iterator].draw(x, y, z);
    }
}

//! Creates an object for lua to use
ParticleLua::ParticleLua(lua_State *L)
{
    console << Console::highish << Console::high << "Instantiated a particle generator" << Console::endl();
    // Does the same thing as NewPart
    particle.init((vector3<GLfloat>)(lua_checknumber(L, 1), lua_checknumber(L, 2), lua_checknumber(L, 3)),
    (vector3<GLfloat>)(lua_checknumber(L, 4), lua_checknumber(L, 5), lua_checknumber(L, 6)),
    (vector3<GLfloat>)(lua_checknumber(L, 7), lua_checknumber(L, 8), lua_checknumber(L, 9)),
    lua_checknumber(L, 10), lua_checknumber(L, 11), lua_checknumber(L, 12), unsigned(lua_checknumber(L, 13)), lua_checknumber(L, 14), lua_checknumber(L, 15), lua_checknumber(L, 16));
}

ParticleLua::~ParticleLua()
{
    
}

const char ParticleLua::className[] = "Particle";
AzLua<ParticleLua>::RegType ParticleLua::methods[] =
{
    { 0, 0 }
};
