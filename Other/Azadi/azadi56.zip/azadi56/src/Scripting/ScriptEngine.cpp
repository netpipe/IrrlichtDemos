#include "../Azadi.h"
#include "ScriptEngine.h"
#include "../GUI/Console.h"
#include "../Sound/SoundFactory.h"
#include "../ModelFactory/ModelFactory.h"
#include "../ModelFactory/ModelLua.h"
#include "../Objects/Unit/Unit.h"
#include "../Objects/Building/Building.h"
#include "../Texture/TextureFactory.h"
#include "../GUI/DrawLua.h"
#include "../GUI/GUI.h"
#include "../GUI/Menu.h"
#include <SDL/SDL.h>
#include <cmath>
#ifdef __OSX__
#include <OpenGL/gl.h>
#else
#include <GL/gl.h>
#endif

using GUI::Console;

std::stack<int> ScriptEngine::returnedInts;
std::stack<float> ScriptEngine::returnedFloats;
std::stack<bool> ScriptEngine::returnedBools;
std::stack<std::string> ScriptEngine::returnedStrings;

//! Azadi's Lua namespace (for lua related functions) these functions have no use other than within the scripting engine only
namespace az_lua
{
    //! Prints a statement to the console - print(x);
    int l_print(lua_State *L)
    {
        console << Console::medium << lua_tostring(L, 1) <<Console::endl();
        return 1;
    }
    
    //! Runs a script - runscript(scriptname);
    int l_runScript(lua_State *L)
    {
        script_engine.runfile(lua_tostring(L, 1));
        return 1;
    }
    
    //! Returns the square root of a given number - sqrt(x);
    int l_sqrt(lua_State *L)
    {
        lua_pushnumber(L, sqrt(lua_tonumber(L, 1)));
        return 1;
    }
    
    //! Returns the sine of a number - sin(x);
    int l_sin(lua_State *L)
    {
        lua_pushnumber(L, sin(lua_tonumber(L, 1)));
        return 1;
    }
    
    //! Returns the cosine of a number - cos(x);
    int l_cos(lua_State *L)
    {
        lua_pushnumber(L, cos(lua_tonumber(L, 1)));
        return 1;
    }
    
    //! Returns the tangent of a number - tan(x);
    int l_tan(lua_State *L)
    {
        lua_pushnumber(L, tan(lua_tonumber(L, 1)));
        return 1;
    }
    
    //! Returns the inverse/arc sine of a number - asin(x);
    int l_asin(lua_State *L)
    {
        lua_pushnumber(L, asin(lua_tonumber(L, 1)));
        return 1;
    }
    
    //! Returns the inverse/arc cosine of a number - acos(x);
    int l_acos(lua_State *L)
    {
        lua_pushnumber(L, acos(lua_tonumber(L, 1)));
        return 1;
    }
    
    //! Returns the inverse/arc tangent of a number - atan(x);
    int l_atan(lua_State *L)
    {
        lua_pushnumber(L, atan(lua_tonumber(L, 1)));
        return 1;
    }
    
    //! Returns a random number - random();
    int l_random(lua_State *L)
    {
        srand(SDL_GetTicks());
        lua_pushnumber(L, (rand() / ((double)RAND_MAX + 1)));
        return 1;
    }
    
    //! Releases the cursor from the hold of the program - releaseCursor();
    int l_releaseCursor(lua_State *L)
    {
        SDL_ShowCursor(SDL_ENABLE);
        return 1;
    }
    
    //! Captures the cursor - captureCursor();
    int l_captureCursor(lua_State *L)
    {
        SDL_ShowCursor(SDL_DISABLE);
        return 1;
    }
    
    //! Calls the draw function of the model factory - drawModels();
    int l_drawModels(lua_State *L)
    {
        model_factory.Draw();
        return 1;
    }
    
    //! Tells the model factory to update all it's objects - modelTick();
    int l_modelTick(lua_State *L)
    {
        model_factory.Update();
        return 1;
    }
    
    //! Flushes the model factory (to do) - flushModels();
    int l_flushModels(lua_State *L)
    {
        // model_factory.Flush();  // Clears the model factory of all models
        return 1;
    }
    
    //! Flushes the texture factory - flushTextures();
    int l_flushTextures(lua_State *L)
    {
        texture_factory.flushFactory();  // Clears the texture memory
        return 1;
    }
    
    //! Returns the current gl version number - getGLVersion();
    int l_getGLVersion(lua_State *L)
    {
        lua_pushnumber(L, atof((const char*)glGetString(GL_VERSION)));
        return 1;
    }
    
    //! Toggles the display of a layout item - toggleLayoutItem(itemname, bool);
    int l_toggleLayoutItem(lua_State *L)
    {
        gui_engine.setActive(lua_checkstring(L, 1), lua_toboolean(L, 2));
        return 1;
    }
    
    //! Updates a string area
    int l_updateSArea(lua_State *L)
    {
        gui_engine.updateArea(lua_checkstring(L, 1), lua_checkstring(L, 2), (int)lua_checknumber(L, 3));
        return 1;
    }
    
    //! Updates an integer area
    int l_updateIArea(lua_State *L)
    {
        gui_engine.updateArea(lua_checkstring(L, 1), (int)lua_checknumber(L, 2), (int)lua_checknumber(L, 3));
        return 1;
    }
    
    //! Updates a float area
    int l_updateFArea(lua_State *L)
    {
        float temp = lua_checknumber(L, 2);
        gui_engine.updateArea(lua_checkstring(L, 1), temp, (int)lua_checknumber(L, 3));
        return 1;
    }
    
    //! Adds a gravity core - addGravCore();
    int l_addGravCore(lua_State *L)
    {
        return 1;
    }
    
    //! Removes a gravity core
    int l_remGravCore(lua_State *L)
    {
        return 1;
    }
    
    int l_setPostProcessing(lua_State *L)
    {
        Azadi::postprocessing = lua_toboolean(L, 1);
        return 1;
    }
    
    int l_setPostShaders(lua_State *L)
    {
        for (unsigned int i=0; i < unsigned(lua_checknumber(L, 1)); i++)
        {
            Azadi::ppShaders.push_back(lua_checkstring(L, i+2));
        }
        Azadi::postProgram = shader_factory.loadShaders(Azadi::ppShaders);
        return 1;
    }
    
    int l_setDefaultShaders(lua_State *L)
    {
        for (unsigned int i=0; i < unsigned(lua_checknumber(L, 1)); i++)
        {
            Azadi::dpShaders.push_back(lua_checkstring(L, i+2));
        }
        Azadi::defaultProgram = shader_factory.loadShaders(Azadi::dpShaders);
        return 1;
    }
    
    int l_wait(lua_State *L)
    {
        int duration = (int)lua_checknumber(L, 1) * 1000;
        unsigned int ticks = SDL_GetTicks();
        while((SDL_GetTicks()-ticks) < unsigned(duration))
        {
            sound_factory.tick(); Azadi::Delay(15); // Will wait a moment (but the sound will continue, that way there's not stuttering);
        }
        return 1;
    }
    
    int l_getfps(lua_State *L)
    {
        lua_pushnumber(L, Drawing::fps);
        return 1;
    }
    
    int l_nowPlaying(lua_State *L)
    {
        std::string file;
        file = lua_checkstring(L, 1);
        Azadi::jukebox.setNowPlaying(file);
        return 1;
    }
    
    int l_returnInt(lua_State *L)
    {
        ScriptEngine::returnedInts.push((int)lua_checknumber(L, 1));
        return 1;
    }
    
    int l_returnFloat(lua_State *L)
    {
        ScriptEngine::returnedFloats.push((float)lua_checknumber(L, 1));
        return 1;
    }
    
    int l_returnBool(lua_State *L)
    {
        ScriptEngine::returnedBools.push((bool)lua_toboolean(L, 1));
        return 1;
    }
    
    int l_returnString(lua_State *L)
    {
        ScriptEngine::returnedStrings.push((std::string)lua_checkstring(L, 1));
        return 1;
    }
    
    int l_registerJukeChan(lua_State *L)
    {
        JukeBox::soundChannel = unsigned(lua_checknumber(L, 1));
        return 1;
    }
    
    int l_toggle2dStyle(lua_State *L)
    {
        Azadi::view2d = !Azadi::view2d;
        return 1;
    }
    
    int l_constrainCamPos(lua_State *L)
    {
        Azadi::constrainedAxis[0] = (lua_checknumber(L, 1) == 1)?true:false;
        Azadi::constrainedAxis[1] = (lua_checknumber(L, 2) == 1)?true:false;
        Azadi::constrainedAxis[2] = (lua_checknumber(L, 3) == 1)?true:false;
        return 1;
    }
    
    int l_constrainCamRot(lua_State *L)
    {
        Azadi::ix = lua_checknumber(L, 1);
        Azadi::iy = lua_checknumber(L, 2);
        return 1;
    }
    
    int l_setMoveSpeed(lua_State *L)
    {
        Azadi::movespeed = lua_checknumber(L, 1);
        return 1;
    }
    
    int l_remapDirections(lua_State *L)
    {
        Azadi::movementAxis[0] = int(lua_checknumber(L, 1));
        Azadi::movementAxis[1] = int(lua_checknumber(L, 2));
        Azadi::movementAxis[2] = int(lua_checknumber(L, 3));
        return 1;
    }
    
    int l_sendChat(lua_State *L)
    {
        Azadi::client.Pushdata(CHAT, (Azadi::playerName + ": " + lua_checkstring(L, 1)).c_str());
        return 1;
    }
    
    int l_getChat(lua_State *L)
    {
        char data[256];
        memset(data, 0, 255);
        Azadi::client.Receivedata(CHAT, data);
        lua_pushstring(L, data);
        return 1;
    }
    
    int l_setName(lua_State *L)
    {
        Azadi::playerName = lua_checkstring(L, 1);
        return 1;
    }
    
    int l_strlen(lua_State *L)
    {
        lua_pushnumber(L, strlen((char*)lua_checkstring(L, 1)));
        return 1;
    }
}

using namespace az_lua;

//! Script engine constructor! Registers all required core lua functions
ScriptEngine::ScriptEngine()
{
    console << Console::normal << Console::high << "Initializing Scripting Engine" << Console::endl();
    luavm = lua_open();
    if (luavm == NULL)
    {
        console << Console::normal << Console::high << "Scripting Engine Init Failed" << Console::endl();
        return;
    }
    
    // Lua registered functions
    lua_register(luavm, "print", l_print);
    lua_register(luavm, "runScript", l_runScript);
    lua_register(luavm, "include", l_runScript);
    
    // Math functions
    lua_register(luavm, "sqrt", l_sqrt);
    lua_register(luavm, "sin", l_sin);
    lua_register(luavm, "cos", l_cos);
    lua_register(luavm, "tan", l_tan);
    lua_register(luavm, "asin", l_asin);
    lua_register(luavm, "acos", l_acos);
    lua_register(luavm, "atan", l_atan);
    lua_register(luavm, "random", l_random);
    
    // String related functions
    lua_register(luavm, "strlen", l_strlen);
    
    // Input related functions
    lua_register(luavm, "releaseCursor", l_releaseCursor);
    lua_register(luavm, "captureCursor", l_captureCursor);
    
    // Model functions
    lua_register(luavm, "drawModels", l_drawModels);
    lua_register(luavm, "modelTick", l_modelTick);
    lua_register(luavm, "flushModels", l_flushModels);
    
    // Texture factory functions
    lua_register(luavm, "flushTextures", l_flushTextures);
    
    // Jukebox functions
    lua_register(luavm, "registerJukeChan", l_registerJukeChan);
    
    // Physics interface -to do-
    lua_register(luavm, "addGravityCore", l_addGravCore);
    lua_register(luavm, "remGravityCore", l_remGravCore);
    
    // Layout related functions
    lua_register(luavm, "toggleLayoutItem", l_toggleLayoutItem);
    lua_register(luavm, "updateSArea", l_updateSArea);
    lua_register(luavm, "updateIArea", l_updateIArea);
    lua_register(luavm, "updateFArea", l_updateFArea);
    
    // Camera restriction functions
    lua_register(luavm, "constrainCamPos", l_constrainCamPos);
    lua_register(luavm, "constrainCamRot", l_constrainCamRot);
    lua_register(luavm, "toggle2dStyle", l_toggle2dStyle);
    lua_register(luavm, "setMoveSpeed", l_setMoveSpeed);
    lua_register(luavm, "remapDirections", l_remapDirections);
    
    // Network functions
    lua_register(luavm, "sendChat", l_sendChat);
    lua_register(luavm, "getChat", l_getChat);
    lua_register(luavm, "setName", l_setName);
    
    // Misc functions
    lua_register(luavm, "getGLVersion", l_getGLVersion);
    lua_register(luavm, "setPostProcessing", l_setPostProcessing);
    lua_register(luavm, "setPostShaders", l_setPostShaders);
    lua_register(luavm, "setDefaultShaders", l_setDefaultShaders);
    lua_register(luavm, "wait", l_wait);
    lua_register(luavm, "getfps", l_getfps);
    lua_register(luavm, "setNowPlaying", l_nowPlaying);
    
    // Return functions
    lua_register(luavm, "returnInt", l_returnInt);
    lua_register(luavm, "returnFloat", l_returnFloat);
    lua_register(luavm, "returnBool", l_returnBool);
    lua_register(luavm, "returnString", l_returnString);
    
    // Register the script engine under the console
    console.registerObject(*this, "azsc");
    
    
    //! Registration of the Classes
    
    // Register the sound class
    AzLua<SoundLua>::Register(luavm);
    // Register the unit class
    AzLua<UnitLua>::Register(luavm);
    // Register the buildings class
    AzLua<BuildingLua>::Register(luavm);
    // Register the texture factory class
    AzLua<TextureLua>::Register(luavm);
    // Register the drawing class
    AzLua<DrawLua>::Register(luavm);
    // Register the Model class
    AzLua<ModelLua>::Register(luavm);
    // Register the Menu class
    //AzLua<Menu>::Register(luavm);
}

//! Closes the lua virtual machine
ScriptEngine::~ScriptEngine()
{
    lua_close(luavm);
}

//! Runs a script file
void ScriptEngine::runfile(const char *cmd)
{
    std::string filename("./data/Scripts/");
    filename += cmd;
    
    if (luaL_loadfile(luavm, filename.c_str()) || lua_pcall(luavm, 0, 0, 0))
    {
        printf("%s\n", lua_tostring(luavm, 1));
        lua_pop(luavm, 1);
    }
}

//! Single line command interpreter
void ScriptEngine::dostring(const char *cmd)
{
    if (luaL_loadbuffer(luavm, cmd, strlen(cmd), cmd) || lua_pcall(luavm, 0, 0, 0))
    {
        printf("%s\n", lua_tostring(luavm, 1));
        lua_pop(luavm, 1);
    }
}

//! The handler for the console (Deprecated)
std::string ScriptEngine::acceptConsoleCommand(std::string cmd)
{
    dostring(cmd.c_str());
    return "";
}

int ScriptEngine::returnedInt()
{
    int temp = returnedInts.top();
    returnedInts.pop();
    return temp;
}

float ScriptEngine::returnedFloat()
{
    float temp = returnedFloats.top();
    returnedFloats.pop();
    return temp;
}

bool ScriptEngine::returnedBool()
{
    bool temp = returnedBools.top();
    returnedBools.pop();
    return temp;
}

std::string ScriptEngine::returnedString()
{
    std::string temp = returnedStrings.top();
    returnedStrings.pop();
    return temp;
}
