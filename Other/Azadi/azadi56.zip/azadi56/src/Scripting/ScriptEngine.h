#ifndef SCRIPTENGINE_H
#define SCRIPTENGINE_H

#include "../Input/ConsoleListener.h"
#include <stack>

#include "luna.h"

extern "C"
{
	#include <lua.h>
	#include <lualib.h>
	#include <lauxlib.h>
}

#define lua_checkstring luaL_checkstring
#define lua_optstring luaL_optstring
#define lua_checknumber luaL_checknumber
#define lua_checkany luaL_checkany

//! Scripting engine class
/*!
	<h3>How the hell does this class work?</h3>
	The Scripting engine is quite simple to use once you know all the little niggles<br>
	and complications to using it.<br><br>

	Let's take an example;<br><br>

	class testluaobj<br>
	{<br>
	&nbsp;&nbsp;&nbsp;&nbsp;public:<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;testluaobj(lua_State *L);<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;~testluaobj();<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;int addnumbers(lua_State *L);<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;static const char className[];<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;static AzLua<testluaobj>::RegType methods[];<br>
	};<br><br>

	testluaobj::testluaobj(lua_State *L)<br>
	{<br>
	&nbsp;&nbsp;&nbsp;&nbsp;fprintf(stderr, "Instantiated a testluaobj!\n");<br>
	}<br><br>

	testluaobj::~testluaobj(lua_State *L)<br>
	{<br><br>

	}<br><br>

	int testluaobj::addnumbers(lua_State *L)<br>
	{<br>
	&nbsp;&nbsp;&nbsp;&nbsp;float temp;<br>
	&nbsp;&nbsp;&nbsp;&nbsp;temp = (lua_checknumber(L, 1) + lua_checknumber(L, 2));<br>
	&nbsp;&nbsp;&nbsp;&nbsp;lua_pushnumber(L, temp);<br>
	&nbsp;&nbsp;&nbsp;&nbsp;return 1;<br>
	}<br><br>

	Note: The following are intentionally in the global scope<br>
	const char className[] = "testluaobj";<br>
	AzLua<testluaobj>::RegType testluaobj::methods[] = {<br>
	&nbsp;&nbsp;&nbsp;&nbsp;{ "addnumber", &testluaobj::addnumbers },<br>
	&nbsp;&nbsp;&nbsp;&nbsp;{ 0, 0 }<br>
	}<br><br>

	The above code will create a class that is accesible by Lua.<br>
	the const char className[] value is what lua will use to refer to<br>
	this class. The methods array export the class methods to lua in<br>
	so far that you can call them by <class>.<method>(). as an example<br>
	to instantiate the class above in lua, you would:<br><br>

	test = testluaobj();<br><br>

	then to use the addnumber method that I exported above:<br><br>

	test.addnumber(14.5, 32.5);<br><br>

	All that remains now is to go into the ScriptEngine's constructor<br>
	in ScriptEngine.cpp and add the line that registers the class with<br>
	lua itself (if you don't do this step, you can't use the class at all)<br><br>

	AzLua<classname>::Register(luavm);<br><br>

	where classname is the name of the class you wrote, and luavm is the lua<br>
	state machine. (In azadi's case, luavm is the correct variable)<br><br>

	example of use:<br>
	AzLua<testluaobj>::Register(luavm);<br><br>

	And that's all there is to it!<br><br>

	<h3>Lua Arguments</h3>
	in regards to how to take the arguments of lua functions, we'll continue<br>
	using the above example.<br><br>

	int testluaobj::addnumbers(lua_State *L)<br><br>

	every argument passed by lua, or to lua goes through the lua_State<br>
	each argument passed or pushed through goes in order, 1, 2 etc<br>
	to take an argument from the lua_State, we use a function like:<br><br>

	int x = lua_tonumber(L, 1);<br><br>

	the key here is in the brackets, L, standing for the lua_State,<br>
	and "1", referring to the first argument. We can take the second or<br>
	third respectively by:<br><br>

	int x = lua_tonumber(L, 2);<br>
	int y = lua_tonumber(L, 3);<br><br>

	Simple :D<br>
	There are times though that you will want to make sure that the<br>
	scripter wrote the correct argument type. For example, you want<br>
	to ensure that the scripter has set the third argument of a function<br>
	as an number, we can do this by using the "check" version of functions:<br><br>

	int x = lua_checknumber(L, 3);<br><br>

	simple as pie :D<br>
	The functions we would normally use would be:<br><br>

	lua_tonumber(lua_State *, #);<br>
	lua_tostring(lua_State *, #);<br>
	lua_toboolean(lua_State *, #);<br>
	lua_checknumber(lua_State *, #);<br>
	lua_checkstring(lua_State *, #);<br><br>

	to return something to the lua_State (in order for lua to receive a return value)<br>
	we do a:<br><br>

	lua_pushnumber(lua_State *, #);<br><br>

	or a:<br><br>

	lua_pushstring(lua_State *, #);<br><br>

	where # is the value you want to push. Lua allows us to return more than one value.<br>
	To do this, all you have to do is push multiple things through one after the other<br>
	then the return value of the function is how many items you will push through. For example<br>
	if you pushed 3 numbers, you would return 3. This is why all lua accesible functions are<br>
	always of type INT. In lua, to retrieve all the returned values, you do something like:<br><br>

	eg. test, test2 = dosomething(42, 123, 5453);<br>

	in which test will take the first argument returned, and test2 will take the second<br><br>
	anyway that's all for now folks!!<br><br>

	<h3>By: Aren Villanueva</h3>
*/
class ScriptEngine : public ConsoleListener
{
	public:
		ScriptEngine();
		~ScriptEngine();
		int returnedInt();
        float returnedFloat();
        bool returnedBool();
        std::string returnedString();

		void runfile(const char *cmd);
		void dostring(const char *cmd);
		std::string acceptConsoleCommand(std::string input);

		static std::stack<int> returnedInts;
		static std::stack<float> returnedFloats;
		static std::stack<bool> returnedBools;
		static std::stack<std::string> returnedStrings;
	private:
		lua_State *luavm;
};

extern ScriptEngine script_engine;

#endif
