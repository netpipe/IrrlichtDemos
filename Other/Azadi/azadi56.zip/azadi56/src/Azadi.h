#ifndef AZADI_H
#define AZADI_H

// execute debug() only if in _DEBUG mode
#ifdef _DEBUG
#	define debug(x) x
#else
#	define debug(x)
#endif

#ifndef __OSX__
	#include <AL/al.h>
	#include <AL/alc.h>
#else
	#include <OpenAL/al.h>
	#include <OpenAL/alc.h>
#endif

#include "Input/Input.h"
#include "GUI/FPSCounter.h"
#include "GUI/GUI.h"
#include "Particle/ParticleFactory.h"
#include "Texture/TextureFactory.h"
#include "Sound/SoundFactory.h"
#include "Scripting/ScriptEngine.h"
#include "Net/Client.h"
#include "XML/XML.h"
#include "Shader/Shader.h"
#include "GUI/GUI.h"
#include "GUI/Menu.h"
#include "matrix.h"
#include "quaternion.h"
#include "Fonts/Font.h"
#include "Sound/JukeBox.h"
#include "Video/Video.h"
#include "Extensions/Extensions.h"
#include "Objects/Player/Player.h"
#include "CustomFunctions.h"

#ifndef NDEBUG
#define BUILD "Debug"
#else
#define BUILD "Release"
#endif

#define AZADIVERSION "0.1 pre-alpha"

//#define PI 3.1415926535897932384626433832795f
#define PI 3.14159
const float piover180 = 0.0174532925f;


class ModelFactory ;
class Drawing;
class Textures;
class SDL_Surface;

enum mov
{
    FORWARD=0,
    BACKWARD,
    LEFT,
    RIGHT
};

//! The main Azadi class that handles the main game loop
class Azadi : public eventListener,ConsoleListener
{
    public:
        Azadi(int argc, char** argv);
		~Azadi(); // Cleans up the engine
        int Run();
        GLubyte *glext; // Contains the GL extensions available
        static bool postprocessing;
        static std::vector<std::string> ppShaders;
        static std::vector<std::string> dpShaders;
        static unsigned int postProgram;
        static unsigned int defaultProgram;
        // the player's name
        static std::string playerName;
        // JukeBox :D
        static JukeBox jukebox;
        //! Screen size
        static int screen[2];
        static void Delay(unsigned int);
        static bool constrainedAxis[3];
        static bool view2d;
        static float ix;
        static float iy;
        static float movespeed;
        static int movementAxis[3];
        std::map<std::string, bool> extensions;

        //! network client
		static Client client;
    private:
        int Lobby();
        bool Init();
        int Mainloop();
        void ResetState();
        void ResizeScreen(unsigned int w, unsigned int h);
        void drawCursor(vector3<GLfloat> forward, float ix, float iy);   // Cursor drawing
        bool Draw();
        void ProcessMessages();
        void HandleGameData();
        void parseParameters(int argc, char** argv);
        void cmdTriggered(std::string cmd);
        void cmdReleased(std::string cmd);
        std::string acceptConsoleCommand(std::string);

		//! template of the screen
		screenTemplate screenTemp;

        Drawing* drawing;

        //! Window SDL-Handler
        SDL_Surface* window;

        GUI::FPSCounter fps_counter;

        //! Program done?
        bool done;

        //! Mouse position
        int mouse[2];

        //! Koordinates of the center
        int center[2];

        // Selction and dispatch status
        bool selecting;
        bool dispatching;

        // Dispatch cursor position
        GLfloat cursorPos;
        GLfloat curMousePos;

        GLfloat origPos[3];
        GLfloat cursPos[3];
        GLfloat CamPos[3];

        GLfloat dxrot;
        GLfloat dyrot;

        bool MoveKey[4];

        ParticleFactory *testPart;

        ALCcontext *soundContext;
        ALCdevice *soundDevice;

        bool soundDeviceWorking;
        bool fullScreen;
        bool withAudio;

        matrix3<float> test;

        float msensitivity;   // Mouse sensitivity

        // Postprocess related items
        GLuint posttext;
        bool firstset;

        char *playerVect;

        std::vector<Player> players;

        unsigned int sessionId;
        
        unsigned long rate;
        unsigned long lastTick;

        void SendPosition()
        {
            if ((SDL_GetTicks() - lastTick) < rate)
                return;
            lastTick = SDL_GetTicks();
            char *p = playerVect;
            char header = 1; // 1 means viewer vector
            char nameSize = strlen(Azadi::playerName.c_str());
            unsigned int packetSize = sizeof(sessionId)+sizeof(nameSize)+strlen(Azadi::playerName.c_str())+(sizeof(float)*3)+sizeof(header);
            memset(p, 0, packetSize+1);
            strncat(p, &header, 1);
            strncat(p, &nameSize, 1);
            strcat(p, Azadi::playerName.c_str());
            unsigned int firstLen = p[0] + p[1] + strlen(Azadi::playerName.c_str());
            strncat(p, (const char*)&sessionId, sizeof(sessionId));
            firstLen += sizeof(sessionId);
            strncat(p, (const char*)&CamPos, sizeof(float)*3);
            client.Pushdata(GAME, p, packetSize);
        }
};

/*! \mainpage Azadi RTS engine

	Place some descriptive text here you guys, at the bottom of Azadi.h <br><br>

	Even after how many months we have been working, we're still so far from our goals. But we're slowly getting there day by day

*/

#endif
