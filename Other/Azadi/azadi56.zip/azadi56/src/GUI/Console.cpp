#include "Console.h"

#include <iostream>
#include "Console/Message.h"

#ifndef __OSX__
#include <GL/gl.h>
#else
#include <OpenGL/gl.h>
#endif

#include "SDL/SDL.h"

#include "Drawing.h"

#include "../Input/ConsoleListener.h"
#include "GUI.h"
#include <ctime>

extern Input input;

//! Console constructor
GUI::Console::Console()
{
    logFile = fopen("./log.txt", "w");
    time_t *curTime = new time_t;
    time(curTime);
    fputs("Began logging at: ", logFile);
    fputs(ctime(curTime), logFile);
    fputs("\n", logFile);
	history_size = 128;
	show = false;
	collapsed = false;
	x = 4;
	y = 4;
	has_focus = false;
	verbosity_level = medium;
	buffer_type = normal;
	buffer_level = highish;
	width = 792;
	height = 200;
	start = messages.begin();
	stick_bottom = true;
	button_up.setX(x+width-15).setY(y+14).setDirection(Button::DIRECTION_UP).setButtonNumber(0);
	button_down.setX(x+width-15).setY(y+height-16-15).setDirection(Button::DIRECTION_DOWN).setButtonNumber(0);
	button_stick_bottom.setX(x+width-15).setY(y+height-16).setDirection(Button::DIRECTION_DOWN).setButtonNumber(4);
	button_collapse.setX(x+width-15-15).setY(y-1).setDirection(Button::DIRECTION_LEFT).setButtonNumber(1);
	button_hide.setX(x+width-15).setY(y-1).setDirection(Button::DIRECTION_LEFT).setButtonNumber(3);
	button_verbosity_down.setX(x+width-60).setY(y-1).setDirection(Button::DIRECTION_RIGHT).setButtonNumber(5);
	button_verbosity_up.setX(x+width-45).setY(y-1).setDirection(Button::DIRECTION_RIGHT).setButtonNumber(6);
	addMessage(normal,highish,"Initialising Console");
	this->registerObject(*this,"console");

	input.registerOverrideKeyListener("toggleConsole",SDLK_TAB,this);

}

//! Registers an object to the Console
void GUI::Console::registerObject(ConsoleListener& listener,std::string handle)
{
	listeners[handle] = &listener;
}

//! Console destructor
GUI::Console::~Console()
{
    fputs("\n", logFile);
    fputs("End log\n", logFile);
    fclose(logFile);
}

//! Accepts console commands from the user
std::string GUI::Console::acceptConsoleCommand(std::string command)
{
	script_engine.dostring(command.c_str());
	std::size_t space_pos = command.find(' ',0);
	std::string command_portion = command.substr(0,space_pos);
	if (command_portion == "echo" && (space_pos != std::string::npos))
		*this << normal << low << "Console echo: " << command.substr(space_pos+1,command.length()) << endl();
	if (command_portion == "collapse") {
		collapsed = true;
		has_focus = false;
		height = 15;
	}
	if (command_portion == "close") {
		show = false;
		has_focus = false;
	}
    
	return "";
}

//! No documentation just yet
void GUI::Console::insertUserCommand(std::string command)
{
	user_commands.push_back(command);
	addMessage(user,low,command);
	cycle_back_position = user_commands.end();
	//std::size_t dot_pos = command.find('.',0);
	std::size_t dot_pos = command.find(' ',0);
	if(command != "help")
	{
		std::map<std::string,ConsoleListener*>::iterator listener = listeners.find(command.substr(0,dot_pos));
		if (listener == listeners.end())
			script_engine.dostring(command.c_str());
		//*this << warning << lowish << "Not found - \"" << command.substr(0,dot_pos) << "\". Type help to see all avaliable commands" << endl();
		else
			listener->second->acceptConsoleCommand(command.substr(dot_pos+1,command.size()));
	}
	else
		for(std::map<std::string,ConsoleListener*>::iterator it = listeners.begin(); it != listeners.end();it++)
			*this << it->first << " - " << it->second->shortDescr() << endl();
}

//! Need to study this one more
void GUI::Console::parseInput()
{
	button_up.parseInput(input);
	button_down.parseInput(input);
	button_collapse.parseInput(input);
	button_hide.parseInput(input);
	button_stick_bottom.parseInput(input);
	button_verbosity_up.parseInput(input);
	button_verbosity_down.parseInput(input);

	if (button_up.getMouseClick()) {
		if (start!=messages.end())
			++start;
		stick_bottom = false;
	}
	if (button_down.getMouseClick()) {
		if (start!=messages.begin())
			--start;
		stick_bottom = false;
	}
	if (button_collapse.getMouseClick()) {
		collapsed = !collapsed;
		button_collapse.setButtonNumber(collapsed?2:1);
		height = collapsed?15:200;
		has_focus = false;
	}
	if (button_hide.getMouseClick())
	{
		has_focus = false;
		show = false;
	}
	if (button_stick_bottom.getMouseClick()) {
		start = messages.begin();
		stick_bottom = true;
	}

	if (button_verbosity_up.getMouseClick())
		increaseVerbosityLevel();

	if (button_verbosity_down.getMouseClick())
		decreaseVerbosityLevel();
/*
  if ((input.getMouseY()>y+height-15) && (input.getMouseY()<y+height))
  if ((input.getMouseX()>x) && (input.getMouseX()<x+width))
  if (input.getMouseClick(SDL_BUTTON_LEFT))
  {
  has_focus = true;
  input.flush();
  }
*/
	if (has_focus)
	{
		// input.TextMode(&Cmdparser);
		/*
		  if (!input.isKeyDepressed(SDLK_RSHIFT) && !input.isKeyDepressed(SDLK_LSHIFT))
		  {
		  for (int i = SDLK_SPACE; i < SDLK_z ; i++)
		  if (input.getKeyPress(i))
		  {
		  user_command += char(i);
		  input.removeDepressed(i);
		  i = SDLK_z;
		  }
		  if (input.getKeyPress(SDLK_BACKSPACE) && user_command.size())
		  user_command.erase(user_command.end()-1);
		  if (input.getKeyPress(SDLK_RETURN) && user_command.size())
		  {
		  insertUserCommand(user_command);
		  user_command = "";
		  }
		  }*/
		//console << "FOCUS !" << GUI::Console::endl();
		if (input.getMouseClick(SDL_BUTTON_LEFT))
			if (!((input.getMouseY()>y+height-15) && (input.getMouseY()<y+height)) || !((input.getMouseX()>x) && (input.getMouseX()<x+width)))
				has_focus = false;
	}


}

//! Initialize the textures for the GUI
void GUI::Console::initTextures() {
	button_up.initTextures();
	button_down.initTextures();
	button_stick_bottom.initTextures();
	button_collapse.initTextures();
	button_hide.initTextures();
	button_verbosity_up.initTextures();
	button_verbosity_down.initTextures();
}

//! Toggles the showing of the Console
void GUI::Console::toggleShow()
{
	show = !show;
}

//! Increases the verbosity of the Console
void GUI::Console::increaseVerbosityLevel()
{
	if (verbosity_level==highish)
		verbosity_level = high;
	if (verbosity_level==medium)
		verbosity_level = highish;
	if (verbosity_level==lowish)
		verbosity_level = medium;
	if (verbosity_level==low)
		verbosity_level = lowish;
}

//! Decreases the verbosity of the Console
void GUI::Console::decreaseVerbosityLevel()
{
	if (verbosity_level==lowish)
		verbosity_level = low;
	if (verbosity_level==medium)
		verbosity_level = lowish;
	if (verbosity_level==highish)
		verbosity_level = medium;
	if (verbosity_level==high)
		verbosity_level = highish;
}

//! Draws the console on screen
void GUI::Console::draw() {

	if (!show) return;

	Drawing::prepare2D();

	glDisable(GL_CULL_FACE);
	glEnable(GL_BLEND);

	glColor4f(0.0,0.6,1.0,1.0);
	glRectd(x,y,x+width,y+14);

	glColor4f(1.0,1.0,1.0,1.0);
	glRectd(x,y+14,x+width,y+height);

	glColor4f(0.0,0.0,0.0,1.0);
	glBegin(GL_LINE_LOOP);

	glVertex2i(x,y);
	glVertex2i(x+width,y);
	glVertex2i(x+width,y+height);
	glVertex2i(x,y+height);

	glEnd();

	glColor4f(1.0,1.0,1.0,1.0);
	Drawing::drawText(x+2,y,"Console",12);

	if (!collapsed) {

		glLoadIdentity ();
		glColor3f(0.0,0.0,0.0);

		glBegin(GL_LINES);
		glVertex2i(x,y+15);
		glVertex2i(x+width,y+15);
		glVertex2i(x,y+height-15);
		glVertex2i(x+width,y+height-15);
		glEnd();


		int y = this->y+height-12-16;

		for(std::list<Message*>::iterator iter = start; iter != messages.end(); ++iter)
		{
			if ((*iter)->getType() == error) glColor4f(1.0,0.0,0.0,1.0);
			if ((*iter)->getType() == warning) glColor4f(1.0,0.6,0.0,1.0);
			if ((*iter)->getType() == normal) glColor4f(0.0,0.0,0.0,1.0);
			if ((*iter)->getType() == user) glColor4f(0.7,0.7,0.2,1.0);
			if ((*iter)->getLevel()<=verbosity_level)
			{
				Drawing::drawText(x+2,y,(*iter)->getContent(),12);
				y -= 10;
			}
			//if (y>this->y) iter = messages.end();
		}

		glColor3f(0.0,0.0,0.0);

		static unsigned int cursor_blinktime = 0; // a global static unsigned integer should do the job --blub
		cursor_blinktime += Drawing::last_frame_length;//getLastFrameLength();

		Drawing::drawText(x+2,this->y+height-15,user_command,12);
		if( (cursor_blinktime/400) & 1 )
		{ // blink every 400 milliseconds
			std::string curstr = "";
			/*for(unsigned int i = 0; i < cursor; ++i)
			  cursor.append(" ");*/
			curstr.insert(0, cursor, ' ');
			curstr.append("_");
			Drawing::drawText(x+2, this->y+height-15, curstr, 12);
		}

		glColor4f(1.0,1.0,1.0,1.0);

		button_up.draw();
		button_down.draw();
		button_stick_bottom.draw();
	}

	glColor3f(0.0,0.6,1.0);
	button_collapse.draw();
	button_hide.draw();
	button_verbosity_up.draw();
	button_verbosity_down.draw();


	glColor3f(1.0,1.0,1.0);
	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);
}

bool GUI::Console::isVisible()
{
    return show;
}

//! Adds a message to the console
void GUI::Console::addMessage(Console::MessageType type, Console::MessageLevel level, std::string content)
{
    if (type==log || type==error)
    {
        fprintf(logFile, "%s\n", content.c_str());
        if (level!=silent)
            printf("%s\n", content.c_str());
    }
    else if(level!=silent)
    {
        printf("%s\n",content.c_str());
    }
    if (level!=silent)
    {
        messages.push_front(new Message(type,level, content));
        if (stick_bottom)
            start = messages.begin();
    }
}

//! Sets the verbosity level to level
void GUI::Console::setVerbosityLevel(MessageLevel level)
{
	verbosity_level = level;
}

//! Puts a MessageType into the console
GUI::Console& GUI::Console::operator<<(Console::MessageType right)
{
	buffer_type = right;
	return *this;
}

//! Puts a MessageLevel into the console
GUI::Console& GUI::Console::operator<<(Console::MessageLevel right)
{
	buffer_level = right;
	return *this;
}

//! Puts a String into the console
GUI::Console& GUI::Console::operator<<(std::string right)
{
	buffer << right;
	return *this;
}

//! Puts an int into the console
GUI::Console& GUI::Console::operator<<(int right)
{
	buffer << right;
	return *this;
}

//! Puts a char into the console
GUI::Console& GUI::Console::operator<<(char right)
{
	if (right=='\n') {
		addMessage(buffer_type,buffer_level,buffer.str());
		buffer_type = normal;
		buffer_level = medium;
		buffer.str("");
		//cursor = 0;
	} else {
		buffer << right;
		//buffer.str().insert(cursor++, 1, right);
	}
	return *this;
}

//! Puts a float into the console
GUI::Console& GUI::Console::operator<<(float right)
{
	buffer << right;
	return *this;
}

//! Puts a double into the console
GUI::Console& GUI::Console::operator<<(double right)
{
	buffer << right;
	return *this;
}

//! Puts an unsigned into the console
GUI::Console& GUI::Console::operator<<(unsigned right)
{
	buffer << right;
	return *this;
}

//! Puts an long unsigned int into the console
GUI::Console& GUI::Console::operator<<(long unsigned int right)
{
	buffer << right;
	return *this;
}

//! Puts an endline into the console
char GUI::Console::endl()
{
	return '\n';
}

void GUI::Console::charEntered(SDLKey sym, unsigned short int ch)
{
	if (sym == SDLK_BACKSPACE)
	{
		if (user_command.size() && cursor > 0) {
			user_command.erase(--cursor, 1);
		}
		return;
	}
	if (sym == SDLK_DELETE)
	{
		if(user_command.size() > cursor) {
			user_command.erase(cursor, 1);
		}
		return;
	}
	if (sym == SDLK_LEFT)
	{
		if(cursor)
			--cursor;
		return;
	}
	if (sym == SDLK_RIGHT)
	{
		if(cursor < user_command.size())
			++cursor;
		return;
	}
	if (sym == SDLK_KP_ENTER || sym == SDLK_RETURN )
	{
		if(!history_size)
			history_size = 32;
		if(user_command.size())
		{
			command_history.push_back(user_command);
                        insertUserCommand(user_command);
		}
		if(command_history.size() > history_size)
		{
			command_history.erase(
				command_history.begin(),
				command_history.end() - history_size);
		}
		user_command = "";
		history_pos = cursor = 0;
		return;
	}
	if(command_history.size())
	{
		if (sym == SDLK_DOWN)
		{
			history_pos = (history_pos+1) % command_history.size();
			user_command = command_history[history_pos];
			return;
		}
		if (sym == SDLK_UP)
		{
			if(history_pos == 0)
				history_pos = command_history.size()-1;
			else
				history_pos = (history_pos-1) % command_history.size();
			user_command = command_history[history_pos];
			return;
		}
	}
	if (sym == SDLK_END)
	{
		cursor = user_command.size();
		return;
	}
	if (sym == SDLK_HOME)
	{
		cursor = 0;
		return;
	}
	if(ch)
		user_command.insert(cursor++, 1, ch);
}
