#include "GUI.h"
#include "Console.h"
#include "../Input/Input.h"

using GUI::Console;

Layout::Layout()
{   
    pos = 0;
    input.registerOverrideKeyListener("toggleChat", SDLK_t, this);
}

Layout::~Layout()
{

}

void Layout::charEntered(SDLKey sym, unsigned short int ch)
{
    if (sym != SDLK_RETURN && sym != SDLK_BACKSPACE)
    {
        chat.insert(pos++, 1, ch);
        updateArea("chat", (std::string)"say: " + chat, 1);
    }
    else if (sym == SDLK_BACKSPACE)
    {
        if (chat.size() && pos > 0)
            chat.erase(--pos, 1);
        updateArea("chat", (std::string)"say: " + chat, 1);
    }
    else
    {
        script_engine.dostring(((std::string)"sendChat(\"" + chat + "\");").c_str());
        updateArea("chat", "", 1);
        chat.clear();
        entering=false;
        input.KeyMode();
        setActive("chat", false);
        pos = 0;
    }
}

void Layout::loadTemplate(screenTemplate screenTemp)
{
	unsigned int i, ii;

	for (i = 0 ; i < screenTemp.panels.size(); i++)
	{
		for (ii = 0; ii < screenTemp.panels[i].textures.size() ; ii++)
			screenTemp.panels[i].textures[ii].textureID = texture_factory.loadTexture(screenTemp.panels[i].textures[ii].name);
		screenTemp.panels[i].active = false;
	}

	for (i = 0 ; i < screenTemp.messageAreas.size(); i++)
	{
		for (ii = 0; ii < screenTemp.messageAreas[i].textures.size() ; ii++)
			screenTemp.messageAreas[i].textures[ii].textureID = texture_factory.loadTexture(screenTemp.messageAreas[i].textures[ii].name);
		screenTemp.messageAreas[i].active = false;
        areaSMaxLines[screenTemp.messageAreas[i].name] = screenTemp.messageAreas[i].maxLines;
	}

	for (i = 0 ; i < screenTemp.numericAreas.size(); i++)
	{
		for (ii = 0; ii < screenTemp.numericAreas[i].textures.size() ; ii++)
			screenTemp.numericAreas[i].textures[ii].textureID = texture_factory.loadTexture(screenTemp.numericAreas[i].textures[ii].name);
		screenTemp.numericAreas[i].active = false;
	}

	this->screenTemp = screenTemp;
}

void Layout::draw(int x, int y)
{
	unsigned int i, ii;

	// Draw the panels first
	glEnable(GL_TEXTURE_2D);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0.0f, x, y, 0.0f, -1.0, 2000);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glColor3f(1.0, 1.0, 1.0);

    glEnable(GL_BLEND);
	glPushMatrix();
	for (i = 0; i < screenTemp.panels.size(); i++)
	{
		if (screenTemp.panels[i].active)
		{
			glPushMatrix();
			glTranslatef(screenTemp.panels[i].x, screenTemp.panels[i].y, 0.0);
			for(ii = 0; ii < screenTemp.panels[i].textures.size(); ii++)
			{
				// need to do multitexturing (maybe not)
				texture_factory.applyTexture(screenTemp.panels[i].textures[ii].textureID);
			}
			glBegin(GL_QUADS);
			{
				glTexCoord3f(0.0, 0.0, 0.0);
				glVertex2f(0.0f, screenTemp.panels[i].h);
				glTexCoord3f(1.0, 0.0, 0.0);
				glVertex2f(screenTemp.panels[i].w, screenTemp.panels[i].h);
				glTexCoord3f(1.0, 1.0, 0.0);
				glVertex2f(screenTemp.panels[i].w, 0.0f);
				glTexCoord3f(0.0, 1.0, 0.0);
				glVertex2f(0.0, 0.0);
			}
			glEnd();
			glPopMatrix();
		}
	}
	for (i = 0; i < screenTemp.messageAreas.size(); i++)
	{
		if (screenTemp.messageAreas[i].active)
		{
			glPushMatrix();
			glTranslatef(screenTemp.messageAreas[i].x, screenTemp.messageAreas[i].y, 0.0);
			for(ii = 0; ii < screenTemp.messageAreas[i].textures.size(); ii++)
			{
				texture_factory.applyTexture(screenTemp.messageAreas[i].textures[ii].textureID);
			}
			glBegin(GL_QUADS);
			{
				glTexCoord3f(0.0, 0.0, 0.0);
				glVertex2f(0.0, screenTemp.messageAreas[i].h);
				glTexCoord3f(1.0, 0.0, 0.0);
				glVertex2f(screenTemp.messageAreas[i].w, screenTemp.messageAreas[i].h);
				glTexCoord3f(1.0, 1.0, 0.0);
				glVertex2f(screenTemp.messageAreas[i].w, 0.0);
				glTexCoord3f(0.0, 1.0, 0.0);
				glVertex2f(0.0, 0.0);
			}
			glEnd();
			glPopMatrix();
			glPushMatrix();
			glTranslatef(screenTemp.messageAreas[i].x + screenTemp.messageAreas[i].textoffsetx, screenTemp.messageAreas[i].y + screenTemp.messageAreas[i].textoffsety, 0.0);
            std::string tempBuffer;
            for (unsigned int it = 0; it < areaSData[screenTemp.messageAreas[i].name].size(); ++it)
                tempBuffer+=areaSData[screenTemp.messageAreas[i].name][it] + "\n";
            text_engine.drawText(tempBuffer, screenTemp.messageAreas[i].font, screenTemp.messageAreas[i].fontpt);
			glPopMatrix();
		}
	}
	for (i = 0; i < screenTemp.numericAreas.size(); i++)
	{
		if (screenTemp.numericAreas[i].active)
		{
			glPushMatrix();
			glTranslatef(screenTemp.numericAreas[i].x, screenTemp.numericAreas[i].y, 0.0);
			for(ii = 0; ii < screenTemp.numericAreas[i].textures.size(); ii++)
			{
				texture_factory.applyTexture(screenTemp.numericAreas[i].textures[ii].textureID);
			}
			glBegin(GL_QUADS);
			{
				glTexCoord3f(0.0, 0.0, 0.0);
				glVertex2f(0.0, screenTemp.numericAreas[i].h);
				glTexCoord3f(1.0, 0.0, 0.0);
				glVertex2f(screenTemp.numericAreas[i].w, screenTemp.numericAreas[i].h);
				glTexCoord3f(1.0, 1.0, 0.0);
				glVertex2f(screenTemp.numericAreas[i].w, 0.0);
				glTexCoord3f(0.0, 1.0, 0.0);
				glVertex2f(0.0, 0.0);
			}
			glEnd();
			glPopMatrix();
			glPushMatrix();
			glTranslatef(screenTemp.numericAreas[i].x + screenTemp.numericAreas[i].textoffsetx, screenTemp.numericAreas[i].y + screenTemp.numericAreas[i].textoffsety, 0.0);
			if(screenTemp.numericAreas[i].type == 0)
				text_engine.drawText(areaIData[screenTemp.numericAreas[i].name], screenTemp.numericAreas[i].font, screenTemp.numericAreas[i].fontpt);
			else
				text_engine.drawText(areaFData[screenTemp.numericAreas[i].name], screenTemp.numericAreas[i].font, screenTemp.numericAreas[i].fontpt);
			glPopMatrix();
		}
	}
	glPopMatrix();
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);
}

void Layout::updateArea(const char* name, const std::string& data, int type)
{
	std::string areaName;
	areaName = name;
	if (type == APPEND || type == 0)
	{
        if (areaSData[areaName].size() > areaSMaxLines[areaName])
            areaSData[areaName].erase(areaSData[areaName].begin());
		areaSData[areaName].push_back(data);
	}
	else if (type == REPLACE)
	{
        areaSData[areaName].clear();
		areaSData[areaName].push_back(data);
	}
}

void Layout::updateArea(const char* name, int data, int type)
{
	std::string areaName;
	areaName = name;
	if (type == APPEND || type == 0)
	{
		areaIData[areaName] += data;
	}
	else if (type == REPLACE)
	{
		areaIData[areaName] = data;
	}
}

void Layout::updateArea(const char* name, float data, int type)
{
	std::string areaName;
	areaName = name;
	if (type == APPEND || type == 0)
	{
		areaFData[areaName] += data;
	}
	else if (type == REPLACE)
	{
		areaFData[areaName] = data;
	}
}

void Layout::setActive(const std::string& itemName, bool active)
{
	unsigned int i;
	for (i = 0; i < screenTemp.panels.size(); i++)
		if (screenTemp.panels[i].name == itemName)
		{
			screenTemp.panels[i].active = active;
			goto skip;
		}
	for (i = 0; i < screenTemp.messageAreas.size(); i++)
		if (screenTemp.messageAreas[i].name == itemName)
		{
			screenTemp.messageAreas[i].active = active;
			goto skip;
		}
	for (i = 0; i < screenTemp.numericAreas.size(); i++)
		if (screenTemp.numericAreas[i].name == itemName)
		{
			screenTemp.numericAreas[i].active = active;
			goto skip;
		}
skip:;
}
