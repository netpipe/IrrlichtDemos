#include "Menu.h"
#include "../Azadi.h"
#include "../Input/Input.h"

extern Input input;

using GUI::Console;

Menu::Menu(const int& x, const int& y, const int& w, const int& h, const std::string& texture)
{
    this->x = x; this->y = y;
    width = w;
    height = h;
    texid = texture_factory.loadTexture(texture);

    numTex=0;
    curButtons=0;

    menuButTex.resize(0);

    menuList = glGenLists(1);

    firstrun=true;
}

Menu::Menu(lua_State *L)
{
    x = (int)lua_checknumber(L, 1);
    y = (int)lua_checknumber(L, 2);
    width = (int)lua_checknumber(L, 3);
    height = (int)lua_checknumber(L, 4);
    texid = texture_factory.loadTexture((std::string)lua_checkstring(L, 5));

    menuList = glGenLists(1);
    glNewList(menuList, GL_COMPILE);
    glPushMatrix();
    texture_factory.applyTexture(texid);
    glBegin(GL_QUADS);
    {
        glTexCoord2f(0.0f, 1.0f);
        glVertex2f(0.0f, 0.0f);
        glTexCoord2f(1.0f, 1.0f);
        glVertex2f(width, 0.0f);
        glTexCoord2f(1.0f, 0.0f);
        glVertex2f(width, height);
        glTexCoord2f(0.0f, 0.0f);
        glVertex2f(0.0f, height);
    }
    glEnd();
    glPopMatrix();
    glEndList();
}

Menu::~Menu()
{

}

int Menu::tick()
{
    for (unsigned int i=0; i<menuButtons.size() ; ++i)
    {
        menuButtons[i].parseInput(input);
        if (menuButtons[i].getMouseClick())
        {
            return i;
        }
    }
    return -1;
}

int Menu::tick(lua_State *L)
{
    bool clicked=false;
    for (unsigned int i=0; i<menuButtons.size() ; ++i)
    {
        menuButtons[i].parseInput(input);
        if (menuButtons[i].getMouseClick())
        {
            lua_pushnumber(L, i);
            clicked=true;
        }
    }
    if (!clicked)
        lua_pushnumber(L, -1);
    return 1;
}

void Menu::draw()
{
    unsigned int i;
    glTranslatef(x, y, 0.0f);
    glColor3f(1.0f, 1.0f, 1.0f);

    if (firstrun)
    {
        glNewList(menuList, GL_COMPILE);
        glPushMatrix();
        texture_factory.applyTexture(texid);
        glBegin(GL_QUADS);
        {
            glTexCoord2f(0.0f, 1.0f);
            glVertex2f(0.0f, 0.0f);
            glTexCoord2f(1.0f, 1.0f);
            glVertex2f(width, 0.0f);
            glTexCoord2f(1.0f, 0.0f);
            glVertex2f(width, height);
            glTexCoord2f(0.0f, 0.0f);
            glVertex2f(0.0f, height);
        }
        glEnd();
        glPopMatrix();

        glColor3f(1.0f, 1.0f, 1.0f);
        glTranslatef((float)menuButtonLeftPad, (float)menuButtonTopPad, 0.1f);
        glPushMatrix();

        for (i=0; i<numTex ; i++)
        {
            texture_factory.applyTexture(menuButTex[i]);
            glPushMatrix();
            glBegin(GL_QUADS);
            {
                glTexCoord2f(0.0f, 1.0f);
                glVertex2f(0.0f, 0.0f);
                glTexCoord2f(1.0f, 1.0f);
                glVertex2f(menuButtonWidths, 0.0f);
                glTexCoord2f(1.0f, 0.0f);
                glVertex2f(menuButtonWidths, menuButtonHeights);
                glTexCoord2f(0.0f, 0.0f);
                glVertex2f(0.0f, menuButtonHeights);
            }
            glEnd();
            glPopMatrix();
            glTranslatef(0.0f, (menuButtonHeights+menuButtonButPad), 0.0f);
        }
        glPopMatrix();
        glEndList();
        firstrun=false;
    }
    else
        glCallList(menuList);
}

int Menu::draw(lua_State *L)
{
    unsigned int i;
    glTranslatef(x, y, 0.0f);
    glColor3f(1.0f, 1.0f, 1.0f);
    glCallList(menuList);
    glColor3f(1.0f, 1.0f, 1.0f);
    glTranslatef((float)menuButtonLeftPad, (float)menuButtonTopPad, 0.1f);
    glPushMatrix();
    for (i=0; i<sizeof(menuButTex.size()) ; i++)
    {
        texture_factory.applyTexture(menuButTex[i]);
        glPushMatrix();
        glBegin(GL_QUADS);
        {
            glTexCoord2f(0.0f, 1.0f);
            glVertex2f(0.0f, 0.0f);
            glTexCoord2f(1.0f, 1.0f);
            glVertex2f(menuButtonWidths, 0.0f);
            glTexCoord2f(1.0f, 0.0f);
            glVertex2f(menuButtonWidths, menuButtonHeights);
            glTexCoord2f(0.0f, 0.0f);
            glVertex2f(0.0f, menuButtonHeights);
        }
        glEnd();
        glPopMatrix();
        glTranslatef(0.0f, (menuButtonHeights+menuButtonButPad), 0.0f);
    }
    glPopMatrix();
    glDisable(GL_BLEND);
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_CULL_FACE);
    return 1;
}

int Menu::addButton(lua_State *L)
{
    menuButTex.push_back(texture_factory.loadTexture((std::string)lua_checkstring(L, 1)));
    GUI::Button temp;
    temp.setX(x+menuButtonLeftPad);
    temp.setY(y+menuButtonTopPad + (curButtons*(menuButtonHeights + menuButtonButPad)));
    temp.setW(menuButtonWidths);
    temp.setH(menuButtonHeights);
    temp.reset();
    menuButtons.push_back(temp);
    curButtons++;
    return 1;
}

void Menu::addButton(const std::string& texname)
{
    menuButTex.push_back(texture_factory.loadTexture(texname));
    numTex++;
    GUI::Button temp;
    temp.setX(x + menuButtonLeftPad);
    temp.setY(y + menuButtonTopPad + (curButtons*(menuButtonHeights + menuButtonButPad)));
    temp.setW(menuButtonWidths);
    temp.setH(menuButtonHeights);
    temp.reset();
    menuButtons.push_back(temp);
    curButtons++;
}

int Menu::setPadding(lua_State *L)
{
    menuButtonTopPad = (int)lua_checknumber(L, 1);
    menuButtonLeftPad = (int)lua_checknumber(L, 2);
    menuButtonButPad = (int)lua_checknumber(L, 3);
    return 1;
}

void Menu::setPadding(const int& x, const int& y, const int& z)
{
    menuButtonTopPad = x;
    menuButtonLeftPad = y;
    menuButtonButPad = z;
}

int Menu::setButtonDimensions(lua_State *L)
{
    menuButtonWidths = (int)lua_checknumber(L, 1);
    menuButtonHeights = (int)lua_checknumber(L, 2);
    return 1;
}

void Menu::setButtonDimensions(const int& w, const int& h)
{
    menuButtonWidths = w;
    menuButtonHeights = h;
}

const char Menu::className[]="Menu";
AzLua<Menu>::RegType Menu::methods[] = {
    { "Draw", &Menu::draw },
    { "Tick", &Menu::tick },
    { "Dimensions", &Menu::setButtonDimensions },
    { "Padding", &Menu::setPadding },
    { "AddButton", &Menu::addButton }
};





/*======================================

    Menu Factory below here!

======================================*/


MenuFactory::MenuFactory()
{
#ifndef NDEBUG
    console << Console::log << Console::highish << "Initializing Menu System" << Console::endl();
#endif
}

MenuFactory::~MenuFactory()
{

}

void MenuFactory::registerMenu(Menu *menu)
{
    menus.push_back(menu);
}

void MenuFactory::tick()
{
    for (unsigned int i=0; i < menus.size(); i++)
    {
        menus[i]->tick();
    }
}

void MenuFactory::draw(int sw, int sh)
{
    glDisable(GL_CULL_FACE);
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0, sw, sh, 0.0, -1.0, 2000);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glColor3f(1.0f, 1.0f, 1.0f);
    for (unsigned int i=0; i < menus.size(); i++)
    {
        glPushMatrix();
        menus[i]->draw();
        glPopMatrix();
    }
    glDisable(GL_BLEND);
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_CULL_FACE);
}
