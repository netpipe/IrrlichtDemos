#include "FPSCounter.h"

#include <sstream>

#ifndef __OSX__
	#include <GL/gl.h>
#else
	#include <OpenGL/gl.h>
#endif

#include "Drawing.h"
#include "../Fonts/Font.h"

GUI::FPSCounter::FPSCounter() {
	show = true;
	x = 4;
	y = 582;
	width = 100;
	height = 14;
}

void GUI::FPSCounter::parseInput(Input& input) {
}

void GUI::FPSCounter::initTextures() {
}

void GUI::FPSCounter::toggleShow()
{
    show = !show;
}

void GUI::FPSCounter::draw() {

    if (!show) return;

    Drawing::prepare2D();

	glTranslatef(0.0, 0.0, -0.5);

    glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND);

    glColor3f(1.0,1.0,1.0);
    glPushMatrix();
    glTranslatef(x+4, y, 0.0);
    text_engine.drawText(" ", "LillyUPC.ttf", 8);
    glPopMatrix();

   glColor3f(1.0,1.0,1.0);
   glDisable(GL_BLEND);
   glEnable(GL_CULL_FACE);
}

