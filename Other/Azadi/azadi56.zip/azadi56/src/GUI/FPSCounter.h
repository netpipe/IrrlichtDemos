#ifndef FPS_COUNTER_H_01112006
#define FPS_COUNTER_H_01112006

class Input;

namespace GUI {
    class FPSCounter
    {
        private:
            int x;
            int y;
            int width;
            int height;
            bool show;
            bool collapsed;
        public:
            FPSCounter();
            void draw();
            void initTextures();
            void parseInput(Input& input);
            void toggleShow();
    };

}

#endif
