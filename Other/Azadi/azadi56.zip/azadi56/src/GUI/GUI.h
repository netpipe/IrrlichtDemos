#ifndef GUI_H
#define GUI_H
#include "../XML/XML.h"
#include "../Texture/TextureFactory.h"
#include "../Fonts/Font.h"
#include <string>
#include <vector>
#include <map>

#include <SDL/SDL.h>

#ifndef __OSX__
#include <GL/gl.h>
#else
#include <OpenGL/gl.h>
#endif

#define	APPEND 0
#define	REPLACE 1

class Layout : public eventListener
{
	public:
		Layout();
		~Layout();
		void loadTemplate(screenTemplate);
		void draw(int, int);
		void updateArea(const char*, const std::string& data, int type);
		void updateArea(const char*, int data, int type);
		void updateArea(const char*, float data, int type);
		void setActive(const std::string& itemName, bool);
        void charEntered(SDLKey sym, unsigned short int ch);
        
        void cmdTriggered(std::string cmd)
        {
            if (!entering && !console.isVisible())
            {
                input.TextMode(this);
                entering = true;
                setActive("chat", true);
                updateArea("chat", "say: ", 1);
            }
            else if (console.isVisible())
                console.charEntered(SDLK_t, 116);
            else
                charEntered(SDLK_t, 116);
        };
	private:
        unsigned long pos;
        bool entering;
        std::string chat;
		screenTemplate screenTemp;
		std::map<std::string, std::vector<std::string> > areaSData;
        std::map<std::string, unsigned int> areaSMaxLines;
		std::map<std::string, int> areaIData;
		std::map<std::string, float> areaFData;
};

extern Layout gui_engine;
#endif
