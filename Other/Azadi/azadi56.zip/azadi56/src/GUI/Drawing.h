#ifndef DRAWING_HPP_05112006
#define DRAWING_HPP_05112006

#include <string>

class Drawing {
public: // YES DAMNIT!!! PUBLIC!!! --blub
	static unsigned font;
	static unsigned long int frame;
	static unsigned int last_frame_time;
	static unsigned int last_frame_length;
	static std::string font_path;
	static double fps;
	static char number_fps_values;
	static unsigned running_fps_value;
public:
	Drawing();
	static void drawText(int x, int y, std::string text);
	static void drawText(int x, int y, std::string text, unsigned size);
	static void flipBuffers();
	static unsigned long int getFrame();
	static std::string fixText(std::string raw, unsigned int length);
		
	// this makes me more than sick
	// those are voids --blub
	/*static unsigned getLastFrameTime();
	  static unsigned getLastFrameLength();
	  static double getFPS();*/
	static void prepare2D();
	static void prepare3D();
	static void init();
};

#endif
