#ifndef CONSOLE_H_01112006
#define CONSOLE_H_01112006

#include <list>
#include <sstream>
#include <map>

#include "Button.h"
#include "../Input/ConsoleListener.h"
#include "../Input/Input.h"
#include "../Scripting/ScriptEngine.h"

class Input;
extern Input input;

//! GUI framework that contains all the GUI related code (Console, FPS counter, etc). The console is implemented in the global namespace with:  console
namespace GUI {
    //! Console class that handles displaying of all messages
    class Console : public ConsoleListener, eventListener
    {
        friend class cmdparser;
        public:
            enum MessageType {error,warning,normal,user,log};
            enum MessageLevel {silent,low,lowish,medium,highish,high};
            class Message;
        private:
            int x;
            int y;
            int width;
            int height;
            unsigned long cursor; // cursor position --
            unsigned long history_pos; // pos in history --
            unsigned long history_size; // max stored strings --blub
            std::stringstream buffer;
            MessageType buffer_type;
            MessageLevel buffer_level;
            std::list<Message*> messages;
            MessageLevel verbosity_level;
            bool show;
            bool collapsed;
            bool has_focus;
            bool stick_bottom;
            Button button_up;
            Button button_down;
            Button button_collapse;
            Button button_hide;
            Button button_stick_bottom;
            Button button_verbosity_up;
            Button button_verbosity_down;
            std::list<Message*>::iterator start;
            std::list<std::string> user_commands;
            std::list<std::string>::iterator cycle_back_position;
            std::string user_command;
            std::vector<std::string> command_history;
            std::map<std::string,ConsoleListener*> listeners;
            FILE *logFile;

            void cmdTriggered(std::string cmd)
            {
                show = !show;
                has_focus =  !has_focus;
                if(input.getKeyMode())
                    input.TextMode(this);
                else
                    input.KeyMode();

            };

        public:
            Console();
            Console(Console&);
            Console& operator<<(MessageType right);
            Console& operator<<(MessageLevel right);
            Console& operator<<(std::string right);
            Console& operator<<(int);
            Console& operator<<(char);
            Console& operator<<(double);
            Console& operator<<(float);
            Console& operator<<(unsigned);
            Console& operator<<(long unsigned int);
            ~Console();
            static char endl();
            void toggleShow();
            void draw();
            void initTextures();
            bool isVisible();
            
            void charEntered(SDLKey sym, unsigned short int ch);
            void addMessage(MessageType,MessageLevel,std::string);
            void setVerbosityLevel(MessageLevel level);
            void increaseVerbosityLevel();
            void decreaseVerbosityLevel();
            void parseInput();
        /*! \brief Executes a registered Console command
            \param command: The command, including its arguments, that you want to execute
         */
            void insertUserCommand(std::string command);
        /*! \brief Register a new ConsoleListener
            \param listener: Pointer to an inhereited ConsoleListener instance. Its acceptConsoleCommand functions will be called if the cmd was entered. Use splitArgs to get the single arguments
            \param handle: The command which should be registered.
         */
            void registerObject(ConsoleListener&,std::string);
            std::string acceptConsoleCommand(std::string);
    };

}

extern GUI::Console console;

#endif
