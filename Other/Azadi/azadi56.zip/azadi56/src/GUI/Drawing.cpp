#include "Drawing.h"

#include <SDL/SDL.h>
#ifndef __OSX__
	#include <GL/gl.h>
#else
	#include <OpenGL/gl.h>
#endif

#include <string>
#include "../Texture/TextureFactory.h"
#include "Console.h"
#include "../Fonts/Font.h"

std::string Drawing::font_path = "font.png";
unsigned Drawing::font = 0;
unsigned long int Drawing::frame = 0;
unsigned int Drawing::last_frame_time = 0;
unsigned int Drawing::last_frame_length = 1;
double Drawing::fps = 0;
char Drawing::number_fps_values = 0;
unsigned Drawing::running_fps_value = 0;

Drawing::Drawing()
{
#ifndef NDEBUG
	console << GUI::Console::normal << GUI::Console::normal << "Loading Drawing subsystem" << GUI::Console::endl();
#endif
	font = texture_factory.loadTexture(font_path);

	frame = 0;
}

void Drawing::init()
{

}

void Drawing::prepare2D()
{

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glOrtho(0.0f, 800, 600, 0.0f, -1.0f, 2000.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glDepthFunc(GL_LEQUAL);
	glEnable(GL_DEPTH_TEST|GL_BLEND);
	glShadeModel(GL_SMOOTH);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

}

void Drawing::prepare3D()
{

        glMatrixMode (GL_PROJECTION);
        glLoadIdentity ();
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glViewport(0,0,800,600);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

}

void Drawing::drawText(int x, int y, std::string text)
{
	glLoadIdentity ();
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
	glTranslatef(x, y, 0.0f);

	texture_factory.applyTexture(font);

	x -= 2;

	for (unsigned int h = 0; h < text.length(); h++)
	{
		int i = text[h];

		glLoadIdentity ();
		glTranslatef(x, y, 0.0f);

		glBegin(GL_QUADS);

		glTexCoord2f((i%16)*0.0625,1-((i/16)*0.0625+0.0625));
		glVertex3f(0.0f, 8.0f, 0.0f);

                glTexCoord2f((i%16)*0.0625+0.0625,1-((i/16)*0.0625+0.0625));
                glVertex3f(8.0f, 8.0f, 0.0f);

                glTexCoord2f((i%16)*0.0625+0.0625,1-(i/16)*0.0625);
                glVertex3f(8.0f, 0.0f, 0.0f);

                glTexCoord2f((i%16)*0.0625,1-(i/16)*0.0625);
                glVertex3f(0.0f, 0.0f, 0.0f);

		glEnd();

		x += 12;

	}
	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
}

void Drawing::drawText(int x, int y, std::string text, unsigned size)
{
        glLoadIdentity ();
        glEnable(GL_BLEND);
        glEnable(GL_TEXTURE_2D);
        glTranslatef(x, y, 0.0f);

        texture_factory.applyTexture(font);

        x -= 2;

        for (unsigned int h = 0; h < text.length(); h++)
        {
                int i = text[h];

                glLoadIdentity ();
                glTranslatef(x, y, 0.0f);

                glBegin(GL_QUADS);

                glTexCoord2f((i%16)*0.0625,1-(i/16)*0.0625);
                glVertex3f(0.0f, 0.0f, 0.0f);

                glTexCoord2f((i%16)*0.0625+0.0625,1-(i/16)*0.0625);
                glVertex3f(size, 0.0f, 0.0f);

                glTexCoord2f((i%16)*0.0625+0.0625,1-((i/16)*0.0625+0.0625));
                glVertex3f(size, size, 0.0f);

                glTexCoord2f((i%16)*0.0625,1-((i/16)*0.0625+0.0625));
                glVertex3f(0.0f, size, 0.0f);
                glEnd();

                x += size*2/4;

        }

        glDisable(GL_BLEND);
        glDisable(GL_TEXTURE_2D);
}


void Drawing::flipBuffers()
{
	frame++;
	last_frame_length = SDL_GetTicks() - last_frame_time;
	last_frame_time = SDL_GetTicks();
	running_fps_value += last_frame_length;
	number_fps_values++;
	if (number_fps_values==10) {
		number_fps_values = 0;
		fps = 10000.0 / running_fps_value;
		running_fps_value = 0;
	}

	SDL_GL_SwapBuffers();
}

unsigned long int Drawing::getFrame()
{
	return frame;
}

std::string Drawing::fixText(std::string raw, unsigned int length)
{
	if (raw.length() <= length)
		return raw;

	return raw.substr(0,length-3) + "...";
}
