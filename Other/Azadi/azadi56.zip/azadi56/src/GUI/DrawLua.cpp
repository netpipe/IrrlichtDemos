#include "DrawLua.h"
#ifndef __OSX__
	#include <GL/gl.h>
#else
	#include <OpenGL/gl.h>
#endif
#include <SDL/SDL.h>
#include "../Texture/TextureFactory.h"
#include "../Azadi.h"

DrawLua::DrawLua(lua_State *L)
{

}

DrawLua::~DrawLua()
{

}

int DrawLua::drawRect(lua_State *L)
{
	// Check all the arguments
	lua_checknumber(L, 1);  // x
	lua_checknumber(L, 2);  // y
	lua_checknumber(L, 3);  // w
	lua_checknumber(L, 4);  // h
	lua_checknumber(L, 5);  // Texture ID

    glDisable(GL_CULL_FACE);
    glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, 1024, 768, 0, -1.0, 1.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	// Sixth argument is the alpha bit
	if (lua_tonumber(L, 6) == 1)
		glEnable(GL_BLEND);
	else
		glDisable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glColor3f(1.0, 1.0, 1.0);
	texture_factory.applyTexture((int)lua_tonumber(L, 5));
	glBegin(GL_QUADS);
	{
		glTexCoord3f(0.0, 1.0, 0.0);
		glVertex2f(lua_tonumber(L, 1), lua_tonumber(L, 2));
		glTexCoord3f(1.0, 1.0, 0.0);
		glVertex2f(lua_tonumber(L, 3), lua_tonumber(L, 2));
		glTexCoord3f(1.0, 0.0, 0.0);
		glVertex2f(lua_tonumber(L, 3), lua_tonumber(L, 4));
		glTexCoord3f(0.0, 0.0, 0.0);
		glVertex2f(lua_tonumber(L, 1), lua_tonumber(L, 4));
	}
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);
	glEnable(GL_CULL_FACE);

	return 1;
}

int DrawLua::clearBuffers(lua_State *L)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    return 1;
}

int DrawLua::set2D(lua_State *L)
{
    glDisable(GL_CULL_FACE);
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, Azadi::screen[0], Azadi::screen[1], 0, -1.0, 2000);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    return 1;
}

int DrawLua::set3D(lua_State *L)
{
    glEnable(GL_CULL_FACE);
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum (-1.0, 1.0, -1.0, 1.0, 1.5, 20000.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    return 1;
}

int DrawLua::flipBuffers(lua_State *L)
{
	SDL_GL_SwapBuffers();
	return 1;
}

const char DrawLua::className[] = "Draw";
AzLua<DrawLua>::RegType DrawLua::methods[] = {
	{ "drawRect", &DrawLua::drawRect },
	{ "clearBuffers", &DrawLua::clearBuffers },
	{ "set2D", &DrawLua::set2D },
	{ "set3D", &DrawLua::set3D },
	{ "flipBuffers", &DrawLua::flipBuffers },
	{ 0, 0 }
};
