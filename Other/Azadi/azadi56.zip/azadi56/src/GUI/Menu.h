#ifndef MENU_H
#define MENU_H

#ifndef __OSX__
#include <GL/gl.h>
#else
#include <OpenGL/gl.h>
#endif

#include "../Scripting/ScriptEngine.h"
#include "../Texture/TextureFactory.h"
#include "../GUI/Console.h"
#include "../GUI/Button.h"

class Menu
{
    public:
        Menu(const int&, const int&, const int&, const int&, const std::string&);
        Menu(lua_State *L);
        ~Menu();
        int toggleVisible();
        int tick();
        int tick(lua_State *L);
        void draw();
        int draw(lua_State *L);
        int addButton(lua_State *L);
        void addButton(const std::string&);
        int setPadding(lua_State *L);
        void setPadding(const int&, const int&, const int&);
        int setButtonDimensions(lua_State *L);
        void setButtonDimensions(const int&, const int&);
        static const char className[];
        static AzLua<Menu>::RegType methods[];
    private:
        int x;
        int y;
        int width;
        int height;
        unsigned int texid;
        int menuList;
        int menuButtonWidths;
        int menuButtonHeights;
        int menuButtonTopPad;
        int menuButtonLeftPad;
        int menuButtonButPad;
        unsigned int numTex;
        unsigned int curButtons;
        std::vector<unsigned int> menuButTex;
        std::vector<GUI::Button> menuButtons;
        bool firstrun;
};

class MenuFactory
{
    public:
        MenuFactory();
        ~MenuFactory();
        void registerMenu(Menu*);
        void tick();
        void draw(int sw, int sh);
    private:
        std::vector<Menu*> menus;
};

extern MenuFactory menu_factory;

#endif
