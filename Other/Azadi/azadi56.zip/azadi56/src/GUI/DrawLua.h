#include "../Scripting/ScriptEngine.h"
#include "Drawing.h"

// Drawing class for lua
class DrawLua
{
	public:
		DrawLua(lua_State *);
		~DrawLua();
		int drawRect(lua_State *);
        int clearBuffers(lua_State *);
        int set2D(lua_State *);
        int set3D(lua_State *);
		int flipBuffers(lua_State *);
		static const char className[];
		static AzLua<DrawLua>::RegType methods[];
};
