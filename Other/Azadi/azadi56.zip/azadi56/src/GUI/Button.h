#ifndef BUTTON_H
#define BUTTON_H

class Input;

namespace GUI
{

    class Button {
    public:
        enum direction {DIRECTION_RIGHT, DIRECTION_DOWN, DIRECTION_LEFT, DIRECTION_UP};
    protected:
        signed x;
        signed y;
        signed w;
        signed h;
        direction current_direction;
        unsigned referenceID;
        bool is_clicked;
        bool is_down;
        bool scrolled_up;
        bool scrolled_down;
        unsigned button_number;
    public:
        Button();
        Button(signed x, signed y, signed w, signed h, direction current_direction);
        Button& setX(signed x);
        Button& setY(signed y);
        Button& setW(signed w);
        Button& setH(signed h);
        Button& transX(int x);
        Button& transY(int y);
        Button& setDirection(direction current_direction);
        Button& setButtonNumber(unsigned number);
        void reset();
        void draw();
        void parseInput(Input& input);
        bool getMouseClick();
        bool getMouseDown();
        bool getScrollUp();
        bool getScrollDown();
        int getHitPositionX(Input &input);
        int getHitPositionY(Input &input);
        void initTextures();
    };
}


#endif
