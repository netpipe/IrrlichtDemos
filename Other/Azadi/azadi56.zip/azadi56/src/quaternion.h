#ifndef QUATERNION_H
#define QUATERNION_H

#include "matrix.h"
#include <cmath>

//! Quaternion class
template<class T>
class quaternion
{
  public:
        quaternion(const T& w=0, const T& x=0, const T& y=0, const T& z=0)
        {
            this->W = w;
            this->X = x;
            this->Y = y;
            this->Z = z;
        }

        quaternion(const quaternion<T> &copy)
        {
            *this = copy;
        }

	double getLength() { return sqrt(W*W+X*X+Y*Y+Z*Z); }
        static float length(const quaternion<T> &rhs)
        {
            return sqrt(dot(rhs));
        }

        quaternion<T> normalize(void) const
        {
            float size = length(this);
            return quaternion<T>
            (
                this->W/size,
                this->X/size,
                this->Y/size,
                this->Z/size
            );
        }

        quaternion<T> conjugate() const
        {
            return quaternion<T>
            (
                this->W,
                -this->X,
                -this->Y,
                -this->Z
            );
        }

        matrix3<T> tomat3() const
        {
            return matrix3<T>
            (
                1-(2*(this->Y*this->Y)) - 2*(this->Z*this->Z), 2*(this->X*this->Y) - 2*(this->W*this->Z), 2*(this->X*this->Z) + 2*(this->W*this->Y),
                2*(this->X*this->Y) + 2*(this->W*this->Z), 1-(2*(this->X*this->X) - 2*(this->Z*this->Z)), 2*(this->Y*this->Z) - 2*(this->W*this->X),
                2*(this->X*this->Z) - 2*(this->W*this->Y), 2*(this->Y*this->Z) + 2*(this->W*this->X), 1-(2*(this->X*this->X) - 2*(this->Y*this->Y))

            );
        }

        matrix4<T> tomat4() const
        {
            return matrix4<T>
            (
                1-(2*(this->Y*this->Y)) - 2*(this->Z*this->Z), 2*(this->X*this->Y) - 2*(this->W*this->Z), 2*(this->X*this->Z) + 2*(this->W*this->Y), 0,
                2*(this->X*this->Y) + 2*(this->W*this->Z), 1-(2*(this->X*this->X) - 2*(this->Z*this->Z)), 2*(this->Y*this->Z) - 2*(this->W*this->X), 0,
                2*(this->X*this->Z) - 2*(this->W*this->Y), 2*(this->Y*this->Z) + 2*(this->W*this->X), 1-(2*(this->X*this->X) - 2*(this->Y*this->Y)), 0,
                0                                        , 0                                        , 0                                            , 1
            );
        }

        // to do (Aren again)
        void rotate(double angle, const vector3<T> &axis)
        {
            this->W = cos(angle/2);
            double sn = sin(angle/2.0); // I don't trust any compiler's optimization --blub
            this->X = axis.X*sn;
            this->Y = axis.Y*sn;
            this->Z = axis.Z*sn;
        }

        quaternion<T> inverse() const
        {
            quaternion<T> temp;
            temp = this->conjugate();
            return quaternion<T>
            (
                temp->W /(this->W * this->W),
                temp->X /(this->X * this->X),
                temp->Y /(this->Y * this->Y),
                temp->Z /(this->Z * this->Z)
            );
        }

	// wouldn't we need a check for time > 1? it would need the next "frame"? --blub
        quaternion<T> linearinterpolate(float time, const quaternion<T> &rhs) const
        {
            return (*this)*(1.0-time) + (rhs*time); // time*rhs, float has no op*(quat) --blub
        }

        quaternion<T> norminterpolate(float time, const quaternion<T> &rhs) const
        {
            return (*this)*((1.0-time) + (rhs*time))/length((1-time)*this + (rhs*time));
        }

        // to do! (Aren)
        quaternion<T> constinterpolate(float time, const quaternion<T> &rhs) const
        { // this is just a test: --blub
            return (*this) + (rhs - (*this)) * time;
        }

        float dot(const quaternion<T> &rhs) const
        {
            return (this->W*rhs.W) + (this->X*rhs.X) + (this->Y*rhs.Y) + (this->Z*rhs.Z);
        }

        quaternion<T> operator+(const quaternion<T> &rhs) const
        {
            return quaternion<T>
            (
                this->W+rhs.W,
                this->X+rhs.X,
                this->Y+rhs.Y,
                this->Z+rhs.Z
            );
        }

        quaternion<T> operator-(const quaternion<T> &rhs) const
        {
            return quaternion<T>
            (
                this->W-rhs.W,
                this->X-rhs.X,
                this->Y-rhs.Y,
                this->Z-rhs.Z
            );
        }

        quaternion<T> operator*(const quaternion<T> &rhs) const
        {
            return quaternion<T>
            (
                this->W*rhs.W,
                this->X*rhs.X,
                this->Y*rhs.Y,
                this->Z*rhs.Z
            );
        }

        quaternion<T> operator*(const float x) const
        {
            return quaternion<T>
            (
                this->W*x,
                this->X*x,
                this->Y*x,
                this->Z*x
            );
        }

       quaternion<T> &operator=(const quaternion<T> &rhs)
       {
            this->W = rhs.W;
            this->X = rhs.X;
            this->Y = rhs.Y;
            this->Z = rhs.Z;
            return *this;
       }

        quaternion<T> &operator*=(const quaternion<T> &rhs)
        {
            this->W = (this->W*rhs.W) - (this->X*rhs.X) - (this->Y*rhs.Y) - (this->Z*rhs.Z);
            this->X = (this->W*rhs.X) + (this->X*rhs.W) + (this->Y*rhs.Z) - (this->Z*rhs.Y);
            this->Y = (this->W*rhs.Y) - (this->Z*rhs.X) + (this->Y*rhs.W) + (this->Z*rhs.X);
            this->Z = (this->W*rhs.Z) + (this->X*rhs.Y) - (this->Y*rhs.X) + (this->Z*rhs.W);
	    return (*this);
        }


        T W, X, Y, Z;
};

#endif
