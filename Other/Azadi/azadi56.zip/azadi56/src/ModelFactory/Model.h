#ifndef MODEL_H_INCLUDED
#define MODEL_H_INCLUDED

#include "ModelFactory.h"
#include "Frame.h"
#include "Bone.h"


class Controller
{
    public:
        Controller(Bone * b);
        void update(); // Time to update our bone
        const std::string name;


    private:
        Bone * bone; // The bone this Controller controlls
        struct pos
        {
            float time;
            int id;
            matrix4<float> pos;
        };

        std::vector<pos> positions;
};






class multiVertex
{
    public:
        multiVertex()
        {
            id=-1;
        }
        ~multiVertex()
        {
            for(std::list<vector3<GLfloat>* >::iterator it=vertices.begin(); it != vertices.end(); it++)
                delete *it;
        }
        void setBase(vector3<GLfloat> *nbase)
        {
            base=nbase;
        }
        vector3<GLfloat> * addVertex()
        {
            vector3<GLfloat> * tmp = new vector3<GLfloat>;
            *tmp = *base;
            vertices.push_back(tmp);
            return tmp;
        }
        void updateBase()
        {
            base->reset();
            for(std::list<vector3<GLfloat>* >::iterator it=vertices.begin(); it != vertices.end(); it++)
                *base += *(*it);

            *base /=  (vertices.size());
        }

        int id;
    private:
        std::list<vector3<GLfloat>* >  vertices;
        vector3<GLfloat>* base;

};









/*! \brief Model class
 */
class ModelFactory::Model
{
	friend class ModelFactory;
	friend class ModelLua;
    public:
        class Action;
        /*! \brief Constructor
        \param md: a pointer to the Models data ( vertices,textures,faces,bones)
        */
        Model(mdata * md);

        ~Model();
        //! Draw it..
        void Draw();
        //! Update the animations(actions) of the model
        void Update();

        //! \brief Searches and returns the corresponding action-id to the name
        int getActionIDbyName(std::string name);
        //! finds an action by its name and return a iterator to it
        std::list<Action>::iterator getActionPbyName(std::string name);
        //! finds an action by its id and return a iterator to it
        std::list<Action>::iterator getActionPbyID(int id);

        void play(std::list<Action>::iterator);
        void stop(std::list<Action>::iterator);

        void reset(); //! Reset all actions

        //! Sets the Location in 3D Space
        void setLoc(float x,float y,float z);
        //! Sets the Rotation in 3D Space
        void setRot(float w,float x,float y,float z);

      /*  float *getLoc();
        float *getRot();*/

        //! Is this Model enabled
        bool enabled;
        bool drawSkeleton;  //! Draw the skelet or not
        bool drawMeshes;    //! Draw the meshes or not

    private:
        //! Lists  of actions
        std::list<Action> actions;
        std::list<Action*> active;

    public:
        float loc[3]; // Location of the model
        float rot[4]; // Rotation ..
        matrix4<float> *Matrix;
    private:
        void updateBones(char level);

        Frame merged;
        ModelFactory::mdata * ModelData; // Pointer to Modeldata

        std::list<multiVertex> multiVerts;
        vector3<GLfloat> *  vertices;
        int numVertices;

        Bone* bones;
        int numBones;

        struct grp
        {
            grp(char w,workingVertexGroup* i) { way=w; id=i; }
            char way;
            workingVertexGroup * id;
        };


};







#endif // MODEL_H_INCLUDED
