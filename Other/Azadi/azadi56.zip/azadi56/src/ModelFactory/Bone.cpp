#include "Bone.h"

/** @brief
  *
  *
  */
void Bone::apply()
{

    if(EditState == true)
    {
        matrix4<float> tmp = Matrix;
        tmp.inverse();

        tmp= (*ModelMatrix)*tmp;
        //Calculate all vertices back, so they are realtive to the bone
        for(std::vector<vector3<GLfloat> * >::iterator it=Vertices.begin(); it != Vertices.end(); it++)
            *(*it) = tmp.multiplyVector((*(*it)));
    }
}

/** @brief setData
  *
  * @todo: document this function
  */
void Bone::setData(workingBone * data,matrix4<float> * mm)
{
    Data = data;

    OriginalMatrix.setTranslation(Data->loc);
    OriginalMatrix.setRotation(Data->rot);
    Matrix = OriginalMatrix; //! We need the Original Matrix in case the setVertices Function gets recalled.

    ModelMatrix=mm;
}

/** @brief setVertices
  *
  * @todo: document this function
  */
void Bone::setVertices(std::vector<vector3<GLfloat> * > verts)
{
    Vertices = verts;
    fullUpdate=true;
}

/** @brief addLocation
  *
  * @todo: document this function
  */
void Bone::addLocation(vector3<float> vec)
{
    EditMode();
    Matrix.W4+= vec.X;
    Matrix.X4+= vec.Y;
    Matrix.Y4+= vec.Z;
}

/** @brief setLocation
  *
  * @todo: document this function
  */
void Bone::setLocation(vector3<float> vec,bool space)
{
    EditMode();
    if(space==MODEL_SPACE)
        Matrix.setTranslation(vec);
}

/** @brief addRotation
  *
  * @todo: document this function
  */
void Bone::addRotation(quaternion<float> rot)
{
    EditMode();
}

/** @brief setRotation
  *
  * @todo: document this function
  */
void Bone::setRotation(quaternion<float> rot,bool space)
{
    EditMode();
    if(space==MODEL_SPACE)
        Matrix.setRotation(rot);
}

/** @brief getRotation
  *
  * @todo: document this function
  */
quaternion<float> Bone::getRotation()
{

}

/** @brief getLocation
  *
  * @todo: document this function
  */
vector3<float> Bone::getLocation()
{
    return Matrix.translationVector();
}

/** @brief EditMode
  *
  * @todo: document this function
  */
void Bone::EditMode()
{
    if(EditState)
        return;

    matrix4<float> tmp = *ModelMatrix;
    tmp.inverse();

    if(fullUpdate)
        tmp=OriginalMatrix*tmp;
    else
        tmp=Matrix*tmp;

    for(std::vector<vector3<GLfloat> * >::iterator it=Vertices.begin(); it != Vertices.end(); it++)
        *(*it) = tmp.multiplyVector(*(*it));

    EditState=true;
}




/** @brief Bone
  *
  * @todo: document this function
  */
 Bone::Bone()
{
    fullUpdate=EditState=false;
    Vertices.clear();
}

