#ifndef __FILESTRUCT
#define __FILESTRUCT

#include <map>
#include <bitset>
#include "../matrix.h"
#include "../quaternion.h"
#include "../vector.h"

struct fileAction
{
    unsigned int frameNum;  // Length of the uint array which contains the indexes of the frames
    unsigned int name;
};



struct workingAction
{
    unsigned int numFrames;
    unsigned int * frames;
    unsigned int frame;
    bool play;
    char * name;
};




struct fileFrame
{
    unsigned int nr;
    unsigned int numBonePositions; // Length of the uint array which contains the bone-positions
};


struct fileBonePos
{
    unsigned int boneID;
    float loc[3];
    float rot[4];
};



struct workingBonePos
{
    vector3<float> loc;
    quaternion<float> rot;
    workingBonePos()
    {

    };

    workingBonePos(vector3<float> v,const quaternion<float> &r)
    {
        loc=v;
        rot=r;
    };


    workingBonePos(const workingBonePos &tmp)
    {
        loc = tmp.loc;
        rot = tmp.rot;
    };

    workingBonePos(const workingBonePos* tmp)
    {
        loc = tmp->loc;
        rot = tmp->rot;
    };

    workingBonePos linearinterpolate(const workingBonePos &tmp,float time)
    {
        workingBonePos tmp2 = workingBonePos (loc.linearinterpolate(tmp.loc,time),rot.linearinterpolate(time,tmp.rot));
        console << "rot.W " <<  tmp.rot.W << " + " << this->rot.W << " = " << tmp2.rot.W << GUI::Console::endl();
        console << "rot.X " <<  tmp.rot.X << " + " << this->rot.X << " = " << tmp2.rot.X << GUI::Console::endl();
        console << "rot.Y " <<  tmp.rot.Y << " + " << this->rot.Y << " = " << tmp2.rot.Y << GUI::Console::endl();
        console << "rot.Z " <<  tmp.rot.Z << " + " << this->rot.Z << " = " << tmp2.rot.Z << GUI::Console::endl();
        console << "loc.X " <<  tmp.loc.X << " + " << this->loc.X << " = " << tmp2.loc.X << GUI::Console::endl();
        console << "loc.Y " <<  tmp.loc.Y << " + " << this->loc.Y << " = " << tmp2.loc.Y << GUI::Console::endl();
        console << "loc.Z " <<  tmp.loc.Z << " + " << this->loc.Z << " = " << tmp2.loc.Z << GUI::Console::endl();
        return tmp2;
    }

};




struct workingFrame
{
    float nr;
    std::map<unsigned int,workingBonePos> *positions;
};



//! Struct of a Bone
struct fileBone
{
    float qRotate[4]; // Quaternion
    float vOffset[3]; // Vector
    float fLength; // of the Bone..
    int nJointType;
    int children[8];
    int Parent;
    float weight;
    char options;   // 0=CONNECTED 1=HINGE 2=CONNECTED+HINGE
    unsigned int nameL; // amount of chars following this struct
};



//! Struct of the Bone we will actually work with
struct workingBone
{
    vector3<float> loc;
    quaternion<float> rot;
    float fLength; // of the Bone..
    int nJointType;
    int children[8];
    int Parent;
    float weight;
    char options;   // 0=CONNECTED 1=HINGE 2=CONNECTED+HINGE
    char * name; //name
};



//! Vertex Struct
struct fileVertex
{
    float vPos[3]; // Vertex Position
};


//! Face Struct
struct fileFace
{
    unsigned int normal;
    unsigned int numVertices; // how long the array of vertices is which will follow this struct
    unsigned int texture;
};


struct fileVertex2D
{
    float vPos[2];
};


struct workingFace
{
    unsigned int normal;
    unsigned int * vertices;
    unsigned int numVertices;
    unsigned int texId;
    fileVertex2D * uvcoords;
};



//! The vertex Group header struct
struct fileVertexGroup
{
    unsigned int detailLevel;
    unsigned int boneID;
    unsigned int vertexL; // amount of ints following the name
};

struct workingVertexGroup
{
    unsigned int detailLevel;
    unsigned int boneID;
    unsigned int vertexL;
    unsigned int * vertices;
};



//! This is the File Header
struct fileHeader
{
    //! Version of the file
    unsigned int version;
    //! Number of bones
    unsigned int numBones;
    unsigned int numVertices;
    unsigned int numFaces;
    unsigned int numGroups;
    unsigned int numTextures;
    unsigned int numActions;
    unsigned int numFrames;
};


#endif
