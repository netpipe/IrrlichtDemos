#include "ModelFactory.h"
#include "Action.h"
#include "Mdata.h"
#include "../GUI/Console.h"
#include "../Texture/TextureFactory.h"
#include "../glmatrix.h"


#define DEFAULT_DETAIL_LEVEL 1


ModelFactory::Model::Model(mdata * md)
	:  multiVerts(), vertices()
{
	loc[0]=loc[1]=loc[2]=rot[0]=rot[1]=rot[2]=rot[3] = 0;
	drawSkeleton=drawMeshes=enabled=true;

	ModelData=md;
	merged.pos=0;

	reset();
	Update();

	Matrix = new matrix4<GLfloat>[md->numVGroups];



	//! Setup Vertices Array and put data in
	numVertices=md->numVerts;
	vertices = new vector3<GLfloat>[numVertices];
	// write all vertices in an array
	for(unsigned int i=0; i < md->numVerts;i++)
		vertices[i]=vector3<GLfloat> (md->vertices[i].vPos[0],md->vertices[i].vPos[1],md->vertices[i].vPos[2]);


	//! Setup Bone Array
	bones = new Bone[md->numBones];
	numBones = md->numBones;

	for(int i=0; i < numBones; i++) // for each bone
		bones[i].setData(&(ModelData->bones[i]),Matrix); // give it its data pointer

	updateBones(DEFAULT_DETAIL_LEVEL);



}

ModelFactory::Model::~Model()
{
	if(bones && numBones)
		delete[] bones;
	if(vertices)
		delete[] vertices;
	if(Matrix)
		delete[] Matrix;
}

/** @brief updates the Bones vertices to the given level
 *
 *
 */
void ModelFactory::Model::updateBones(char level)
{
	// get the number of groups a vertex is member in
	char * vertexGr = new char[ModelData->numVerts]; // Setup the Array that will hold the number of how much bones owne the vertex
	for(unsigned int i=0; i < ModelData->numVerts; i++)
		vertexGr[i] = 0; // Zero it

	for(unsigned int i=0; i < ModelData->numVGroups; i++) // For each Group/Bone
		if(ModelData->vGroups[i].detailLevel==level) // If its the needed Level
			for(unsigned int o=0; o < ModelData->vGroups[i].vertexL; o++) // For each vertex
				if(ModelData->vGroups[i].vertices[o] < numVertices) // if its in valid range
					vertexGr[ModelData->vGroups[i].vertices[o]]++; // increase its number


	for(int i=0; i < numBones; i++) // for each bone
	{
		std::vector<vector3<GLfloat> * > tmp; // tmp array, holds the vertices-pointer that get passed to the bone

		std::list<grp> tmpgrp;

		for(unsigned int o=0; o < ModelData->numVGroups;o++) // get all Groups for that bone
			if(ModelData->vGroups[o].boneID == i)
				tmpgrp.push_back(grp(abs(level-ModelData->vGroups[o].detailLevel),&(ModelData->vGroups[o])));


		// get the lowest way ( the detaillevel that is nearest to the needed one )
		std::list<grp>::iterator lowest=tmpgrp.begin();
		for(std::list<grp>::iterator it=tmpgrp.begin(); it != tmpgrp.end(); it++)
			if(it->way < lowest->way)
				lowest=it;

		for(unsigned int u=0; u < lowest->id->vertexL; u++)  // for each vertex in this group
			if(lowest->id->vertices[u] < numVertices) // if its in range
			{
				if(lowest->id->vertices[u] > 1)// is it a multiVertex ( a vertex that is part of several Groups/Bones)
				{
					bool found=false;
					// first check if it exists already in the multiVertexArray
					for(std::list<multiVertex>::iterator it=multiVerts.begin();it!=multiVerts.end();it++)
						if(it->id == lowest->id->vertices[u]) // We found it!
						{
							found=true;
							tmp.push_back(it->addVertex());// now we add a new vertex and get its pointer (and add it to the vec)
						}

					if(!found) // it does not exist yet
					{
						multiVertex tmpvert; // so .. create it
						tmpvert.setBase(&(vertices[lowest->id->vertices[u]]));
						tmp.push_back( tmpvert.addVertex() );
						multiVerts.push_back(tmpvert);
					}
				}else
					tmp.push_back( &(vertices[lowest->id->vertices[u]])); // Add it to the vector
			}

		bones[i].setVertices(tmp);
	}

	delete[] vertexGr;
}






void ModelFactory::Model::reset()
{
	actions = ModelData->defaultactions;
}

// i wish that one would be inlined... -_- -blb
void ModelFactory::Model::setLoc(float x,float y,float z)
{
	loc[0]=x;
	loc[1]=y;
	loc[2]=z;
}


void ModelFactory::Model::setRot(float w,float x,float y,float z)
{
	rot[0]=w;
	rot[1]=x;
	rot[2]=y;
	rot[3]=z;
}


// the following was nothing but a java..
// uh, i meant, leak...
// it's the same anyway --blub
/*float * ModelFactory::Model::getLoc()
  {
  float *tmp = new float[3];
  memcpy(tmp,loc,3*sizeof(float));
  return tmp;
  }

  float * ModelFactory::Model::getRot()
  {
  float *tmp = new float[4];
  memcpy(tmp,rot,4*sizeof(float));
  return tmp;
  }*/


void ModelFactory::Model::play(std::list<Action>::iterator it)
{
	if(it->play==true)
		return;
	else
	{
		it->play=true;
		active.push_back((Action*) &(*it));
	}

}


void ModelFactory::Model::stop(std::list<Action>::iterator it)
{
	if(it->play==false)
		return;
	else
	{
		for(std::list<Action*>::iterator iter = active.begin(); iter != active.end(); iter++)
			if(*iter == (Action*) &(*it))
			{
				active.erase(iter);
				it->play=false;
				return;
			}
	}
}

void ModelFactory::Model::Update()
{
	/*
//    for(std::map<unsigned int,workingBonePos>::iterator itposition.positions.
unsigned int changes=0;

std::list<Action* >::iterator it,it2;
//! Update all active Actions
for(it = active.begin(); it != active.end();it++)
changes+=(*it)->update();

if(changes > 0) // s.th. did an update, we need to reinterpolate
{
std::list<Frame> tmp;
for(it=it2 = active.begin();it != active.end(); it++)
if(it != active.end() && ++it2 != active.end())
tmp.push_back((*(it))->position->linearinterpolate(*((*(it2))->position),0.5));
else if (it != active.end() && active.size() > 1)
{
it2=it; it2--;
tmp.push_back((*(it))->position->linearinterpolate(*((*(it2))->position),0.5));
}
else
tmp.push_back((*(it))->position);


while(tmp.size() > 1)
for(std::list<Frame>::iterator it = tmp.begin();it != tmp.end(); it++)
if(it++ != tmp.end())
{
*(--it) = (it)->linearinterpolate(*(++it),0.5);
tmp.erase(it);
}
else
{
*(--it) = ((++it)->linearinterpolate(*(--it),0.5));
tmp.erase(++it);
}


if(merged.bones.size() >0)
console << merged.bones[2].rot.W << "<- bone 1, rot,w ->" << tmp.begin()->bones[2].rot.W << GUI::Console::endl();


merged=*(tmp.begin());

for(unsigned int i=0; i < ModelData->numVGroups;i++)
for(unsigned int o=0; o < ModelData->vGroups[i].vertexL; o++)
{
//vertices[ModelData->vGroups[i].vertices[o]] *= merged.bones[ModelData->vGroups[i].boneID].loc;
vertices[ModelData->vGroups[i].vertices[o]] =
glmatrix<GLfloat>(merged.bones[ModelData->vGroups[i].boneID].rot,
merged.bones[ModelData->vGroups[i].boneID].loc).Transform(
vertices[ModelData->vGroups[i].vertices[o]]);

}
}
	*/
	}



int ModelFactory::Model::getActionIDbyName(std::string name)
{
	int i=0;
	for(std::list<Action>::iterator Iterator = actions.begin(); Iterator != actions.end(); Iterator++)
	{
		if(Iterator->Name == name)
			return i;

		i++;
	}
	return -1;
}

//! finds an action by its name and return a pointer to it
std::list<ModelFactory::Model::Action>::iterator ModelFactory::Model::getActionPbyName(std::string name)
{
	for(std::list<Action>::iterator Iterator = actions.begin(); Iterator != actions.end(); Iterator++)
		if(Iterator->Name == name)
			return Iterator;

	return actions.end();

}

std::list<ModelFactory::Model::Action>::iterator ModelFactory::Model::getActionPbyID(int id)
{
	if(actions.size() > (unsigned) id)
	{
		std::list<Action>::iterator Iterator = actions.begin();
		for(int i=0; i < (int) id; i++)
			Iterator++;

		return Iterator;
	}
	return actions.end();
}




void ModelFactory::Model::Draw()
{
	if(enabled)
	{
		glPushMatrix(); // Save the Matrix
		glTranslatef(loc[0],loc[1],loc[2]);
		glRotatef(rot[0],rot[1],rot[2],rot[3]);
		if(drawSkeleton)
		{
			glColor3f(1.0,1.0,0.0);
			glBegin(GL_LINES);
			for(unsigned int i=0; i < numBones;i++)
			{
				//glPushMatrix(); // Save the Matrix

				//glTranslatef(ModelData->bones[i].loc.X,ModelData->bones[i].loc.Y,ModelData->bones[i].loc.Z);
				//glRotatef(ModelData->bones[i].rot.W,ModelData->bones[i].rot.X,ModelData->bones[i].rot.Y,ModelData->bones[i].rot.Z);

				vector3<float> tmp = bones[i].getLocation();
			//	glVertex3f(tmp.X ,tmp.Y,tmp.Z);
			//	glVertex3f(0 ,ModelData->bones[i].fLength,0);

				//glPopMatrix();
			}
			glEnd();
		}

		if(drawMeshes)
		{
			glColor3f(1.0, 1.0, 1.0);
			for (unsigned int i=0; i < ModelData->numFaces;i++)
			{
				//   for(unsigned int o=0; o < numBones;o++)
				//        bones[o].apply(); // Make sure all Bones updated their vertices

				//    for(std::list<multiVertex>::iterator it=multiVerts.begin();it!=multiVerts.end();it++)
				//       it->updateBase(); // Prepare multiVerts


				if(ModelData->numTextures > 0)
					texture_factory.applyTexture(ModelData->texID[ModelData->faces[i].texId]);


				glBegin(GL_POLYGON);

				/* ========================================

				Suprano, the following two lines cause a segfault on windows.
				I've commented them out, but the lighting is no longer working correctly without
				these two.

				It's possible that there's a segmentation fault happening here. Something uninitialised?

				===========================================*/
				//if( ModelData->faces[i].normal < ModelData->numVerts)
				//	glNormal3f(vertices[ModelData->faces[i].normal].X,vertices[ModelData->faces[i].normal].Y,vertices[ModelData->faces[i].normal].Z);

				for(unsigned int vi=0; vi < ModelData->faces[i].numVertices;vi++)
					if( ModelData->faces[i].vertices[vi] < ModelData->numVerts)
					{
						if(ModelData->numTextures > 0)
							glTexCoord2fv(ModelData->faces[i].uvcoords[vi].vPos);


						glVertex3f(ModelData->vertices[ModelData->faces[i].vertices[vi]].vPos[0],
                                   ModelData->vertices[ModelData->faces[i].vertices[vi]].vPos[1],
                                   ModelData->vertices[ModelData->faces[i].vertices[vi]].vPos[2]);
					}
					else
						console << GUI::Console::warning << GUI::Console::lowish << "Modeldrawer: Vertex " << vi << " out of Range(" << ModelData->numVerts << ")" << GUI::Console::endl();

				glEnd();

			}
			glPopMatrix();

		}
	}
}
