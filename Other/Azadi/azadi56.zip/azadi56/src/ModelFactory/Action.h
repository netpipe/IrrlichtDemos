#ifndef ACTION_H_INCLUDED
#define ACTION_H_INCLUDED

#include <string>
#include <map>

#include "FileStructs.h"
#include "Model.h"
#include "Frame.h"

/*! \brief Action interface and handler

 */
class ModelFactory::Model::Action
{
    friend class Model;
    public:

        Action(std::string name);

        /*! \brief Set the active Frame
            \param Takes the Framenumber as parameter
         */
        void setFrame(unsigned int frm);
        /*! \brief Get the active Layout
            \return Returns if it was successful or not
         */
        float getFramePosition();
        /*! \brief Adds a KeyFrame to the Animation
         */
        void addKeyFrame(Frame);
        /*! \brief Reports the status of the Animation
            \return If the Animation is completed or not
         */
        bool Status(); // Completed?


        std::string getName();


        /*! \brief Speed of the Animation. Default is 1.0

            Frames per intervall
         */
        float speed; // How much frames per intervall ?

        //! How often to update the positions
        unsigned int intervall; // Intervall of Position Update
        //! Loop the animation or not
        bool loop;

        /*! \brief Turns flexible Mode on
            \param flex: the action will interpolate to flexibleFrame until it is reached and then stops
        */
        void flexibleMode(Frame flex);
        /*! \brief Turns flexible Mode on
            \param flex: the action will interpolate to flexibleFrame until it is reached and then stops
        */
        void flexibleMode(Frame &flex);
        /*! \brief Switches back to normal mode

            After switching back the animation turns from the active position to the next keyframe
        */
        void normalMode();

    private:
        char update();

        std::vector<Frame> frames; // All Frames
        Frame tmpframe,flexibleFrame;  // temp frames
        Frame * position; // Pointer to the momentan frame

        //! Play it or not
        bool play;

        unsigned int frameNum;
        unsigned int numBones;
        float frame_position;
        unsigned int last_update; // Last time we updated

        bool flexible; /* If true, then the action will interpolate to flexibleFrame
                            until it is reached and then stops  */
        std::string Name;

};





#endif // ACTION_H_INCLUDED
