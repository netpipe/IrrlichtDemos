#ifndef FRAME_H
#define FRAME_H


class Frame
{
public:
        Frame(unsigned int Bones=0)  :bones()    { bones.resize(Bones); } // screw this --blub
	//Frame() { pos = 0.0f; }
        Frame(const Frame &frm) { bones = frm.bones; pos=frm.pos; }
        Frame(const Frame *frm) { bones = frm->bones; pos=frm->pos; }


        void setBonenumber(unsigned int Bones)
        {
            bones.resize(Bones);
        }

        Frame linearinterpolate(Frame &frm,float time)
        {
		/*Frame tmp(bones.size());
		  for(unsigned int i=0; i < bones.size(); i++)
		  tmp.bones[i] = bones[i].linearinterpolate(frm.bones[i],time);*/
		// and this --blub
		Frame tmp;
		tmp.bones.resize(bones.size());
		for(unsigned int i = 0; i < bones.size(); ++i)
			tmp.bones[i] = bones[i].linearinterpolate(frm.bones[i], time);
        tmp.pos=pos+time;
		return tmp;

        }
        float pos;
        std::vector<workingBonePos> bones;
};


#endif
