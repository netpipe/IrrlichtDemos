#include "ModelFactory.h"
#include "Action.h"
#include "../Texture/TextureFactory.h"
#include "Mdata.h"
#include "../FileSystem/FileSystem.h"
#include <map>
#include <ctype.h>

#ifndef __powerpc__
#define __powerpc__ false
#endif
#ifndef __BIG_ENDIAN__
#define __BIG_ENDIAN__ false
#endif

using GUI::Console;


ModelFactory::ModelFactory()
{
	models.clear();
}

/*! \brief Loads Model Data
  \return Returns Model ID or -1 on error
  \todo Delete new'ed vars in case of a return -1
*/
int ModelFactory::LoadModel(char * filename)
{
	std::string modelfile;

	// Is this Model already loaded?
	if(ModelData.find(filename) != ModelData.end())
	{ // Yes? Then we only need to create a new Model instance
		models.push_back(Model(ModelData[filename]));
		return models.size()-1;
	}

	modelfile = "./data/Models/";
	modelfile += filename;

	// Inputfile Object
	fileSystem file;
	file.open((char*)modelfile.c_str(),BIN | INP);

	if(!file)
	{
		//valid=false;
		console << Console::warning << Console::lowish << "ModelLoader: Invalid file \"" << filename << "\"" << Console::endl();
		return -1;
	}

	// int size = file.getFilesize();


	// Create File Header Object
	fileHeader header;

	// Read Header from file
	file.read( (char*)&header, sizeof(fileHeader), true);


	// Check for correct file version.
	if(header.version != 4)
	{
		//valid=false;
		console << Console::warning << "ModelLoader: Invalid/wrong header version(" << header.version << ") in file \"" << filename << "\"" << Console::endl();
		return -1;
	}


	ModelData[filename] = new mdata;


	ModelData[filename]->numBones= header.numBones;

	/*  if(header.numBones*sizeof(fileBone) > size)
	    {
	    console << Console::warning << "ModelLoader: Impossible amount of bones: " << header.numBones << ". File is corrupt." << Console::endl();
	    return -1;
	    }
	*/

	// Create an array for the bones
	if(header.numBones > 0)
	{
		try
		{
			ModelData[filename]->bones = new workingBone[header.numBones];
		}
		catch (const std::bad_alloc& )
		{
			console << Console::warning << "ModelLoader: Was not able to allocate " << header.numBones << "bone-instances." << Console::endl();
			//valid=false;
			return -1;
		}


		fileBone *tmpbone = new fileBone;

		// Read all bones
		for(unsigned int i=0;i < header.numBones;i++)
		{
			// Read fileBone struct
			file.read((char*)tmpbone, sizeof(fileBone), true);
			// Put information in workingBone struct
			memcpy(ModelData[filename]->bones[i].children,tmpbone->children,8*sizeof(int));
			ModelData[filename]->bones[i].fLength    = tmpbone->fLength;
			ModelData[filename]->bones[i].nJointType = tmpbone->nJointType;
			ModelData[filename]->bones[i].options    = tmpbone->options;
			ModelData[filename]->bones[i].Parent     = tmpbone->Parent;

			ModelData[filename]->bones[i].rot.W = tmpbone->qRotate[0];
			ModelData[filename]->bones[i].rot.X = tmpbone->qRotate[1];
			ModelData[filename]->bones[i].rot.Y = tmpbone->qRotate[2];
			ModelData[filename]->bones[i].rot.Z = tmpbone->qRotate[3];

			ModelData[filename]->bones[i].loc.X = tmpbone->vOffset[0];
			ModelData[filename]->bones[i].loc.Y = tmpbone->vOffset[1];
			ModelData[filename]->bones[i].loc.Z = tmpbone->vOffset[2];

			ModelData[filename]->bones[i].weight     = tmpbone->weight;

			/*     printf("  nameL = %u\n",tmpbone->nameL);
			       printf("  fLength = %f\n",tmpbone->fLength);
			       printf("  nJointType = %i\n",tmpbone->nJointType);
			       printf("  options = %i\n",tmpbone->options);
			       printf("  Parent = %i\n",tmpbone->Parent); */

			ModelData[filename]->bones[i].name       = new char[tmpbone->nameL];
			// now read the name
			file.read(ModelData[filename]->bones[i].name,tmpbone->nameL,true);

			/*        printf("Name: %s\nqRotate: %f %f %f %f\nvOffset: %f %f %f\n",bones[i].name, bones[i].qRotate[0],
				  bones[i].qRotate[1],
				  bones[i].qRotate[2],
				  bones[i].qRotate[3],
				  bones[i].vOffset[0],
				  bones[i].vOffset[1],
				  bones[i].vOffset[2]);*/

		}
		delete tmpbone;
	}


	// Read the Vertices
	ModelData[filename]->numVerts = header.numVertices;
	if(header.numVertices > 0)
	{
		try
		{
			ModelData[filename]->vertices = new fileVertex[header.numVertices];
		}
		catch (const std::bad_alloc& )
		{
			console << Console::warning << "ModelLoader: Was not able to allocate " << header.numVertices << " Vertex-instances." << Console::endl();
			//valid=false;
			return -1;
		}

		for (unsigned int i =0; i < ModelData[filename]->numVerts;i++)
		{
			file.read((char*) ModelData[filename]->vertices+sizeof(fileVertex)*i,sizeof(fileVertex),true);
			//printf("(%u) : %f %f %f\n",i,vertices[i].vPos[0],vertices[i].vPos[1],vertices[i].vPos[2]);
		}

	}


	// Read the Faces
	ModelData[filename]->numFaces = header.numFaces;
	if(header.numFaces > 0)
	{
		try
		{
			ModelData[filename]->faces = new workingFace[header.numFaces];
		}
		catch (const std::bad_alloc& )
		{
			console << Console::warning << "ModelLoader: Was not able to allocate " << header.numFaces << " face-instances." << Console::endl();
			//valid=false;
			return -1;
		}


		fileFace* tmpface = new fileFace;

		for( unsigned int i=0; i < ModelData[filename]->numFaces;i++)
		{
			file.read((char*) tmpface,sizeof(fileFace),true);
			ModelData[filename]->faces[i].normal = tmpface->normal;
			ModelData[filename]->faces[i].numVertices = tmpface->numVertices;
			ModelData[filename]->faces[i].texId = tmpface->texture;

			// Init place for vertices
			try
			{
				ModelData[filename]->faces[i].vertices = new unsigned int[tmpface->numVertices];
			}
			catch (const std::bad_alloc& )
			{
				console << Console::warning << "ModelLoader: Was not able to allocate " << tmpface->numVertices << " face-vertices-array." << Console::endl();
				//valid=false;
				return -1;
			}
			// read the verts
			file.read((char*) ModelData[filename]->faces[i].vertices,tmpface->numVertices*sizeof(unsigned int),true);


			//  printf("Verts: %u %u %u %u\n",faces[i].vertices[0],faces[i].vertices[1],faces[i].vertices[2],faces[i].vertices[3]);

			// now we read the UV Coordinates
			try
			{
				ModelData[filename]->faces[i].uvcoords = new fileVertex2D[tmpface->numVertices];
			}
			catch (const std::bad_alloc& )
			{
				console << Console::warning << "ModelLoader: Was not able to allocate " << tmpface->numVertices << " face-uvcoords-array." << Console::endl();
				//valid=false;
				delete tmpface;
				return -1;
			}
			file.read((char*) ModelData[filename]->faces[i].uvcoords,sizeof(fileVertex2D)*tmpface->numVertices,true);


			//   for(unsigned int j=0;j<tmpface->numVertices;j++)
			//        printf("UV: %f | %f\n",ModelData[filename]->faces[i].uvcoords[j].vPos[0],ModelData[filename]->faces[i].uvcoords[j].vPos[1]);


			// Search double vertices for debugging
			for(unsigned int ii=0;ii < tmpface->numVertices;ii++)
				for(unsigned int o=0;o < tmpface->numVertices;o++)
					if(ModelData[filename]->faces[i].vertices[ii] == ModelData[filename]->faces[i].vertices[o] && o != ii)
					{
						console << Console::warning << "ModelLoader: Broken Model! Found same vertices in face " << ModelData[filename]->faces[i].vertices[ii] << " in file " << filename << Console::endl();
						return -1;
						break;

					}

		}

		delete tmpface;

	}


	// Read the VertexGroups
	ModelData[filename]->numVGroups = header.numGroups;
	if (header.numGroups > 0)
	{
		fileVertexGroup * tmpgroup = new fileVertexGroup;
		try
		{
			ModelData[filename]->vGroups = new workingVertexGroup[header.numGroups];
		}
		catch (const std::bad_alloc& )
		{
#ifndef NDEBUG
			console << Console::warning << "ModelLoader: Error: Was not able to allocate " << header.numGroups << " VertexGroup-instances." << Console::endl();
#endif
			//valid=false;
			return -1;
		}

		for(unsigned int i =0;i < header.numGroups; i++)
		{
			file.read((char*) tmpgroup, sizeof(fileVertexGroup),true);
			ModelData[filename]->vGroups[i].boneID = tmpgroup->boneID;
			ModelData[filename]->vGroups[i].detailLevel = tmpgroup->detailLevel;
			ModelData[filename]->vGroups[i].vertexL = tmpgroup->vertexL;

			try
			{
				ModelData[filename]->vGroups[i].vertices = new unsigned int[tmpgroup->vertexL];
			}
			catch (const std::bad_alloc& )
			{
#ifndef NDEBUG
				console << Console::warning << "ModelLoader: Error: Was not able to allocate " << tmpgroup->vertexL << "Group-vertices-arrays." << Console::endl();
#endif
				//valid=false;
				return false;
			}

			file.read((char*) ModelData[filename]->vGroups[i].vertices, sizeof(unsigned int)*tmpgroup->vertexL,true);


		}
		delete tmpgroup;
	}

	// Read the Textures
	ModelData[filename]->numTextures  = header.numTextures;
	ModelData[filename]->numTextures = header.numTextures;
	if( header.numTextures > 0)
	{
		try
		{
			ModelData[filename]->texName = new std::string[header.numTextures];
			ModelData[filename]->texID = new unsigned int[header.numTextures];
		}
		catch (const std::bad_alloc& )
		{
#ifndef NDEBUG
			console << Console::warning << "ModelLoader: Error: Was not able to allocate " << header.numTextures << " Texture-names." << Console::endl();
#endif
			//valid=false;
			return -1;
		}

		for(unsigned int i=0;i < header.numTextures;i++)
		{
			unsigned int length=0;
			file.read((char*) &length,sizeof(unsigned int),true);

			if(length <= 0)
				break;

			char * tmp;
			try
			{
				tmp = new char[length+1];
			}
			catch (const std::bad_alloc& )
			{
#ifndef NDEBUG
				console << Console::warning << "ModelLoader: Error: Was not able to allocate " << length+1 << " Texturename-memory for reading." << Console::endl();
#endif
				//valid=false;
				return -1;
			}

			file.read((char*) tmp, sizeof(char)*length, false);
			tmp[length] = '\0';

			ModelData[filename]->texName[i] = tmp;
			int tmpid = texture_factory.loadTexture((std::string)tmp);
			if( tmpid == -1)
			{
#ifndef NDEBUG
				console << Console::warning << "ModelLoader: Could not load texture " << tmp << Console::endl();
#endif
				//return -1;
			}

			ModelData[filename]->texID[i] = tmpid;

			//printf("Texture(%u): %s\n",i,tmp);
			delete [] tmp;
		}

	}


	// Read the Animation-Actions
	std::vector<workingAction> tmp_actions;
	if ( header.numActions > 0 )
	{
		workingAction tmpworkact;
		fileAction tmpaction;
		for(unsigned int i=0;i < header.numActions;i++)
		{
			file.read((char*)&tmpaction, sizeof(fileAction),true);
			try
			{
				tmpworkact.frames = new unsigned int[tmpaction.frameNum];
				tmpworkact.numFrames = tmpaction.frameNum;
				tmpworkact.frame = 0;
				tmpworkact.play = false;
			}
			catch (const std::bad_alloc& )
			{
#ifndef NDEBUG
				console << Console::warning << "ModelLoader: Error: Was not able to allocate " << tmpaction.frameNum << " Frame-indicies ." << Console::endl();
#endif
				//valid=false;
				return false;
			}
			file.read((char*)tmpworkact.frames,sizeof(unsigned int)*tmpaction.frameNum,true);

			tmpworkact.name = new char[tmpaction.name+1];
			file.read(tmpworkact.name,sizeof(char)*tmpaction.name,true);
			tmpworkact.name[tmpaction.name] = '\0';

			tmp_actions.push_back(tmpworkact);
			//printf("Read Action (%u): %s(%u), %u frames.\n",i,actions[i].name,tmpaction.name,tmpaction.frameNum);
			// for(unsigned int j=0;j<tmpaction.frameNum;j++)
			//  printf("  %u\n",actions[i].frames[j]);

		}
	}


	std::vector<Frame> frames;
	// Read the Animation-Frames
	if( header.numFrames > 0)
	{
		Frame tmpworkffrm;//(header.numBones);
		fileFrame tmpfrm;
		for(unsigned int i=0;i < header.numFrames;i++)
		{
			file.read((char*)&tmpfrm,sizeof(fileFrame),true);
			tmpworkffrm.pos = tmpfrm.nr;

//            tmpworkffrm.numBonePositions = tmpfrm.numBonePositions;
			fileBonePos *tmpbpos;
			try
			{
				tmpbpos = new fileBonePos[tmpfrm.numBonePositions];
			}
			catch (const std::bad_alloc& )
			{
#ifndef NDEBUG
				console << Console::warning << "ModelLoader: Was not able to allocate " << tmpfrm.numBonePositions << " BonePos Structs ." << Console::endl();
#endif
				//valid=false;
				return -1;
			}

			file.read((char*)tmpbpos,sizeof(fileBonePos)*tmpfrm.numBonePositions,true);

			for(unsigned int o=0;o < tmpfrm.numBonePositions;o++)
			{
				/*float tmp[4];
				memcpy(tmp,tmpbpos[o].loc,sizeof(float)*3);
				tmpworkffrm.bones[o].loc.X=tmp[0];
				tmpworkffrm.bones[o].loc.Y=tmp[1];
				tmpworkffrm.bones[o].loc.Z=tmp[2];
				memcpy(tmp,tmpbpos[o].rot,sizeof(float)*4);
				tmpworkffrm.bones[o].rot.W=tmp[0];
				tmpworkffrm.bones[o].rot.X=tmp[1];
				tmpworkffrm.bones[o].rot.Y=tmp[2];
				tmpworkffrm.bones[o].rot.Z=tmp[3];*/
				workingBonePos tmp;
				tmp.loc.X = tmpbpos[o].loc[0];
				tmp.loc.Y = tmpbpos[o].loc[1];
				tmp.loc.Z = tmpbpos[o].loc[2];
				tmp.rot.W = tmpbpos[o].rot[0];
				tmp.rot.X = tmpbpos[o].rot[1];
				tmp.rot.Y = tmpbpos[o].rot[2];
				tmp.rot.Z = tmpbpos[o].rot[3];
				tmpworkffrm.bones.push_back(tmp);
			}
			frames.push_back(tmpworkffrm);
		}
	}

	// Convert actions to the Action-Class
	for(unsigned int i=0;i < tmp_actions.size();i++)
	{
		Model::Action newAction(tmp_actions[i].name);
		// Add the frames to the action
		for(unsigned int f=0;f < tmp_actions[i].numFrames;f++)
			if(tmp_actions[i].frames[f] < frames.size() )
				newAction.addKeyFrame(frames[tmp_actions[i].frames[f]]);

		ModelData[filename]->defaultactions.push_back(newAction);
	}

	models.push_back(Model(ModelData[filename]));

#ifndef NDEBUG
	console << Console::normal << Console::lowish << "ModelLoader: Loaded " << filename << Console::endl();
#endif

	file.close();

	return models.size()-1;

}

//! is beeing called from Azadi to update Animations
void ModelFactory::Update()
{
	for(unsigned int i=0;i<models.size();i++)
		models[i].Update();
}

//! Draw all the stuff
void ModelFactory::Draw()
{
	//console << "models.size()" << models.size() << GUI::Console::endl();
	for(unsigned int i=0;i<models.size();i++)
		models[i].Draw();
}

//! Move/Relocate the model
void ModelFactory::Move( unsigned int iD, float x, float y, float z)
{
	if(iD < models.size())
		models[iD].setLoc(x, y, z);
}

void ModelFactory::Rotate(unsigned int iD, float w, float x, float y, float z)
{
	if(iD < models.size())
		models[iD].setRot(w, x, y, z);
}
