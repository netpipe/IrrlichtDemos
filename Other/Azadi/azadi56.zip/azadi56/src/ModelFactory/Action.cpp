#include "Action.h"
#include "../GUI/Console.h"

ModelFactory::Model::Action::Action(std::string name)
{
    name = Name;
    play= false;
    frameNum=last_update=0;
    frame_position=speed = 1.0;
    intervall=100;

}


void ModelFactory::Model::Action::setFrame(unsigned int frm)
{
    frame_position = frm;
}


float ModelFactory::Model::Action::getFramePosition()
{
    return frame_position;
}


void ModelFactory::Model::Action::addKeyFrame(Frame frm)
{
    if(frames.size() == 0)
    {
        frames.push_back(frm);
        return;
    }

    if((frames.end()-1)->pos < frm.pos)
    {
        frames.push_back(frm);
        return;
    }

    for(std::vector<Frame>::iterator it = frames.begin(); it != frames.end();it++)
        if(it->pos > frm.pos)
            frames.insert(it,frm);

}



void ModelFactory::Model::Action::flexibleMode(Frame flex)
{
    flexibleFrame = flex;
    flexible = true;
}



void ModelFactory::Model::Action::flexibleMode(Frame &flex)
{
    flexibleFrame = flex;
    flexible = true;
}



std::string ModelFactory::Model::Action::getName()
{
    return Name;
}





char ModelFactory::Model::Action::update()
{
    if(SDL_GetTicks() - last_update < intervall || // Its not time yet to update positions
    !play || frame_position >= (frames.end()-1)->pos // we are not playing or we ended now
    || frames.size() < 2)  // we got no frames
        return 0;


   // console << "Action-Update was called (pos " << frame_position << " )" << GUI::Console::endl();

    Frame * bg,*sm;

    //! get the frame that we used last time as 'bigger' frame
    std::vector<Frame>::iterator bigger = frames.begin()+frameNum;

    //! check if the needed frame is an existing one
    if(bigger->pos == frame_position) // we don't need to interpolate in this case
    {
         position = &*bigger;
         frameNum++; // Next time we need the next frame
    }else //! its is not, now we interpolate the needed one
    {   //! The position of our frame is smaller then the needed one, so we loop till we get the frame that is higher
        while(bigger->pos < frame_position )
        {
            bigger++;
            frameNum++;
        }
        bg=&*bigger;

        position = &tmpframe; //! we need to interpolate the frame, and it will be written to tmpframe
        std::vector<Frame>::iterator smaller = bigger-1; //! get the next smaller frame

        sm=&*smaller;

   //     float interpolate = bigger->pos  //! get the pos difference between the 2 frames
  //      interpolate = frame_position - smaller->pos;       //! and now get the value that we need to interpolate to

        tmpframe = smaller->linearinterpolate(*bigger,(frame_position - smaller->pos));
    }

    last_update = SDL_GetTicks();
    frame_position+=speed;
    if((frames.end()-1)->pos >= frame_position && loop) // Reached the end? If loop, restart
    {
        frame_position -= (frames.end()-1)->pos;
        frameNum = 0;
    }
    return 1;
}

/*
float Model::Action::linear_interpolation (float frame0,float value0,float frame1,float value1,float frame)
{
    return value0 + ((value1 - value0) / (frame1 - frame0)) * (frame - frame0);
}
*/
