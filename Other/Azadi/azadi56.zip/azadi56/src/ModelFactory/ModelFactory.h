#ifndef MODEL_H_071106
#define MODEL_H_071106

#ifndef __OSX__
#include <GL/gl.h>
#else
#include <OpenGL/gl.h>
#endif

#include "FileStructs.h"
#include <string>
#include <vector>
#include <map>
#include <SDL/SDL.h>
#include "../GUI/Console.h"
#include "../Input/ConsoleListener.h"

class Textures;
/*! \brief Manages Models and Animation

  Takes care of all the Modeldata, also renders and updates the
  animations
*/
class ModelFactory
{
	friend class Model;
	friend class modelListener;
    public:
        class Model;

        ModelFactory();
        /*! \brief Loads Model Data
	  \return Returns Model ID or -1 on error
	*/
        int LoadModel(char * filename);
        //! Draws all the models
        void Draw();
        //! Updates all the models
        void Update(); // Animation Update callback
        //! Moves/Relocates the id'd model to a new position
        void Move(unsigned int iD, float x, float y, float z);
        //! Rotates the id'd model
        void Rotate(unsigned int iD, float w, float x, float y, float z);

        std::vector<Model> models;




private:
        struct mdata;

        //! Data of the Model
        std::map<std::string,mdata*> ModelData;



};

extern ModelFactory model_factory;

// Temporary ModelFactory Lua interface

#endif
