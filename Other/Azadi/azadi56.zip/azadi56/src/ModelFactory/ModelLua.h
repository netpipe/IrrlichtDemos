#include "../Scripting/ScriptEngine.h"
#include "../Azadi.h"
#include "ModelFactory.h"


/** @brief Proxy Class to let lua controll Models
  *
  * This is only for testing , lua will later not access models directly
  */
class ModelLua
{
    public:
        ModelLua(lua_State *L);
        static const char className[];
        static AzLua<ModelLua>::RegType methods[];
        int setLoc(lua_State *L);
        int setRot(lua_State *L);
        int getLoc(lua_State *L);
        int getRot(lua_State *L);


        int play(lua_State *L);
        int stop(lua_State *L);
        int seek(lua_State *L);
        int list(lua_State *L);


        int valid(lua_State *L);
        int drawMesh(lua_State *L);
        int reset(lua_State *L);
        int enable(lua_State *L);
        int disable(lua_State *L);
        int enabled(lua_State *L);

    private:
        int ModelID;



};

