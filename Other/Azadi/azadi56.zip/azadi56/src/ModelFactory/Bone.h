
#include "../matrix.h"
#include "FileStructs.h"


#define MODEL_SPACE true
#define WORLD_SPACE false

class Bone
{
    public:
        Bone();
        vector3<float> getLocation();
        quaternion<float> getRotation();
        void setRotation(quaternion<float> rot,bool space=MODEL_SPACE);
        void addRotation(quaternion<float> rot);
        void setLocation(vector3<float> vec,bool space=MODEL_SPACE);
        void addLocation(vector3<float> vec);
        void setVertices(std::vector<vector3<GLfloat> * > verts);
        void setData(workingBone * data,matrix4<float> * mm);
        void apply();
    private:
        void EditMode();

        matrix4<float> OriginalMatrix;
        matrix4<float> Matrix; //! the bones matrix in ModelSpace (origin at model root)
        matrix4<float> worldMatrix ; //! The bones Matrix in WorldSpace (This is boneMatrix * Matrix_of_Model)

        matrix4<float> * ModelMatrix;

        workingBone * Data; //! Bones init data
        std::vector<vector3<GLfloat> * > Vertices;
        bool fullUpdate; // If set, we need to update the vertice starting from the Original Matrix
        bool EditState; // if we are in editmode or not
};


