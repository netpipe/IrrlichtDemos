#include "ModelLua.h"
#include "../GUI/Console.h"
#include "Action.h"
#include "Model.h"



extern ModelFactory model_factory;
using GUI::Console;

ModelLua::ModelLua(lua_State *L)
{
	const char *file =  lua_checkstring(L, 1);

	ModelID = model_factory.LoadModel((char*) file);

	console << Console::log << Console::highish << "Instantiated a ModelLua Object" << Console::endl();

}



int ModelLua::setLoc(lua_State *L)
{
	model_factory.models[ModelID].setLoc(lua_checknumber(L, 1),
                                             lua_checknumber(L, 2),
					     lua_checknumber(L, 3)) ;

	return 0;

}


int ModelLua::setRot(lua_State *L)
{
	model_factory.models[ModelID].setRot(lua_checknumber(L, 1),
                                             lua_checknumber(L, 2),
					     lua_checknumber(L, 3),
					     lua_checknumber(L, 4) );

	return 0;

}



int ModelLua::valid(lua_State *L)
{

	lua_pushnumber(L, (ModelID < 0) ? 0 : 1 );
	return 1;
}



int ModelLua::drawMesh(lua_State *L)
{
	if( lua_checknumber(L, 1) != 0)
		model_factory.models[ModelID].drawMeshes = true;
	else
		model_factory.models[ModelID].drawMeshes = false;

	return 0;
}



/** @brief getLoc
 *
 * @todo: document this function
 */
int ModelLua::getLoc(lua_State *L)
{
	register float * loc = model_factory.models[ModelID].loc;//.getLoc();
	lua_pushnumber(L, loc[0]);
	lua_pushnumber(L, loc[1]);
	lua_pushnumber(L, loc[2]);
	return 3;
}

/** @brief getRot
 *
 * @todo: document this function
 */
int ModelLua::getRot(lua_State *L)
{
	register float * rot = model_factory.models[ModelID].rot;//.getRot();
	lua_pushnumber(L, rot[0]);
	lua_pushnumber(L, rot[1]);
	lua_pushnumber(L, rot[2]);
	return 3;
}

/** @brief reset
 *
 * @todo: document this function
 */
int ModelLua::reset(lua_State *L)
{
	model_factory.models[ModelID].reset();
	return 0;
}

/** @brief enable
 *
 * @todo: document this function
 */
int ModelLua::enable(lua_State *L)
{
	model_factory.models[ModelID].enabled = true;
	return 0;
}

/** @brief disable
 *
 * @todo: document this function
 */
int ModelLua::disable(lua_State *L)
{
	model_factory.models[ModelID].enabled = false;
	return 0;
}

/** @brief enabled
 *
 * @todo: document this function
 */
int ModelLua::enabled(lua_State *L)
{
	lua_pushnumber(L,(model_factory.models[ModelID].enabled) ? 1 : 0);
	return 1;
}






/** @brief returns the list of animations
 *
 *
 */
int ModelLua::list(lua_State *L)
{
	int i=0;
	for( std::list<ModelFactory::Model::Action>::iterator Iterator = model_factory.models[ModelID].actions.begin(); Iterator != model_factory.models[ModelID].actions.end(); Iterator++ )
	{
		i++;
		lua_pushstring(L, Iterator->getName().c_str());
	}
	return i;
}

/** @brief seek
 *
 * @todo: this needs to be tested
 */
int ModelLua::seek(lua_State *L)
{
	if(model_factory.models[ModelID].actions.size() < lua_checknumber(L, 1))
	{
		std::list<ModelFactory::Model::Action>::iterator Iterator = model_factory.models[ModelID].actions.begin();
		for(int i=0; i < lua_checknumber(L, 1); i++)
			Iterator++;

		(Iterator)->setFrame((int)lua_checknumber(L, 2));
	}
	return 0;
}

/** @brief stop
 *
 * @todo: document this function
 */
int ModelLua::stop(lua_State *L)
{
	model_factory.models[ModelID].stop(model_factory.models[ModelID].getActionPbyID((int)lua_checknumber(L, 1)));
	return 0;
}

/** @brief play
 *
 * @todo: document this function
 */
int ModelLua::play(lua_State *L)
{
	model_factory.models[ModelID].play(model_factory.models[ModelID].getActionPbyID((int)lua_checknumber(L, 1)));
	return 1;
}




const char ModelLua::className[] = "Model";
AzLua<ModelLua>::RegType ModelLua::methods[] = {
	{ "setLoc", &ModelLua::setLoc },
	{ "setRot", &ModelLua::setRot },
	{ "drawMesh", &ModelLua::drawMesh },
	{ "getLoc", &ModelLua::getLoc },
	{ "getRot", &ModelLua::getRot },
	{ "reset", &ModelLua::reset },
	{ "enable", &ModelLua::enable },
	{ "disable", &ModelLua::disable },
	{ "enabled", &ModelLua::enabled },
	{ "stop", &ModelLua::stop },
	{ "play", &ModelLua::play },
	{ "seek", &ModelLua::seek },
	{ "list", &ModelLua::list },
	{ 0, 0 }
};
