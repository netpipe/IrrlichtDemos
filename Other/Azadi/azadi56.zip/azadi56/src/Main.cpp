#include "Azadi.h"
#include "GUI/Console.h"
#include "GUI/GUI.h"
#include "GUI/Menu.h"
#include "Texture/TextureFactory.h"
#include "Sound/SoundFactory.h"
#include "ModelFactory/Model.h"
#include "ModelFactory/Action.h"
#include "ModelFactory/ModelFactory.h"
#include "Scripting/ScriptEngine.h"
#include "Particle/ParticleFactory.h"
#include "Objects/Planet/Planet.h"
#include "Physics/Physics.h"
#include "Fonts/Font.h"
#include "SceneGraph/SceneGraph.h"
#include "Extensions/Extensions.h"
#include <cstdio>

#ifdef __OSX__
	#import <Cocoa/cocoa.h>
#endif

//! Global Console Object for printing Information

Input input;
GUI::Console console;
Layout gui_engine;
ScriptEngine script_engine;
TextureFactory texture_factory;
ParticleFactory particle_factory;
SoundFactory sound_factory;
ModelFactory model_factory;
PlanetFactory planet_factory;
Physics physics_engine;
Font text_engine;
ShaderFactory shader_factory;
MenuFactory menu_factory;
SceneGraph scene_graph;
//Frustum frustum;

Extensions extensions_handler;

#ifdef WIN32
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
    char **tempo;
    tempo = new char*[3];
    *tempo = new char[15];
    strcpy(tempo[0], "-fullscreen");
    #ifndef NDEBUG
    strcpy(tempo[0], "Azadi");
    #endif
    return main(1, tempo);
}
#endif

#ifdef __VISCPP__
int _tmain (int argc, char* argv[])
#else
int main ( int argc, char** argv )
#endif
{
	#ifdef WIN32
	WSADATA wsaData;

	if(WSAStartup(MAKEWORD(1, 1), &wsaData) != 0)
	{
		fprintf(stderr, "WSAStartup failed.\n");
		return 1;
	}

	#endif

    #ifdef __OSX__
	NSApplicationLoad();
    #endif

	debug(std::cout << "debugging enabled" << std::endl << std::flush);

    Azadi game(argc,argv);
    game.Run();

	#ifdef WIN32
	WSACleanup();
	#endif

    return 0;
}




