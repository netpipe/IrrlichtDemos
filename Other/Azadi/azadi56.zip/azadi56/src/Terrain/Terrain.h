#ifndef TERRAIN_H
#define TERRAIN_H

#ifndef __OSX__
	#include <GL/gl.h>
#else
	#include <OpenGL/gl.h>
#endif

#include "../vector.h"
#include "../Camera/Frustum.h"

const int Twidth=7;
const int MTWidth=24;
//const int DTpn=5;

class cTrainP{
	public:
		cTrainP();
		int LOD;
		int x,z; //bottom right start coords
		//int roughness,material;
		float Train[6][6];// extra row for smoothing
		int nLOD[4];
};

class cTerrainDT{
	public:
		int x,y,z;
		cTerrainDT();
		//vector3f<float> Vertex;
		cTrainP Patch[16]; //4x4 tile from of 6x6
};

//cTerrainDT TTile[(MTWidth * MTWidth)];
//cTerrainDT *TTile = new cTerrainDT[100];

class Terrain
{
	public:
		Terrain();  // Constructor
		~Terrain();  // Destructor
		void Initialise();
		float GetHeight(float x,float z);
		void Draw(int x,int z);
		void DrawTerrainT(int LOD,float x,float z,int DTNumber,int patch,int scale);
		void Sphere(int,int);
		unsigned int sphereDL;
		cTerrainDT TTile[2];//103
		friend class Azadi;
	private:
		Frustum *frustum;


};

#endif
