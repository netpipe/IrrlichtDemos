#include "Terrain.h"
#include <math.h>
#include <cstdlib>
#include <iostream>
#include "../vector.h"
#include "./simplexnoise1234.h"
#include "../Texture/TextureFactory.h"
const float piover180 = 0.0174532925f;
int grass;
float az=0;
float ax=0;
int sphereDL;
cTrainP::cTrainP()

{}

cTerrainDT::cTerrainDT()
{}

Terrain::Terrain()
{

    frustum = new Frustum;  //Instantiate the frustum class

}

Terrain::~Terrain()
{}

void Terrain::Initialise()
{
    grass=texture_factory.loadTexture("rust1.png");


    frustum->ExtractFrustum();

    sphereDL = glGenLists(1);

    glNewList(sphereDL, GL_COMPILE);

        glEnable(GL_TEXTURE_2D);
    int scale=25;

        texture_factory.applyTexture(grass); // APPLY GRASS HERE <<<<<<<<<<


    for ( int tilex = 0; tilex < 1*24; tilex+=24)
    {
        for( int tilez = 0; tilez < 1*24; tilez+=24)
        {

            if (frustum->SphereCheck((tilex+12)*scale, 1, (tilez+12)*scale, scale*12))
            {
                for ( int x = 0 ; x < 24; x++)
                {
                    for ( int z=0; z < 24; z++)
                    {
                        {
                            DrawTerrainT(5, (x+tilex)*scale, (z+tilez)*scale, 0, z, scale);
                        }
                    }
                } // end of frustum check
            }
        }
        // 	}//end cpherecheck
    }
    //	glDisable(GL_TEXTURE_2D);
glEndList();
}


// main noise function
float Terrain::GetHeight(float x, float z)
{

    float xpos;
    float zpos;
    int octaves=8;
    float persistance =2.5;
    int scale=5;  // noise scaler, not the same as patch scaler
    float total = 0;


    for(int i=4; i < octaves; i++)
    {
        float frequency = pow(2, i);
        float amplitude = pow(persistance, i);
        total += SimplexNoise1234::noise(((x+ax)/scale)/ frequency, ((z+az)/scale)/ frequency) * amplitude;
    }

    return (total);
};


void Terrain::Draw(int ix,int iz)
{
glCallList(sphereDL);
}



void Terrain::DrawTerrainT(int LOD, float x, float z, int DTNumber, int Dtile, int scale)
{

    float height=GetHeight(x, z);
    //	if (frustum->SphereCheck(x+12,height,z+12,scale)){
    float zp1= z+scale;
    float xp1= x+scale;
    float cco = height/4;



    glBegin(GL_TRIANGLE_STRIP);
    glColor3f(1, cco, 0.5);
    glTexCoord2f(1, 1);
    glVertex3f(xp1, GetHeight((xp1), (zp1)), zp1);
    glTexCoord2f(1, 0);
    glVertex3f(xp1, GetHeight((xp1), z), z);
    glTexCoord2f(0, 1);
    glVertex3f(x, GetHeight(x, (zp1)), zp1 );
    //		glColor3f(cco, cco, cco);
    glTexCoord2f(0, 0);
    glVertex3f(x, height , z );
    glEnd();
    //	glDisable(GL_TEXTURE_2D);


    //}// end of Tile Frustum check
}



void Terrain::Sphere(int dtheta, int dphi)
{

    int n;
    int theta, phi;
    vector3<float> Vertex[4];

 //   sphereDL = glGenLists(1);

 //   glNewList(sphereDL, GL_COMPILE);

    for (theta=-90;theta<=90-dtheta;theta+=dtheta)
    {
        for (phi=0;phi<=360-dphi;phi+=dphi)
        {
            n = 0;
            Vertex[n].X = cos(theta*piover180) * cos(phi*piover180);
            Vertex[n].Y = cos(theta*piover180) * sin(phi*piover180);
            Vertex[n].Z = sin(theta*piover180);
            n++;
            Vertex[n].X = cos((theta+dtheta)*piover180) * cos(phi*piover180);
            Vertex[n].Y = cos((theta+dtheta)*piover180) * sin(phi*piover180);
            Vertex[n].Z = sin((theta+dtheta)*piover180);
            n++;
            Vertex[n].X = cos((theta+dtheta)*piover180) * cos((phi+dphi)*piover180);
            Vertex[n].Y = cos((theta+dtheta)*piover180) * sin((phi+dphi)*piover180);
            Vertex[n].Z = sin((theta+dtheta)*piover180);
            n++;

            if (theta > -90 && theta < 90)
            {
                Vertex[n].X = cos(theta*piover180) * cos((phi+dphi)*piover180);
                Vertex[n].Y = cos(theta*piover180) * sin((phi+dphi)*piover180);
                Vertex[n].Z = sin(theta*piover180);
                n++;
            }


            //
            glColor3f(3, 1, 0);
            //

            glPushMatrix();
            //glTranslatef(222,20,222);
            glScalef(5, 5, 5);
            glPointSize(5);
            glBegin(GL_POINTS);

            for (int i=0; i < 3;i++)
            {
                glVertex3f(Vertex[i].X, Vertex[i].Y, Vertex[i].Z);
            }

            glEnd();
            glPopMatrix();

        }
    }
}

