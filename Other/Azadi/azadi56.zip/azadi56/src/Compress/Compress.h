#ifndef __AZADIARCHIVE_H__
#define __AZADIARCHIVE_H__

#include <string>
#include <zlib.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <cassert>
#include <map>

//! Compression facilities
class Compress
{
	public:
		Compress(const std::string& filename);
		Compress();
		~Compress();
		void SetComment(const std::string& comment);
		void AddData(const std::string&, const std::string&);
		void UpdateArchiveData();
		char * Squish(const char *);
		int Deflate(unsigned char *, int size, int level);
	private:
		std::fstream archive;
		unsigned int pos;
		unsigned int nofiles;
		unsigned int archivesize;
		std::vector<char> buff;
};

//! Decompression facilities
class Decomp
{
	public:
		Decomp(const std::string& filename);
		Decomp();
		~Decomp();
		char * GetComment();
		bool SetFile(const std::string&);
		char * GetData(unsigned int size);
		char * UnSquish(char *buffer);
		int Inflate(unsigned char *, int size);
	private:
		std::fstream archive;
		unsigned int pos;
		unsigned int filesize;
		unsigned int archivesize;
		std::vector<char> buff;
};

#endif
