#include "../../vector.h"

#ifndef __OSX__
	#include <AL/al.h>
#else
	#include <OpenAL/al.h>
#endif

#include "../Ogg/OggFile.h"

//! Class that handles sound sources for OpenAL
class SoundSource
{
	public:
        SoundSource();
		bool setPos(vector3<GLfloat>);
		void update();
		bool isPlaying();
		bool hasFinished();
		double getLength();
		double getCurrentTime();
		void play();
		void stop();
		void attachToSource(OggFile*, unsigned int);
		void setAttenuation(float);
		void setVolume(float);
		void setLooping(bool);
	private:
		float volume;
		bool looping;
		bool has_stopped;
		bool bufferit(ALuint);
		vector3<GLfloat> position;
		unsigned int source;
		OggFile *ogg;
		ALuint buffers[2];
};
