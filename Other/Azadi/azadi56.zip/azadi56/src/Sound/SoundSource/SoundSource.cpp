#include "SoundSource.h"

SoundSource::SoundSource()
{
    has_stopped=true;
}

//! Sets the position of the sound source
bool SoundSource::setPos(vector3<GLfloat> newPosition)
{
    position = newPosition;
    alSource3f(source, AL_POSITION, position.X, position.Y, position.Z);
    return true;
}

bool SoundSource::hasFinished()
{
    if (has_stopped)
        return true;
    else
        return false;
}

double SoundSource::getLength()
{
    return (ogg->getLength());
}

double SoundSource::getCurrentTime()
{
    return (ogg->curTime());
}

//! Buffers the source up
bool SoundSource::bufferit(ALuint buffer)
{
    unsigned int segments = 8192;
    char data[131072];
    int size = 0;
    int section, result;
    
    while (unsigned(size) < (segments * 16))
    {
        #ifdef __powerpc__
        if (ogg->getPosition() >= ogg->samples() - 20)
        {
            if (looping)
                ogg->rewind();
            else
            {
                ogg->rewind();
                stop();
            }
        }
        result = ogg->read(data + size, (segments * 16) -size, 1, 2, 1, &section);
        #else
        if (ogg->getPosition() >= ogg->samples() - 20)
        {
            if(looping)
                ogg->rewind();
            else
            {
                ogg->rewind();
                stop();
            }
        }
        result = ogg->read(data + size, (segments * 16) -size, 0, 2, 1, &section);
        #endif
        
        if (result>0)
            size += result;
        else
            break;
    }
    
    if (size == 0)
        return false;
    
    ogg->bufferthis(&buffer, data, size);
    
    return true;
}

//! Updates the buffer of the sound source
void SoundSource::update()
{
    int done;
    bool active = true;
    
    alGetSourcei(source, AL_BUFFERS_PROCESSED, &done);
    
    while (done--)
    {
        ALuint buffer;
        
        alSourceUnqueueBuffers(source, 1, &buffer);
        
        active = bufferit(buffer);
        
        alSourceQueueBuffers(source, 1, &buffer);
    }
}

//! Checks to see if the sound source is currently playing.
bool SoundSource::isPlaying()
{
    ALenum state;
    
    alGetSourcei(source, AL_SOURCE_STATE, &state);
    
    return (state == AL_PLAYING);
}

//! Starts playing the the sound source's attached buffer
void SoundSource::play()
{
    if (isPlaying())
        return;
    
    if (!bufferit(buffers[0]))
        return;
    
    if (!bufferit(buffers[1]))
        return;
    
    alSourceQueueBuffers(source, 2, buffers);
    alSourcePlay(source);
    has_stopped = false;
}

//! Stops playing the sound source's attached buffer
void SoundSource::stop()
{
    alSourceStop(source);
    has_stopped = true;
}

//! This is self explanitory :)
void SoundSource::attachToSource(OggFile *loadedOgg, unsigned int currentSources)
{
    source = currentSources-1;
    ogg = loadedOgg;
    alGenBuffers(2, buffers);
    alGenSources(1, &source);
    
    alSource3f(source, AL_POSITION, 0.0, 0.0, 0.0);
    alSource3f(source, AL_VELOCITY, 0.0, 0.0, 0.0);
    alSource3f(source, AL_DIRECTION, 0.0, 0.0, 0.0);
    alSourcef(source, AL_PITCH, 1.0);
    alSourcef(source, AL_GAIN, 1.0);
    alSourcef(source, AL_ROLLOFF_FACTOR, 1.0);
}

//! Sets the attenuation of the source
void SoundSource::setAttenuation(float arg)
{
    if (arg < 0.0)
        arg = 0.0;
    alSourcef(source, AL_ROLLOFF_FACTOR, arg);
}

//! Sets the volume of the source
void SoundSource::setVolume(float arg)
{
    if (arg > 1.0)
        arg = 1.0;
    else if (arg < 0.0)
        arg = 0.0;
    
    volume = arg;
    alSourcef(source, AL_GAIN, volume);
}

//! Sets looping on or off
void SoundSource::setLooping(bool loop)
{
    looping = loop;
    if (looping)
        alSourcef(source, AL_LOOPING, AL_TRUE);
    else
        alSourcef(source, AL_LOOPING, AL_FALSE);
}
