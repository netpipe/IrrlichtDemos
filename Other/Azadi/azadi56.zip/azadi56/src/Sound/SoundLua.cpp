#include "SoundFactory.h"

using GUI::Console;

SoundLua::SoundLua(lua_State *L)
{
    SauceID=0;
    #ifndef NDEBUG
    console << Console::log << Console::highish << "Instantiated a SoundLua Object" << Console::endl();
    #endif
}

SoundLua::~SoundLua()
{
    
}

int SoundLua::loadSound(lua_State *L)
{
    #ifndef NDEBUG
    console << Console::normal << "Loading: " << lua_tostring(L, 1) << Console::endl();
    #endif
    SoundID = sound_factory.loadSound(lua_checkstring(L, 1));
    if (SauceID==0)
        SauceID = sound_factory.newSource(); // Adds a new source for this sound
    SourceID = sound_factory.attachSound(SoundID, SauceID);
    SoundName = lua_tostring(L, 1);
    return 1;
}

int SoundLua::unloadSound(lua_State *L)
{
    #ifndef NDEBUG
    console << Console::normal << "Unloading: " << SoundName << Console::endl();
    #endif
    sound_factory.unloadSound(SoundName);
    return 1;
}

int SoundLua::setVolume(lua_State *L)
{
    sound_factory.setSourceVol(SourceID, lua_checknumber(L, 1));
    return 1;
}

int SoundLua::setAtten(lua_State *L)
{
    sound_factory.setSourceAtten(SourceID, lua_checknumber(L, 1));
    return 1;
}

int SoundLua::setLoop(lua_State *L)
{
    if (lua_checknumber(L, 1) == 1)
        sound_factory.setSourceLoop(SourceID, true);
    else
        sound_factory.setSourceLoop(SourceID, false);
    return 1;
}

int SoundLua::stopSound(lua_State *L)
{
    sound_factory.stopSource(SourceID);
    return 1;
}

int SoundLua::hasFinished(lua_State *L)
{
    sound_factory.hasSourceFinished(SourceID);
    return 1;
}

int SoundLua::soundLength(lua_State *L)
{
    lua_pushnumber(L, sound_factory.getLength(SourceID));
    return 1;
}

int SoundLua::soundTime(lua_State *L)
{
    lua_pushnumber(L, sound_factory.getTime(SourceID));
    return 1;
}

int SoundLua::playSound(lua_State *L)
{
    sound_factory.playSource(SourceID);
    return 1;
}

int SoundLua::ID(lua_State *L)
{
    lua_pushnumber(L, SourceID);
    return 1;
}

const char SoundLua::className[] = "Sound";
AzLua<SoundLua>::RegType SoundLua::methods[]=
{
    {"Load", &SoundLua::loadSound},
    {"Unload", &SoundLua::unloadSound},
    {"Volume", &SoundLua::setVolume},
    {"Attenuation", &SoundLua::setAtten},
    {"Loop", &SoundLua::setLoop},
    {"ID", &SoundLua::ID},
    {"Play", &SoundLua::playSound},
    {"Length", &SoundLua::soundLength},
    {"Time", &SoundLua::soundTime},
    {"Finished", &SoundLua::hasFinished},
    {"Stop", &SoundLua::stopSound},
    {0, 0}
};
