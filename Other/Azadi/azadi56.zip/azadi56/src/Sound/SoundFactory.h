#ifndef SOUNDFACTORY_H
#define SOUNDFACTORY_H

#include "../Azadi.h"
#include "../vector.h"
#include "Ogg/OggFile.h"
#include "SoundSource/SoundSource.h"
#include "../Scripting/ScriptEngine.h"
#include "../GUI/Console.h"

//! Global sound factory that facilitates the loading and playing of audio
class SoundFactory
{
	public:
		SoundFactory();
		~SoundFactory();
		void soundNotWorking();
        bool isWorking();
		long loadSound(const std::string&);
		void unloadSound(const std::string&);
		unsigned int newSource();
		long attachSound(unsigned int, unsigned int);	//! Attaches a sound to a source, returns the source ID
		bool playSource(unsigned int);	//! Plays the source ID'd sound
		bool hasSourceFinished(unsigned int); //! Checks if the source has finished playing
		double getLength(unsigned int); //! Returns the length of a song
		double getTime(unsigned int); //! Returns the current playtime of a song
		bool stopSource(unsigned int);	//! Stops the source ID'd sound
		bool moveSound(unsigned int, vector3<GLfloat> );	//! moves the source to a new position
		bool removeSound(unsigned int);	//! detaches the source from the sound
		bool setSourceAtten(unsigned int, float);
		bool setSourceVol(unsigned int, float);
		bool setSourceLoop(unsigned int, bool);
		void tick();	//! This function should be called every cycle, it updates the sound
                        //! Buffers

	private:
		unsigned int sources;
		bool soundIsWorking;
		bool loadOgg(const std::string&);
		void unloadOgg(const std::string&);
		unsigned int counter;
		std::map<std::string,unsigned int> sounds;
		std::map<unsigned int,OggFile> files;
		std::map<unsigned int,SoundSource> soundsources;
		std::map<unsigned int,unsigned int> source;
};

//! Lua interface to the SoundFactory
class SoundLua
{
	public:
		SoundLua(lua_State *L);
		int loadSound(lua_State *L);
		int unloadSound(lua_State *L);
		int setVolume(lua_State *L);
		int setAtten(lua_State *L);
		int setLoop(lua_State *L);
		int playSound(lua_State *L);
		int hasFinished(lua_State *L);
		int soundLength(lua_State *L);
		int soundTime(lua_State *L);
		int stopSound(lua_State *L);
		int ID(lua_State *L);
		~SoundLua();
		static const char className[];
		static AzLua<SoundLua>::RegType methods[];
	private:
		std::string SoundName;
		long SoundID;
		long SourceID;
		unsigned int SauceID;
};

extern SoundFactory sound_factory;

#endif
