#include "SoundFactory.h"

using GUI::Console;

//! SoundFactory constructor
SoundFactory::SoundFactory()
{
    console << Console::normal << Console::high << "Initializing Sound Factory" << Console::endl();
    sources = 0;
    soundIsWorking = true;
}

//! SoundFactory destructor
SoundFactory::~SoundFactory()
{
    unsigned int i;
    for (i=0; i< unsigned(files.size()); i++)
        files[i].close();
}

void SoundFactory::soundNotWorking()
{
    soundIsWorking = false;
}

bool SoundFactory::isWorking()
{
    return soundIsWorking;
}

//! loads an ogg file into the sound factory
bool SoundFactory::loadOgg(const std::string& filename)
{
    unsigned int selector = unsigned(files.size());
    
    if (files[selector].open(filename)<0)
    {
        console << Console::normal << Console::high << "Error loading: " << filename << Console::endl();
        return false;
    }
    
    unsigned int reference = unsigned(sounds.size());
    sounds[filename] = reference;
    
    return true;
}

void SoundFactory::unloadOgg(const std::string& filename)
{
    files[sounds[filename]].close();
    files.erase(sounds[filename]);
    sounds.erase(filename);
}

//! The front end to all the sound loading functions, returns an ID number of the loaded sound
long SoundFactory::loadSound(const std::string& filename)
{
    if (!soundIsWorking || (filename.size() == 0))
        return -1;
    std::string soundname("./data/Sounds/");  // Modify to where the sounds should be
    soundname += filename;
    
    #ifndef NDEBUG
    console << Console::log << Console::highish << "SoundFactory->Loading " << soundname << Console::endl();
    #endif
    
    std::map<std::string, unsigned>::iterator value  = sounds.find(soundname);
    if (value != sounds.end())
    {
        #ifndef NDEBUG
        console << Console::normal << Console::high << soundname << " already loaded" << Console::endl();
        #endif
        return (*value).second;
    }
    //console << Console::normal << Console::high << "Attempting to load: " << soundname << Console::endl();
    if (loadOgg(soundname.c_str()))
    {
        return sounds[soundname];
    }
    else
    {
        #ifndef NDEBUG
        console << Console::normal << Console::high << soundname << " was not loaded" << Console::endl();
        #endif
        return -1;
    }
}

void SoundFactory::unloadSound(const std::string& filename)
{
    if (!soundIsWorking || (filename.size()==0))
        return;
    std::string fileName("./data/Sounds/");
    fileName += filename;
    #ifndef NDEBUG
    console << Console::log << Console::highish << "SoundFactory->Unloading " << fileName << Console::endl();
    #endif
    unloadOgg(fileName);
}

//! Adds a new source to the factory
unsigned int SoundFactory::newSource()
{
    if (!soundIsWorking)
        return 0;
    sources++;
    return sources;
}

//! Attaches a sound and returns the source ID
long SoundFactory::attachSound(unsigned int sndNum, unsigned int sourceID)
{
    if (sndNum <0 || (!soundIsWorking))
        return -1;
    source[sourceID-1] = sndNum;
    soundsources[sourceID-1].attachToSource(&(files[sndNum]), soundsources.size());
    return source[sourceID-1];
}

//! Plays a sound specified by a source ID
bool SoundFactory::playSource(unsigned int sourceNum)
{
    if (sourceNum < 0 || (!soundIsWorking))
        return false;
    soundsources[sourceNum].play();
    return true;
}

bool SoundFactory::hasSourceFinished(unsigned int sourceNum)
{
    if (sourceNum < 0 || (!soundIsWorking))
        return true;
    return soundsources[sourceNum].hasFinished();
}

double SoundFactory::getLength(unsigned int sourceNum)
{
    if (sourceNum < 0 || (!soundIsWorking))
        return 0;
    return soundsources[sourceNum].getLength();
}

double SoundFactory::getTime(unsigned int sourceNum)
{
    if (sourceNum < 0 || (!soundIsWorking))
        return 0;
    return soundsources[sourceNum].getCurrentTime();
}

bool SoundFactory::stopSource(unsigned int sourceNum)
{
    if (sourceNum < 0 || (!soundIsWorking))
        return false;
    soundsources[sourceNum].stop();
    return true;
}

//! Moves the sound to a new
bool SoundFactory::moveSound(unsigned int srcNum, vector3<GLfloat> position)
{
    if (srcNum < 0 || (!soundIsWorking))
        return false;
    soundsources[srcNum].setPos(position);
    return true;
}

//! Removes the sound specified by the ID from the sound factory freeing up the memory in the process - to do
bool SoundFactory::removeSound(unsigned int sndNum)
{
    return true;
}

//! Sets the attenuation of a source designated by srcNum
bool SoundFactory::setSourceAtten(unsigned int srcNum, float attenuation)
{
    if (srcNum < 0 || (!soundIsWorking))
        return false;
    soundsources[srcNum].setAttenuation(attenuation);
    return true;
}

//! Sets the volume of a source designated by srcNum
bool SoundFactory::setSourceVol(unsigned int srcNum, float volume)
{
    if (srcNum < 0 || (!soundIsWorking))
        return false;
    soundsources[srcNum].setVolume(volume);
    return true;
}

//! Set the source looping property
bool SoundFactory::setSourceLoop(unsigned int srcNum, bool looping)
{
    if (srcNum < 0 || (!soundIsWorking))
        return false;
    soundsources[srcNum].setLooping(looping);
    return true;
}

//! Updates the buffers of all the sound sources
void SoundFactory::tick()
{
    if (soundIsWorking)
    {
        unsigned int i;
        for(i=0; i<sources; i++)
        {
            if (soundsources[i].isPlaying())
                soundsources[i].update();
        }
    }
}
