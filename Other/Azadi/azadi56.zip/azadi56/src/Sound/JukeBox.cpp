#include "JukeBox.h"
#include "../Fonts/Font.h"
#include "../Texture/TextureFactory.h"
#include "../Scripting/ScriptEngine.h"
#include "../Sound/SoundFactory.h"

unsigned int JukeBox::soundChannel = 0;

JukeBox::JukeBox()
{
    
}

JukeBox::~JukeBox()
{
    
}

void JukeBox::init(screenTemplate& temp)
{
    show = false;
    defaultFont = temp.jukePanel.font;
    x=temp.jukePanel.x;
    y=temp.jukePanel.y;
    w=temp.jukePanel.w;
    h=temp.jukePanel.h;
    ps1=temp.jukePanel.ps1;
    ps2=temp.jukePanel.ps2;
    ps3=temp.jukePanel.ps3;
    soundChannel = 0;
    playtype=1;
    
    text_engine.loadFont(defaultFont);
    text_engine.genPointSize(defaultFont, ps1);
    text_engine.genPointSize(defaultFont, ps2);
    text_engine.genPointSize(defaultFont, ps3);
    
    textoffsetx=temp.jukePanel.textoffsetx;
    textoffsety=temp.jukePanel.textoffsety;
    playoffsetx=temp.jukePanel.nowPlayingx;
    playoffsety=temp.jukePanel.nowPlayingy;
    playMaxWidth=temp.jukePanel.playMaxWidth;
    textMaxWidth=temp.jukePanel.textMaxWidth;
    fontadvance=13;
    maxvisible=temp.jukePanel.maxVisible;
    visibleOffset=0;
    
    firstStart = true;
    
    volumeOffsetX = (unsigned int)textoffsetx+temp.jukePanel.volumeOffsetx;
    volumeOffsetY = y + temp.jukePanel.volumeOffsety;
    
    texture = texture_factory.loadTexture(temp.jukePanel.texture);
    
    volumeWidth=temp.jukePanel.volumeWidth;
    volumeHeight=temp.jukePanel.volumeHeight;
    
    volumeSlider.setX(volumeOffsetX);
    volumeSlider.setY(volumeOffsetY);
    volumeSlider.setW((int)volumeWidth);
    volumeSlider.setH((int)volumeHeight);
    volumeSlider.reset();
    
    jukelist = glGenLists(1);
    
    glNewList(jukelist, GL_COMPILE);
    texture_factory.applyTexture(texture);
    glPushMatrix();
    glBegin(GL_QUADS);
    {
        glTexCoord2f(0.0f, 1.0f);
        glVertex2f(0.0f, 0.0f);
        glTexCoord2f(1.0, 1.0f);
        glVertex2f((float)w, 0.0f);
        glTexCoord2f(1.0, 0.0);
        glVertex2f((float)w, (float)h);
        glTexCoord2f(0.0f, 0.0);
        glVertex2f(0.0f, (float)h);
    }
    glEnd();
    glPopMatrix();
    glEndList();
    
    volume = 1.0;
}

void JukeBox::setWorkingDir(const std::string& workingDir)
{
    this->workingDir = workingDir;
    dir = opendir(workingDir.c_str());
    if (dir == NULL)
        assert(1==0);
}

void JukeBox::setNowPlaying(const std::string& nowPlaying)
{
    currentTrack = nowPlaying;
}

void JukeBox::update()
{
    struct dirent *de;
    files.clear();
    selectBox.clear();
    std::string temp;
    std::string::size_type val;
    unsigned int iterator=0;
    while (de = readdir(dir))
    {
        temp = de->d_name;
        val = temp.find(".ogg", 0);
        if (val != std::string::npos)
        {
            files.push_back(temp);
            GUI::Button temp;
            selectBox.push_back(temp);
            selectBox[iterator].setX(x + (int)textoffsetx);
            selectBox[iterator].setY(y + (int)textoffsety - fontadvance + (iterator*15));
            selectBox[iterator].setW(250);
            selectBox[iterator].setH(15);
            selectBox[iterator].reset();
            iterator++;
        }
    }
}

void JukeBox::setPlayType(unsigned short type)
{
    playtype=type;
}

void JukeBox::tick(Input& input)
{
    char buff[20];
    if ((sound_factory.hasSourceFinished(soundChannel)) && (files.size()>0) && (sound_factory.isWorking()))
    {
        if (playtype == 1) // Linear
        {
            sprintf(buff, "%f", volume);
            script_engine.dostring("bgmusic:Stop()");
            if (!firstStart)
                script_engine.dostring("bgmusic:Unload()");
            if ((currentTrackNum < files.size()-1) && (!firstStart))
                currentTrackNum++;
            else
            {
                currentTrackNum=0;
                firstStart = false;
            }
            script_engine.dostring((const char*)((std::string)"bgmusic:Load(\"" + ("Music/" + files[currentTrackNum]).c_str() + "\");").c_str());
            script_engine.dostring("bgmusic:Attenuation(0.0)");
            script_engine.dostring((const char*)((std::string)"bgmusic:Volume(" + buff + ");").c_str());
            script_engine.dostring("bgmusic:Loop(0)");
            script_engine.dostring("bgmusic:Play()");
            currentTrack = files[currentTrackNum];
        }
        else if(playtype == 2) // Random
        {
            sprintf(buff, "%f", volume);
            script_engine.dostring("bgmusic:Stop()");
            if (!firstStart)
            {
                script_engine.dostring("bgmusic:Unload()");
                firstStart = false;
            }
            srand(SDL_GetTicks());
            currentTrackNum = (unsigned int)((rand() / ((double)RAND_MAX +1)) * files.size());
            script_engine.dostring((const char*)((std::string)"bgmusic:Load(\"" + ("Music/" + files[currentTrackNum]).c_str() + "\");").c_str());
            script_engine.dostring("bgmusic:Attenuation(0.0)");
            script_engine.dostring((const char*)((std::string)"bgmusic:Volume(" + buff + ");").c_str());
            script_engine.dostring("bgmusic:Loop(0)");
            script_engine.dostring("bgmusic:Play()");
            currentTrack = files[currentTrackNum];
        }
    }
    for (unsigned int i = 0; i < maxvisible && i < selectBox.size(); i++)
    {
        selectBox[visibleOffset+i].parseInput(input);
        if (selectBox[visibleOffset+i].getMouseClick())
        {
            sprintf(buff, "%f", volume);
            script_engine.dostring("bgmusic:Stop()");
            script_engine.dostring("bgmusic:Unload()");
            script_engine.dostring((const char*)((std::string)"bgmusic:Load(\"" + ("Music/" + files[visibleOffset+i]).c_str() + "\");").c_str());
            script_engine.dostring("bgmusic:Attenuation(0.0)");
            script_engine.dostring((const char*)((std::string)"bgmusic:Volume(" + buff + ");").c_str());
            script_engine.dostring("bgmusic:Loop(0)");
            script_engine.dostring("bgmusic:Play()");
            currentTrack = files[visibleOffset+i];
            currentTrackNum = visibleOffset+i;
        }
        if (selectBox.size() > maxvisible)
        {
            if (selectBox[i].getScrollUp())
            {
                if (visibleOffset>0)
                {
                    visibleOffset--;
                    for (unsigned int ii = 0; ii < selectBox.size(); ii++)
                        selectBox[ii].transY(15);
                }
            }
            if (selectBox[i].getScrollDown())
            {
                if (visibleOffset<unsigned(selectBox.size())-maxvisible)
                {
                    visibleOffset++;
                    for (unsigned int ii = 0; ii < selectBox.size(); ii++)
                        selectBox[ii].transY(-15);
                }
            }
        }
    }
    volumeSlider.parseInput(input);
    if (volumeSlider.getMouseClick() || volumeSlider.getMouseDown())
    {
        volume = (float)(volumeSlider.getHitPositionX(input) - volumeOffsetX)  / volumeWidth;
        if (volume > 1.0f)
            volume = 1.0f;
        else if (volume<0.0f)
            volume = 0.0f;
        char buff[20];
        sprintf(buff, "%f", volume);
        script_engine.dostring((const char*)((std::string)"bgmusic:Volume(" + buff + ");").c_str());
    }
    if (files.size()>0)
    {
        unsigned int time = (long)sound_factory.getTime(soundChannel);
        if (time > 60)
        {
            sprintf(buff, "%u", time/60);
            time -= 60 * (time/60);
            playtime=(std::string)buff + ":";
        }
        else
        {
            playtime="0:";
        }
        sprintf(buff, "%u", time);
        playtime += buff;
        time = (long)sound_factory.getLength(soundChannel);
        if (time > 60)
        {
            sprintf(buff, "%u", time/60);
            time -= 60 * (time/60);
            totaltime=(std::string)buff + ":";
        }
        else
        {
            totaltime="0:";
        }
        sprintf(buff, "%u", time);
        totaltime+=buff;
    }
    else
    {
        playtime="0:0";
        totaltime="0:0";
    }
}

void JukeBox::toggleVisible()
{
    show = !show;
}

void JukeBox::setLocation(unsigned int nx, unsigned int ny)
{
    x = nx;
    y = ny;
}

void JukeBox::draw(int sw, int sh)
{
    if (!show)
        return;
    
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0, sw, sh, 0.0, -1.0, 2000);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND);
    glEnable(GL_TEXTURE_2D);
    
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
    glTranslatef(x, y, 0.0f);
    
    glPushMatrix();
    glTranslatef(volumeOffsetX, volumeOffsetY, 0.0f);
    glColor3f(1.0f, 1.0f, 1.0f);
    glDisable(GL_TEXTURE_2D);
    glBegin(GL_QUADS);
    {
        glVertex2f(0.0, 0.0f);
        glVertex2f(volumeWidth * volume, 0.0f);
        glVertex2f(volumeWidth * volume, volumeHeight);
        glVertex2f(0.0f, volumeHeight);
    }
    glEnd();
    glEnable(GL_TEXTURE_2D);
    glPopMatrix();
    
    glColor3f(1.0f, 1.0f, 1.0f);
    texture_factory.applyTexture(texture);
    glCallList(jukelist);
    
    glPushMatrix();
    glTranslatef(playoffsetx, playoffsety, 0.0f);
    glPushMatrix();
    glColor3f(0.6f, 0.8f, 0.6f);
    if(currentTrack.size() > playMaxWidth)
        text_engine.drawText((std::string)"Now Playing : " + currentTrack.substr(0, playMaxWidth-3)+"..." + "\n" +playtime + "/" + totaltime, defaultFont, ps1);
    else
        text_engine.drawText((std::string)"Now Playing : " + currentTrack + "\n" + playtime + "/" + totaltime, defaultFont, ps1);
    glPopMatrix();
    glPopMatrix();
    
    glPushMatrix();
    glTranslatef(textoffsetx, textoffsety, 0.0f);
    glPushMatrix();
    glColor3f(1.0f, 1.0f, 1.0f);
    for (unsigned int i = 0; i < maxvisible && i < files.size(); i++)
    {
        if (files[unsigned(visibleOffset)+i].size() > textMaxWidth)
            text_engine.drawText(files[unsigned(visibleOffset)+i].substr(0, textMaxWidth-3) + "...", defaultFont, ps2);
        else
            text_engine.drawText(files[unsigned(visibleOffset)+i], defaultFont, ps2);
        glTranslatef(0.0f, 15.0f, 0.0);
    }
    glPopMatrix();
    glPopMatrix();
    
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_BLEND);
    glEnable(GL_CULL_FACE);
}
