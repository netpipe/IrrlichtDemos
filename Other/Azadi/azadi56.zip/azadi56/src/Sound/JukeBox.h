#ifndef JUKEBOX_H
#define JUKEBOX_H

#include <string>
#include <vector>
#include <dirent.h>

#include "../GUI/Button.h"
#include "../Input/Input.h"
#include "../XML/XML.h"

#ifndef __OSX__
#include <GL/gl.h>
#else
#include <OpenGL/gl.h>
#endif

class JukeBox
{
    public:
        JukeBox();
        ~JukeBox();
        void init(screenTemplate&);
        void toggleVisible();
        void setWorkingDir(const std::string &workingDir);
        void setNowPlaying(const std::string &filename);
        void setPlayType(unsigned short);
        void update();
        void tick(Input& input);
        void setLocation(unsigned int x, unsigned int y);
        void draw(int sw, int sh);
        static unsigned int soundChannel;
    private:
        unsigned int x;
        unsigned int y;
        unsigned int w;
        unsigned int h;
        float textoffsetx;
        float textoffsety;
        float playoffsetx;
        float playoffsety;
        unsigned int texture;
        unsigned int volumeOffsetX;
        unsigned int volumeOffsetY;
        float volumeWidth;
        float volumeHeight;
        GUI::Button volumeSlider;
        unsigned int maxvisible;
        int visibleOffset;
        unsigned int fontadvance;
        float volume;
        std::vector<std::string> files;
        std::string workingDir;
        DIR *dir;
        std::vector<GUI::Button> selectBox;
        std::string defaultFont;
        unsigned int ps1;
        unsigned int ps2;
        unsigned int ps3;
        unsigned int playMaxWidth;
        unsigned int textMaxWidth;
        std::string currentTrack;
        unsigned int currentTrackNum;
        unsigned short playtype;
        bool firstStart;
        GLint jukelist;
        bool show;
        std::string playtime;
        std::string totaltime;
};

#endif
