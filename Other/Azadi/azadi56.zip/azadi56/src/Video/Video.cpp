#include "Video.h"
#include "../GUI/Console.h"
#include <cassert>
#include <signal.h>
#include "../Azadi.h"

using GUI::Console;

namespace Vid
{
    bool caught_signal=false;

    void signalHandler(int)
    {
        caught_signal=true;
    }
}

using namespace Vid;

Video::Video(const std::string& filename)
{
    firstplay = true;
    videobuf_ready=0;
    videobuf_granulepos=-1;
    videobuf_time=0;
    raw = 0;
    frames=0;

    std::string fileName("./data/Videos/" + filename);

    buffer = new char();
    fs = fopen((char*)fileName.c_str(), "rb");
    ogg_sync_init(&oy);

    // Initialize the theora related structures
    theora_comment_init(&tc);
    theora_info_init(&ti);

    // Initialize the voris related structures
    vorbis_comment_init(&vc);
    vorbis_info_init(&vi);

    stateflag = (fs==NULL);
    theora_p = 0;
    vorbis_p = 0;

    #ifndef NDEBUG
    if (!stateflag)
        console << Console::medium << Console::log << "VideoPlayer->Loading " << fileName << Console::endl();
    #endif

    while (!stateflag)
    {
        int ret;
        ret=Buffer();
        assert(ret>0);

        while(ogg_sync_pageout(&oy, &og) > 0)
        {
            ogg_stream_state test;

            if(!ogg_page_bos(&og))
            {
                queue_page();
                stateflag = true;
                break;
            }

            ogg_stream_init(&test, ogg_page_serialno(&og));
            ogg_stream_pagein(&test, &og);
            ogg_stream_packetout(&test, &op);

            if (!theora_p && theora_decode_header(&ti, &tc, &op) >= 0)
            {
                memcpy(&to, &test, sizeof(test));
                theora_p = 1;
            }
            else if (!vorbis_p && vorbis_synthesis_headerin(&vi, &vc, &op) >= 0)
            {
                memcpy(&vo, &test, sizeof(test));
                vorbis_p = 1;
            }
            else
            {
                ogg_stream_clear(&test);
            }
        }
    }

    while ((theora_p && theora_p < 3) || (vorbis_p && vorbis_p < 3))
    {
        int ret;

        while(theora_p && (theora_p<3) && (ret=ogg_stream_packetout(&to, &op)))
        {
            assert(ret>=0);
            if (theora_decode_header(&ti, &tc, &op))
                assert(1==0);
            theora_p++;
            if (theora_p == 3) break;
        }

        while(vorbis_p && (vorbis_p<3) && (ret=ogg_stream_packetout(&vo, &op)))
        {
            assert(ret>=0);
            if (vorbis_synthesis_headerin(&vi, &vc, &op))
                assert(1==0);
            vorbis_p++;
            if (vorbis_p == 3) break;
        }

        if (ogg_sync_pageout(&oy, &og) > 0)
            queue_page();
        else
        {
            ret = Buffer();
            assert(ret>0);
        }
    }

    if (theora_p)
    {
        theora_decode_init(&td, &ti);
    }
    else
    {
        theora_info_clear(&ti);
        theora_comment_clear(&tc);
    }

    if (vorbis_p)
    {
        vorbis_synthesis_init(&vd, &vi);
        vorbis_block_init(&vd, &vb);
    }
    else
    {
        vorbis_info_clear(&vi);
        vorbis_comment_clear(&vc);
    }
}

Video::~Video()
{
    if (fs!=NULL)
        fclose(fs);
}

void Video::queue_page()
{
    if (theora_p) ogg_stream_pagein(&to, &og);
    if (vorbis_p) ogg_stream_pagein(&vo, &og);
}

void Video::Play()
{
    stateflag = false;

    while (ogg_sync_pageout(&oy, &og))
    {
        queue_page();
    }

    signal(SIGINT, signalHandler);

    while (!caught_signal && theora_p)
    {
        while (theora_p && !videobuf_ready)
        {
            if (ogg_stream_packetout(&to, &op)>0)
            {
                theora_decode_packetin(&td, &op);
                videobuf_granulepos = td.granulepos;
                videobuf_time = theora_granule_time(&td, videobuf_granulepos);
                videobuf_ready = true;
                frames++;
            }
            else
                break;
        }

        if (!videobuf_ready && feof(fs))
            break;

        if (!videobuf_ready)
        {
            Buffer();
            while (ogg_sync_pageout(&oy, &og)>0)
            {
                queue_page();
            }
        }
        else
            DrawVideo(20, 20);

        videobuf_ready=false;
    }

    fclose(fs);
}

void Video::DrawVideo(int x, int y)
{
    unsigned int i, ii;
    yuv_buffer yuv;
    theora_decode_YUVout(&td, &yuv);
    GLubyte *buffer = new GLubyte[3*yuv.y_width*yuv.y_height];

    for (i = 0; i < unsigned(yuv.y_height); ++i)
    {
        for (ii = 0 ; ii < unsigned(yuv.y_width*3); ii+=3)
        {
            buffer[(ii)+(yuv.y_width*i)] = (int)   ((1.164 * (yuv.y[(i+1)*ii]-16)) + (1.596*(yuv.v[((i+1)*ii)]-128)));
            buffer[(ii+1)+(yuv.y_width*i)] = (int) ((1.164 * (yuv.y[(i+1)*ii]-16)) - (0.813*(yuv.v[((i+1)*ii)]-128)) - (0.391*(yuv.u[((i+1)*11)]-128)));
            buffer[(ii+2)+(yuv.y_width*i)] = (int) ((1.164 * (yuv.y[(i+1)*ii]-16)) + (2.018*(yuv.u[((i+1)*ii)]-128)));
        }
    }

    if (firstplay)
    {
        firstplay = false;
        glGenTextures(1, &texId);
        glBindTexture(GL_TEXTURE_2D, texId);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, yuv.y_width, yuv.y_height, 0, GL_RGB, GL_UNSIGNED_BYTE, buffer);
    }
    else
    {
        glBindTexture(GL_TEXTURE_2D, texId);
        glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, yuv.y_width, yuv.y_height, GL_RGB, GL_UNSIGNED_BYTE, buffer);
    }

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0f, Azadi::screen[0], Azadi::screen[1], 0.0f, -1.0, 1.0f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glDisable(GL_CULL_FACE);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glColor3f(1.0f, 1.0f, 1.0f);
    glBindTexture(GL_TEXTURE_2D, texId);
    glBegin(GL_QUADS);
    {
        glTexCoord2f(0.0f, 0.0f);
        glVertex3f(0.0f, 0.0f, 0.0f);
        glTexCoord2f(1.0f, 0.0f);
        glVertex3f(Azadi::screen[0], 0.0f, 0.0f);
        glTexCoord2f(1.0f, 1.0f);
        glVertex3f(Azadi::screen[0], Azadi::screen[1], 0.0f);
        glTexCoord2f(0.0f, 1.0f);
        glVertex3f(0.0f, Azadi::screen[1], 0.0f);
    }
    glEnd();

    SDL_GL_SwapBuffers();

    glEnable(GL_CULL_FACE);

    delete [] buffer;
}

int Video::Buffer()
{
    int done;
    char *buffer=ogg_sync_buffer(&oy, 4096);
    done = fread(buffer, 1, 4096, fs);
    ogg_sync_wrote(&oy, done);
    return done;
}

/*
 YUV to RGB

 B = 1.164(Y - 16)                   + 2.018(U - 128)

 G = 1.164(Y - 16) - 0.813(V - 128) - 0.391(U - 128)

 R = 1.164(Y - 16) + 1.596(V - 128)

 */
