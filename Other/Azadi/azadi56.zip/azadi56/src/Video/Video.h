#ifndef VIDEO_H
#define VIDEO_H


#include <string>
#include <theora/theora.h>
#include <vorbis/vorbisfile.h>
#include <ogg/ogg.h>
#include "../FileSystem/FileSystem.h"
#include "../GUI/Drawing.h"
#include <GL/gl.h>

class Video
{
	public:
		Video(const std::string&);
		~Video();
		void Play();
	private:
        inline void queue_page();
        int Buffer();
        void DrawVideo(int x, int y);

		// Ogg stream information
		ogg_sync_state oy;
		ogg_page og;
		ogg_packet op;
		ogg_stream_state vo;
		ogg_stream_state to;
		theora_info ti;
		theora_comment tc;
		theora_state td;
		vorbis_info vi;
		vorbis_dsp_state vd;
		vorbis_block vb;
		vorbis_comment vc;

		int theora_p;
		int vorbis_p;
		bool stateflag;

		FILE *fs;
		char *buffer;
		yuv_buffer yuvbuff;

        int videobuf_ready;
        ogg_int64_t videobuf_granulepos;
        double videobuf_time;
        int raw;
		int frames;

		bool firstplay;
		GLuint texId;
};

#endif
