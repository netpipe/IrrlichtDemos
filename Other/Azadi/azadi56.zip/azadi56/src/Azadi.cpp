#include "Azadi.h"
#include "Terrain/Terrain.h"
#include "ModelFactory/ModelFactory.h"
#include "GUI/Drawing.h"
#include "frustum.h"
#include "Physics/Physics.h"
#include "matrix.h"

#include <SDL/SDL.h>
#include <unistd.h>

#ifndef __OSX__
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glext.h>
#else
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <OpenGL/glext.h>
#endif

extern Input input;

bool Azadi::postprocessing = false;
bool Azadi::constrainedAxis[3];
bool Azadi::view2d = false;
float Azadi::ix = 0;
float Azadi::iy = 0;
float Azadi::movespeed =20;
int Azadi::movementAxis[3] =
{0, 1, 2};
JukeBox Azadi::jukebox;
std::vector<std::string> Azadi::ppShaders;
std::vector<std::string> Azadi::dpShaders;
unsigned int Azadi::postProgram = 0;
unsigned int Azadi::defaultProgram = 0;
int Azadi::screen[2];
Terrain TP;
Client Azadi::client;
std::string Azadi::playerName = "NoName";


float xx=0;
float zz=0;



GLdouble projection_matrix[16]=
{1, 0, 0, 0,
 0, 1, 0, 0,
 0, 0, 1, 0,
 0, 0, 0, 1};

 GLdouble modelview_matrix[16]=
 {1, 0, 0, 0,
  0, 1, 0, 0,
  0, 0, 1, 0,
  0, 0, 0, 1};
  GLint viewport_matrix[4];

  Azadi::Azadi(int argc, char** argv)
  {
      screen[0]=1024, screen[1]=768;

      fullScreen = false;
      withAudio = true;

      parseParameters(argc, argv);

      playerVect = new char[sizeof(GLfloat)*3];
      rate = 50;
  }

  Azadi::~Azadi()
  {
      SDL_Quit();
  }

  void Azadi::Delay(unsigned int x)
  {
      #ifndef WIN32
      usleep(x);
      #else
      Sleep(x);
      #endif
  }

  void Azadi::parseParameters(int argc, char** argv)
  {
      for (int i = 0; i< argc; i++)
      {
          if (strcmp(argv[i], "-fullscreen") == 0)
              fullScreen = true;
          else if (strcmp(argv[i], "-window") == 0)
              fullScreen = false;
          else if (strcmp(argv[i], "-nosound") == 0)
              withAudio = false;
          else if (strcmp(argv[i], "-withsound") == 0)
              withAudio = true;
          /*	else if (strcmp(argv[i], "w=",2) == 0)
           strtol(argv[i]+2,&screen[0];*/
      }
  }

  bool Azadi::Init()
  {

      console << GUI::Console::log << GUI::Console::medium << "Initialising Azadi Engine" << " " << AZADIVERSION << " " << BUILD << GUI::Console::endl();

      GLfloat fogColor[4]=
      {0.0, 0.0, 0.0, 1.0};

      if ( SDL_Init( SDL_INIT_VIDEO ) < 0 )
      {
          printf( "Unable to init SDL: %s\n", SDL_GetError() );
          return false;
      }

      //atexit(SDL_Quit);

      SDL_WM_SetCaption("Azadi", "azadi.bmp");
      SDL_EnableUNICODE(1);
      SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL);
      //SDL_SetModState(KMOD_NUM,false);
      SDL_ShowCursor(SDL_DISABLE);



      SDL_GL_SetAttribute( SDL_GL_RED_SIZE, 5 );
      SDL_GL_SetAttribute( SDL_GL_GREEN_SIZE, 5 );
      SDL_GL_SetAttribute( SDL_GL_BLUE_SIZE, 5 );
      SDL_GL_SetAttribute( SDL_GL_DEPTH_SIZE, 16 );
      SDL_GL_SetAttribute( SDL_GL_DOUBLEBUFFER, 1 );


      center[0]=screen[0]/2;
      center[1]=screen[1]/2;

      CamPos[0]=0.0f;
      CamPos[1]=0.0f;
      CamPos[2]=0.0f;

      MoveKey[0]=false;
      MoveKey[1]=false;
      MoveKey[2]=false;
      MoveKey[3]=false;


      // Register the key listeners
      input.registerKeyListener("forward", SDLK_w, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("backward", SDLK_s, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("left", SDLK_a, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("right", SDLK_d, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("quit", SDLK_ESCAPE, this, MOD_NONE|KMOD_NUM, 0, true);
      input.registerKeyListener("exit", SDLK_ESCAPE, this, MOD_NONE, 0, true);
      input.registerKeyListener("space", SDLK_SPACE, this, MOD_NONE|KMOD_NUM);
      input.registerOverrideKeyListener("exit", SDLK_ESCAPE, this);
      input.registerKeyListener("q", SDLK_q, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("e", SDLK_e, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("r", SDLK_r, this, MOD_NONE|KMOD_NUM);
      //input.registerKeyListener("t", SDLK_t, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("y", SDLK_y, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("u", SDLK_u, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("i", SDLK_i, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("o", SDLK_o, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("p", SDLK_p, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("f", SDLK_f, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("g", SDLK_g, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("h", SDLK_h, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("j", SDLK_j, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("k", SDLK_k, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("l", SDLK_l, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("z", SDLK_z, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("x", SDLK_x, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("c", SDLK_c, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("v", SDLK_v, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("b", SDLK_b, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("n", SDLK_n, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("m", SDLK_m, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("1", SDLK_1, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("2", SDLK_2, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("3", SDLK_3, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("4", SDLK_4, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("5", SDLK_5, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("6", SDLK_6, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("7", SDLK_7, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("8", SDLK_8, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("9", SDLK_9, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("0", SDLK_0, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("F1", SDLK_F1, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("F2", SDLK_F2, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("F3", SDLK_F3, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("F4", SDLK_F4, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("F5", SDLK_F5, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("F6", SDLK_F6, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("F7", SDLK_F7, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("F8", SDLK_F8, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("F9", SDLK_F9, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("F10", SDLK_F10, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("F11", SDLK_F11, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("F12", SDLK_F12, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("F13", SDLK_F13, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("F14", SDLK_F14, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("F15", SDLK_F15, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("KP0", SDLK_KP0, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("KP1", SDLK_KP1, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("KP2", SDLK_KP2, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("KP3", SDLK_KP3, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("KP4", SDLK_KP4, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("KP5", SDLK_KP5, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("KP6", SDLK_KP6, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("KP7", SDLK_KP7, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("KP8", SDLK_KP8, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("KP9", SDLK_KP9, this, MOD_NONE|KMOD_NUM);
      input.registerKeyListener("enter", SDLK_RETURN, this, MOD_NONE|KMOD_NUM);

      #ifndef NDEBUG
      console << GUI::Console::medium << GUI::Console::normal << "Initialising Screen" << GUI::Console::endl();
      #endif
      // create a new window
      if (!fullScreen)
          window = SDL_SetVideoMode(screen[0], screen[1], 24,
          SDL_OPENGL);
      else
          window = SDL_SetVideoMode(screen[0], screen[1], 24,
          SDL_OPENGL | SDL_FULLSCREEN);

      if ( !window )
      {
          printf("Unable to set %ix%i video: %s\n", screen[0], screen[1], SDL_GetError());
          return false;
      }

      // Clears the garbage from the screen straight away
      glClearColor(0.0, 0.0, 0.0, 0.0);
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      SDL_GL_SwapBuffers();

      // Nice Colorflow
      glShadeModel(GL_SMOOTH);

      glEnable(GL_DEPTH_TEST);
      // Enable texturing
      glEnable(GL_TEXTURE_2D);

      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

      // Registers the GLSlang shader context
      ShaderContext context;

      // Enable GL FOG, lets us increase the speed of the rendering by having gl not render beyond a certain distance
      // It also eliminates the visible clipping that can be seen when we go further than what our gluPerspective can give us
      #ifndef NDEBUG
      console << GUI::Console::normal << GUI::Console::highish << "Initialising Fog" << GUI::Console::endl();
      #endif

      glEnable(GL_FOG);

      glFogf(GL_FOG_MODE, GL_EXP2);
      glFogfv(GL_FOG_COLOR, fogColor);
      glFogf(GL_FOG_DENSITY, 0.001);
      glHint(GL_FOG_HINT, GL_FASTEST);
      glFogf(GL_FOG_START, 900.0);
      glFogf(GL_FOG_END, 1000.0);


      //------------------------------------------------------------ Culling

      glViewport(0, 0, (GLsizei) screen[0], (GLsizei) screen[1]);

      drawing = new Drawing();
      console.initTextures();


      // Set up the audio subsystem
      if (!(withAudio) || !(soundDevice = alcOpenDevice(NULL)))
      {
          soundDeviceWorking = false;
          sound_factory.soundNotWorking();
          console << GUI::Console::log << GUI::Console::medium << "Could not open the default sound device" << GUI::Console::endl();
      }
      else
      {
          soundDeviceWorking = true;
          soundContext = alcCreateContext(soundDevice, NULL);
          alcMakeContextCurrent(soundContext);
          console << GUI::Console::log << GUI::Console::medium << "Using default sound device : " << alcGetString(soundDevice, ALC_DEFAULT_DEVICE_SPECIFIER) << GUI::Console::endl();
      }

      glEnable(GL_CULL_FACE);
      glCullFace(GL_BACK);

      // Set the default sensitivity
      msensitivity=5;

      // Generates a texture for post processing
      glGenTextures(1, &posttext);

      firstset=true;

      view2d=false;

      extensions_handler.Init();
      TP.Initialise();

      // Generate the session id
      #ifndef WIN32
      usleep(30000);
      #else
      Sleep(300);
      #endif
      srand(SDL_GetTicks());
      sessionId = rand();
      return true;
  }

  int Azadi::Lobby()
  {
      script_engine.dostring("HumanLobbyFunc()");
      SDL_ShowCursor(SDL_ENABLE);
      Menu mainMenu(700, 190, 300, 400, "MainMenu.png");
      mainMenu.setPadding(90, 50, 15);
      mainMenu.setButtonDimensions(200, 40);
      mainMenu.addButton("Continue.png");
      mainMenu.addButton("Exit-Game.png");

      GLfloat mat_specular[] =
      { 1.0, 1.0, 1.0, 1.0 }; GLfloat mat_shininess[] =
      { 90.0 };
      GLfloat light_position[] =
      {1.5, 1.5 , 1.0, 0};

      glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, 5.0);
      glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, 2.0);
      glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, 1.5);

      glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
      glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
      glLightfv(GL_LIGHT0, GL_POSITION, light_position);

      glEnable(GL_LIGHT0);

      int ret= -1;
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
      while (ret==-1)
      {
          glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
          input.get();
          glMatrixMode(GL_PROJECTION);
          glLoadIdentity();
          glFrustum(-1.0, 1.0, -1.0, 1.0, 1.0, 2000.0);
          glMatrixMode(GL_MODELVIEW);
          glLoadIdentity();
          glColor3f(1.0, 1.0, 1.0);
          glEnable(GL_CULL_FACE);
          glEnable(GL_TEXTURE_2D);
          glEnable(GL_BLEND);
          glEnable(GL_LIGHTING);
          model_factory.Draw();
          glDisable(GL_LIGHTING);
          glMatrixMode(GL_PROJECTION);
          glLoadIdentity();
          glOrtho(0.0, screen[0], screen[1], 0, -1.0, 2000.0);
          glMatrixMode(GL_MODELVIEW);
          glLoadIdentity();
          glDisable(GL_CULL_FACE);
          mainMenu.draw();
          glDisable(GL_BLEND);
          glDisable(GL_TEXTURE_2D);
          glEnable(GL_CULL_FACE);
          ret = mainMenu.tick();
          Drawing::flipBuffers();
          input.flushMouseButtons();
          Azadi::Delay(15);
      }
      script_engine.dostring("HumanLobbyReorient()");
      return ret;
  }

  int Azadi::Run()
  {

      if(!Init())
      {
          console << GUI::Console::error << GUI::Console::high << "Azadi engine initialisation failed" << GUI::Console::endl();
          return 1;
      }

      console << GUI::Console::log << GUI::Console::highish << "Azadi engine initialisation finished" << GUI::Console::endl();

      // Loads the main azadi script file
      script_engine.runfile("main.azs");

      // The following code is necessary otherwise the distance of wherever the mouse was
      // to the center of the screen gets accounted for in the rotations later on.
      // Which means sometimes we end up up-side-down
      SDL_WarpMouse(center[0], center[1]);

      script_engine.dostring("intro()");	// Scripted intro
      if (script_engine.returnedInt() != 0)
          return -1;

      Video intro("test.ogg");
      //intro.Play();

      int ret;
      bool resuming = false;
      bool done = false;
      while (!done)
      {
          ret = Lobby();
          switch (ret)
          {
              case 1:
                  done = true;
                  break;
              case 0:
                  ResetState();
                  Mainloop();
                  resuming=true;
                  break;
                  // Add more cases
          }
      }

      console << GUI::Console::low << GUI::Console::normal << "Closing engine" << GUI::Console::endl();

      #ifndef NDEBUG
      console << Drawing::getFrame() << " frames in " << SDL_GetTicks()/1000.0 << " seconds" << GUI::Console::endl();
      console << "Average framerate: " << 1000.0*Drawing::getFrame()/SDL_GetTicks() << GUI::Console::endl();
      #endif

      return 0;
  }

  void Azadi::ResetState()
  {
      CamPos[0]=0.0f;
      CamPos[1]=0.0f;
      CamPos[2]=0.0f;
  }

  void Azadi::ResizeScreen(unsigned int x, unsigned int y)
  {

  }

  int Azadi::Mainloop()
  {
      SDL_ShowCursor(SDL_DISABLE);
      //! Connect to the master server
    //  client.Connect();

      //! Initialize things using the scripting engine
      script_engine.dostring("init()");
      if (script_engine.returnedInt() != 0)
          return -1;

      //! Parse the layout XML
      XMLParser xml("cosmos.xml");
      //! Obtains the screen resolution template from the xml file
      screenTemp = xml.GetTemplate(screen[0], screen[1]);
      //! Loads the template into the gui engine
      gui_engine.loadTemplate(screenTemp);

      //! Initialize the juke box
      jukebox.init(screenTemp);
      jukebox.setWorkingDir("./data/Sounds/Music");
      jukebox.setLocation(0, 0);

      //! Updates the file list for the jukebox
      jukebox.update();

      //! Program main loop
      done = false;
      selecting=false;
      dispatching=false;

      unsigned int lastupdate=0;
      unsigned int intervall=30;

      unsigned int lastPulse=0;
      unsigned int pulseInterval=2000;

      // Move the mouse to the center one more time
      SDL_WarpMouse(center[0], center[1]);

      // flush the input queue
      input.get();
      input.flush();

      while (!done)
      {
          script_engine.dostring("main()");
          ProcessMessages();
          if (!view2d && !selecting)
          {
              if(SDL_GetTicks() - lastupdate >= intervall)
              {                // Center Mouse after each movment
                  if (selecting == false)
                      SDL_WarpMouse(center[0], center[1]);
                  lastupdate=SDL_GetTicks();
              }
          }
          jukebox.tick(input);
          model_factory.Update();
          sound_factory.tick();  // Updates the sounds :D
          particle_factory.tick();
          physics_engine.tick(Drawing::fps);
          Draw();
          Azadi::Delay(1);
          HandleGameData();
          if (SDL_GetTicks() - lastPulse >= pulseInterval)
          {
              client.Pushdata(HEART, "badump");
              lastPulse = SDL_GetTicks();
          }
      }

      script_engine.dostring("bgmusic:Stop()");
      script_engine.dostring("bgmusic:Unload()");

      input.get();
      input.flush();

      client.Pushdata(CHAT, (playerName + " disconnected").c_str());

      char disc=64;
      client.Pushdata(HEART, &disc);

      client.Disconnect();

      return 0;
  }

  void Azadi::HandleGameData()
  {
      char *buffer = new char[1024];
      char *newBuff = new char[512];
      memset(buffer, 0, 1024);
      unsigned int rounds = 0;
      const int maxRounds = 100;
      unsigned int counter = 0;
      char type=0;
      int ret;
      while ((ret = client.Receivedata(GAME, buffer)) && rounds < maxRounds)
      {
          printf("Received %d bytes\n", ret);
          char *p;
          float x, y, z;
          unsigned int sessiond;
          memset(newBuff, 0, 512);
          type = buffer[0];
          if (type == 1)
          {
              p = buffer;
              int nameSize;
              p++;
              nameSize = p[0];
              p++;
              strscpy(newBuff, p, 0, nameSize);
              p+=nameSize;
              convert((void*)&sessiond, p, sizeof(unsigned int));
              p+=sizeof(unsigned int);
              convert((void*)&x, p, sizeof(float));
              p+=sizeof(float);
              convert((void*)&y, p, sizeof(float));
              p+=sizeof(float);
              convert((void*)&z, p, sizeof(float));
              printf("s: %d : %f - %f - %f\n\n", sessiond, x, y, z);
          }

          rounds++;
      }
      delete [] buffer;
  }

  void Azadi::drawCursor(vector3<GLfloat> forward, float ix, float iy)
  {

      GLfloat cursPos[3];
      GLfloat test[3];

      cursPos[0] = origPos[0];
      cursPos[1] = origPos[1];
      cursPos[2] = origPos[2];

      cursPos[0] += forward.X * (-cursorPos);
      cursPos[1] += forward.Y * (-cursorPos);
      cursPos[2] += forward.Z * (-cursorPos);

      test[0] = - ( cursPos[2]);
      test[1] = 0;
      test[2] = (cursPos[0] * 1);

      glTranslatef(CamPos[0], CamPos[1], CamPos[2]);
      glPushMatrix();
      glTranslatef(cursPos[0], cursPos[1], cursPos[2]);

      glColor3f(1.0, 1.0, 1.0);
      glBegin(GL_LINES);
      {
          glVertex3f(cursPos[0], cursPos[1], cursPos[2]);
          glVertex3f(-3.0, 0.0, 0.0);
          glVertex3f(0.0, 0.0, 0.0);
          glVertex3f(0.0, 3.0, 0.0);
          glVertex3f(0.0, 0.0, 0.0);
          glVertex3f(0.0, 0.0, 1.0);
      }
      glEnd();

      glPopMatrix();

      glLoadIdentity();
      glRotatef(iy, 1.0, 0.0, 0.0);
      glRotatef(ix, 0.0, 1.0, 0.0);

      glTranslatef(-cursPos[0], -cursPos[1], -cursPos[2]);

      glPushMatrix();
  }

  bool Azadi::Draw()
  {
      if (view2d)
          SDL_ShowCursor(SDL_ENABLE);
      else if (!selecting && !dispatching)
          SDL_ShowCursor(SDL_DISABLE);

      // Variable declarations should be at the beginning of the function
      GLfloat mat_specular[] =
      { 1.0, 1.0, 1.0, 1.0 }; GLfloat mat_shininess[] =
      { 90.0 };
      GLfloat light_position[] =
      {1.5, 1.5 , 1.0, 0};

      //! Setup Cam

      // Stores the current frames per second
      float fps;

      vector3<GLfloat> forward;
      vector3<GLfloat> side;

      float Xangle, Yangle;

      //glFrustum (-1.0, 1.0, -1.0, 1.0, 1.5, 20.0);
      //glFrustum(0,width,0,height,1.0,1.0);
      //glFrustum( GLdouble left, GLdouble right, GLdouble bottom, GLdouble top, GLdouble near, GLdouble far )

      //Keep the angles small
      while(iy>360)
          iy-=360;

      while(iy<0)
          iy+=360;

      while(ix>360)
          ix-=360;

      while(ix<0)
          ix+=360;


      Xangle = iy*piover180;
      Yangle = ix*piover180;

      forward.Y = -sin(Xangle);
      forward.X = cos(Xangle)*sin(Yangle);
      forward.Z = cos(Xangle)*-cos(Yangle);

      forward.Normalize();

      side=forward.normcrossprod(vector3<GLfloat> (0.0f, 1.0f, 0.0f));

      if (view2d)
      {
          forward = forward.normcrossprod(-side);
      }

      fps = Drawing::fps + 1;

      if(MoveKey[FORWARD])
      {
          CamPos[movementAxis[0]]-=(forward.X*(constrainedAxis[0]?0:movespeed))/fps;
          CamPos[movementAxis[1]]-=(forward.Y*(constrainedAxis[1]?0:movespeed))/fps;
          CamPos[movementAxis[2]]-=(forward.Z*(constrainedAxis[2]?0:movespeed))/fps;
      }
      if(MoveKey[BACKWARD])
      {
          CamPos[movementAxis[0]]+=(forward.X*(constrainedAxis[0]?0:movespeed))/fps;
          CamPos[movementAxis[1]]+=(forward.Y*(constrainedAxis[1]?0:movespeed))/fps;
          CamPos[movementAxis[2]]+=(forward.Z*(constrainedAxis[2]?0:movespeed))/fps;
      }
      if(MoveKey[LEFT])
      {
          CamPos[movementAxis[0]]+=(side.X*(constrainedAxis[0]?0:movespeed))/fps;
          CamPos[movementAxis[1]]+=(side.Y*(constrainedAxis[1]?0:movespeed))/fps;
          CamPos[movementAxis[2]]+=(side.Z*(constrainedAxis[2]?0:movespeed))/fps;
      }
      if(MoveKey[RIGHT])
      {
          CamPos[movementAxis[0]]-=(side.X*(constrainedAxis[0]?0:movespeed))/fps;
          CamPos[movementAxis[1]]-=(side.Y*(constrainedAxis[1]?0:movespeed))/fps;
          CamPos[movementAxis[2]]-=(side.Z*(constrainedAxis[2]?0:movespeed))/fps;
      }

      if (MoveKey[FORWARD] || MoveKey[BACKWARD] || MoveKey[LEFT] || MoveKey[RIGHT])
          SendPosition();

      // Set it so that if the space button is being held, the screen doesn't rotate
      if (!selecting && !dispatching && !view2d)
      {
          iy-=((center[1]-mouse[1])*msensitivity ) /fps;   // The mouse movement speed though hasn't been changed
          ix-=((center[0]-mouse[0])*msensitivity ) /fps;
      }

      alListener3f(AL_POSITION, CamPos[0], CamPos[1], CamPos[2]);

      /**************************************************************************
       ************************* Camera Setup Finished *************************
       ***************************************************************************/

      glClearColor(0.0, 0.0, 0.0, 0.0);

      GLubyte buff[3*128*128];

      for (unsigned int i = 0; i < 2 ; i++)
      {
          if (postprocessing && i==0)
              glViewport(0, 0, 128, 128);
          else
              glViewport(0, 0, screen[0], screen[1]);

          if (postprocessing)
              shader_factory.bindShader(Azadi::defaultProgram);

          glMatrixMode(GL_PROJECTION);
          glLoadIdentity();
          glFrustum(-1.0, 1.0, -1.0, 1.0, 1.0, 1500.0);
          glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, 5.0);
          glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, 2.0);
          glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, 1.5);


          glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
          glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
          glLightfv(GL_LIGHT0, GL_POSITION, light_position);
          glMatrixMode(GL_MODELVIEW);
          glLoadIdentity();

          // We DO need light !
          glEnable(GL_LIGHT0);

          if(!dispatching)
          {
              glRotatef(iy, 1, 0, 0);
              glRotatef(ix, 0, 1, 0);
              glTranslatef(CamPos[0],CamPos[1],CamPos[2]);
          }

          glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

          glPushMatrix();

          // If we are dispatching, then run the draw cursor function
          if (dispatching)
              drawCursor(forward, ix, iy);

          // draw particles
          particle_factory.draw(CamPos[0], CamPos[1], CamPos[2]);
          TP.Draw((int)(CamPos[0]), (int)(CamPos[2]));

          //glEnable(GL_LIGHTING);
          glEnable(GL_TEXTURE_2D);
          model_factory.Draw();
          glDisable(GL_LIGHTING);
          glPopMatrix();

          if (!postprocessing)
              i=2;
          else if(i==0)
          {
              glFlush();

              glReadBuffer(GL_BACK);
              glReadPixels(0, 0, 128, 128, GL_RGB, GL_UNSIGNED_BYTE, buff);

              glBindTexture(GL_TEXTURE_2D, posttext);

              if (firstset)
              {
                  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
                  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
                  glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 128, 128, 0, GL_RGB, GL_UNSIGNED_BYTE, buff);
                  firstset = false;
              }
              else
              {
                  glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 128, 128, GL_RGB, GL_UNSIGNED_BYTE, buff);
              }
          }
          else
          {
              shader_factory.bindShader(Azadi::postProgram);
              glDisable(GL_CULL_FACE);
              glEnable(GL_BLEND);
              glMatrixMode(GL_PROJECTION);
              glLoadIdentity();
              glOrtho(0, 0, screen[0], screen[1], -1.0, 2000.0);
              glMatrixMode(GL_MODELVIEW);
              glLoadIdentity();
              glBindTexture(GL_TEXTURE_2D, posttext);
              glBlendFunc(GL_ONE, GL_ONE);

              glColor3f(1.0, 1.0, 1.0);
              glPushMatrix();
              glBegin(GL_QUADS);
              {
                  glTexCoord2f(0.0, 0.0);
                  glVertex3f(-1.0, -1.0, 0.0);
                  glTexCoord2f(1.0, 0.0);
                  glVertex3f(1.0, -1.0, 0.0);
                  glTexCoord2f(1.0, 1.0);
                  glVertex3f(1.0, 1.0, 0.0);
                  glTexCoord2f(0.0, 1.0);
                  glVertex3f(-1.0, 1.0, 0.0);
              }
              glEnd();
              glPopMatrix();
              glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
              glDisable(GL_BLEND);
              glEnable(GL_CULL_FACE);
          }
      }

      //! GUI drawing starts here
      gui_engine.draw(screen[0], screen[1]);
      jukebox.draw(screen[0], screen[1]);
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
      console.draw();
      fps_counter.draw();
      glDisable(GL_TEXTURE_2D);
      Drawing::flipBuffers();
      return true;
  }

  /*! \brief Processes the messages
   */
  void Azadi::ProcessMessages()
  {
      input.get();

      console.parseInput();
      /*
  MoveKey[FORWARD] = input.isKeyDepressed(SDLK_w);
  MoveKey[BACKWARD] = input.isKeyDepressed(SDLK_s);
  MoveKey[LEFT] = input.isKeyDepressed(SDLK_a);
  MoveKey[RIGHT] = input.isKeyDepressed(SDLK_d);
       */
      // done = input.isKeyDepressed(SDLK_ESCAPE) | input.isQuit();

      //   if (input.getKeyPress(SDLK_BACKQUOTE))
      //     console.toggleShow();

      if (input.getKeyPress(SDLK_PAGEUP))
          console.increaseVerbosityLevel();

      if (input.getKeyPress(SDLK_PAGEDOWN))
          console.decreaseVerbosityLevel();



      mouse[0] = input.getMouseX();
      mouse[1] = input.getMouseY();


      if (input.getMouseClick(SDL_BUTTON_RIGHT))
      {

          selecting=false;
          dispatching = true;
          SDL_ShowCursor(SDL_DISABLE);
          cursorPos=100.0;
          curMousePos=mouse[1];

          origPos[0] = -CamPos[0];
          origPos[1] = -CamPos[1];
          origPos[2] = -CamPos[2];

          viewport_matrix[0]=0;
          viewport_matrix[1]=0;
          viewport_matrix[2]=screen[0];
          viewport_matrix[3]=screen[1];

          glGetDoublev(GL_PROJECTION_MATRIX, projection_matrix);
          glGetIntegerv(GL_VIEWPORT, viewport_matrix);
      }




      //input.flush();
  }


  void Azadi::cmdTriggered(std::string cmd)
  {
      if(cmd == "forward")
          MoveKey[FORWARD] = true;
      else if(cmd == "backward")
          MoveKey[BACKWARD] = true;
      else if(cmd == "left")
          MoveKey[LEFT] = true;
      else if(cmd == "right")
          MoveKey[RIGHT] = true;
      else if(cmd == "exit" || cmd == "quit")
          done = true;
      else if(cmd == "m")
      {
          jukebox.toggleVisible();
          selecting = !selecting;
          SDL_ShowCursor((selecting)?SDL_ENABLE:SDL_DISABLE);
          input.get();
          input.flush();
      }

      else if(cmd == "enter")
          script_engine.dostring("keyb_ENTER()");
      else // let's see how that works out --blub
          script_engine.dostring( ( std::string("keyb_") + cmd + std::string("()") ).c_str() );
      //console << cmd << " + " <<GUI::Console::endl();

  }

  void Azadi::cmdReleased(std::string cmd)
  {
      if(cmd == "forward")
          MoveKey[FORWARD] = false;
      else if(cmd == "backward")
          MoveKey[BACKWARD] = false;
      else if(cmd == "left")
          MoveKey[LEFT] = false;
      else if(cmd == "right")
          MoveKey[RIGHT] = false;

      //console << cmd << " - " << GUI::Console::endl();

  }



  std::string Azadi::acceptConsoleCommand(std::string cmd)
  {
      done = true;
      return "?";
  }

  eventListener::~eventListener()
  {

  }

