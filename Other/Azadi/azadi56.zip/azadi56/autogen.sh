#!/bin/sh

mv makefile makefile.std
aclocal
autoconf
touch AUTHORS ChangeLog NEWS README
# automake --add-missing usually makes a link COPYING -> GNU GPL
# so we'll create an empty "license" file here for the first time...
touch COPYING
# this creates an INSTALL file (link) describing the standard make process
# ./configure && make && make install
# this is true here too, of course :)
automake --add-missing
