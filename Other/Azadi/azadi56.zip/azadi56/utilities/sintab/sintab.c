#include <stdio.h>
#include <math.h>

int main()
{
/*
	FILE *fo;
	float i;
	float si;

	printf("This utility will create a sintab.bin containing\ncalculated sin results for numbers between\n0 to 360 incrementing by 0.001\n");

	fo = fopen("sintab.bin", "wb");
	for (i=0; i<360; i+=0.001)
	{
		si = sin(i);
		fwrite(&si, sizeof(float), 1, fo);
	}
	fclose (fo);
	
	printf("Done\n");
*/
	return 0;
}
