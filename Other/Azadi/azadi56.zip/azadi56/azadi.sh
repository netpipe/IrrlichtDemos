# This script will run azadi in the datadir

cd $AZADI_DIR
./azadi-bin || exit 1
exit 0
