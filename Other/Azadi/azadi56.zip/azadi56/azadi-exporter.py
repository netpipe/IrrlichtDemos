#!BPY

"""
Name: 'Azadi Exporter'
Blender: 242
Group: 'Export'
Tip: 'Exports animation, mesh and bone data to Azadis Modelformat'
"""

__version__ = "0.4"
__author__  = "Mathias L. Baumann"
__email__   = "anonym001@supradigital.org"
__url__     = "http://supradigital.org"


# Struct Module
from struct import *


#Blender things
import Blender
from Blender import Armature, Mesh, Window
from Blender.Mathutils import *




bones = list()
vertices = list()
vertexGroups = list()
faces = list()
head = int(-1)
actionlist = list()
bonepositions = list()
textures = list()
frames = list()

class Action:
    def __init__(self):
        self.id = int(-1)
        self.frames = list()
        self.name = str()
        self.packed = str()
        
    def prepare(self):
        tmp = list()     
        tmp.append(len(self.frames))
        tmp.append(len(self.name))           
        tmp.extend(self.frames)
        tmp.append(self.name)
        print tmp
        self.packed = pack("II"+str(len(self.frames))+"I"+str(len(self.name))+"s",*tmp)
        

class Frame:
    def __init__(self):
        self.id = -1
        self.nr = int(-1)
        self.BonePositions = list()
        self.packed = str()

    def prepare(self):
        tmp = list()
        tmp.append(self.nr)
        tmp.append(len(self.BonePositions))        
        self.packed = pack("II",*tmp)
        #print "#########Framenr: ",self.nr, " "
        for bp in self.BonePositions:
            bp.prepare()
            self.packed += bp.packed
            

    def add(self,bonestr,attr,val):
        got_it = False
        bid = -1;
        #print "Add: ",bonestr," ",attr, " ",val
        #print "len is ",self.BonePositions
        for bb in self.BonePositions:
            #print bb.name , " =! " , bonestr
            if bb.name == bonestr:
                #print "found it.."
                bid = bb.id
                got_it = True

        if got_it == False:
            #print "adding it.."
            tmpos = BonePos()
            tmpos.name = bonestr
            tmpos.id= len(self.BonePositions)
            bid = tmpos.id
            self.BonePositions.append(tmpos)

        if attr == "LocX":
            self.BonePositions[bid].locX = val
        if attr == "LocY":
            self.BonePositions[bid].locY = val
        if attr == "LocZ":
            self.BonePositions[bid].locZ = val

        if attr == "QuatW":
            self.BonePositions[bid].rotW = val
        if attr == "QuatX":
            self.BonePositions[bid].rotX = val
        if attr == "QuatY":
            self.BonePositions[bid].rotY = val
        if attr == "QuatZ":
            self.BonePositions[bid].rotZ = val            

    
    

class BonePos:
    def __init__(self):    
        self.id = int(-1)
        self.name = str()        
        self.locX = float()
        self.locY = float()
        self.locZ = float()        
        self.rotW = float()
        self.rotX = float()
        self.rotY = float()
        self.rotZ = float()        
        self.boneID = int(-1)
        self.packed = str()
        
    def prepare(self):
        for bon in bones:
            if bon.name == self.name:
                self.boneID = bon.ID
                
        tmp = list()        
        tmp.append(self.boneID)        
        tmp.append(self.locX)
        tmp.append(self.locZ)
        tmp.append(-self.locY)        
        tmp.append(self.rotW)
        tmp.append(self.rotX)
        tmp.append(self.rotZ)
        tmp.append(-self.rotY)
        #print "BonePos: ",self.name, " BonID; ",self.boneID
        #print "  Loc :",self.locX," X ",self.locY," Y ",self.locZ," Z "
        #print "  Rot :",self.rotW," W ",self.rotX," X ",self.rotY," Y ",self.rotZ," Z "        
        self.packed = pack("I 3f 4f",*tmp)



class texture:
    def __init__(self):
        self.id = int()
        self.name= str()
        self.packed = str()

    def prepare(self):
        tmp = list()
        tmp.append(len(self.name))
        tmp.append(self.name)        
        self.packed = pack("I"+str(len(self.name))+"s",*tmp)




class face:
    def __init__(self):
        self.ID = int(-1)
        self.normal = int(-1)
        self.Vertices = list()
        self.packed = str()
        self.texture = int(0)
        self.uvcoords = list()

    def prepare(self):
        tmp = list()
        tmp.append(self.normal)
        tmp.append(len(self.Vertices))
        tmp.append(self.texture)
        tmp.extend(self.Vertices)        
        
        while(len(self.uvcoords) < len(self.Vertices)*2):
            self.uvcoords.append(0.0)

         
        tmp.extend(self.uvcoords)

        
        self.packed = pack ("III"+str(len(self.Vertices))+"I"+str(len(self.uvcoords))+"f",*tmp) 



class VertexGroup:
    def __init__(self):
        self.vertices = list()
        self.detailsm = int(-1)
        self.boneID = int(-1)
        self.ID = int(-1)
        self.packed = 0
        self.name = str()

    def prepare(self):
        tmp = list()
        tmp.append(self.detailsm)
        tmp.append(self.boneID)
        tmp.append(int(len(self.vertices)))
        tmp.extend(self.vertices)        
        self.packed = pack("III"+str(len(self.vertices))+"I",*tmp)
              





class Vertex:
    def __init__(self):
        self.x=float(0)
        self.y=float(0)
        self.z=float(0)
        self.id=int(0)
        self.packed = 0
        
    def prepare(self):        
        tmp = list()
        tmp.append(self.x)
        tmp.append(self.z)
        tmp.append(-self.y)
        #print self.id," : ",tmp
        self.packed = pack("fff",*tmp)
        

#### BONE STUFF


class Bone:
    def __init__(self):   
        self.ID = int(-1)
        self.fRotation= list() # Quaternion (4 floats)
        self.fOffset  = list() # Vector (3 Floats)
        self.qRotation = 0
        self.vOffset   = 0
        self.fLength  = float(0)
        self.jType   = int(0)
        self.iChildren = list() # Integer List
        self.sChildren = list()
        self.iParent   = int(0)
        self.sParent   = str()
        self.fWeight   = float(0)
        self.name    = str()
        self.packed = str()
        self.options = -1
        self.vergrpID = int(-1)
        self.matrix = 0

    # Prepares the Bone to get written to file
    def prepare(self):
        #self.echo()
        self.fRotation=[self.qRotation.angle,self.qRotation.x,self.qRotation.z,-self.qRotation.y]
        self.fOffset  =[self.vOffset.x,self.vOffset.z,-self.vOffset.y]
        tmp = self.fRotation
        tmp.extend(self.fOffset)
        tmp.append(self.fLength)
        tmp.append(self.jType)
        tmp.extend(self.iChildren)
        tmp.append(self.iParent)
        tmp.append(self.fWeight)
        tmp.append(self.options)
        tmp.append(len(self.name))
        tmp.append(self.name)
        
        self.packed = pack("4f 3f f i 8i i f b I"+str(len(self.name))+"s",*tmp)

    # Prints all Info for debugging
    def echo(self):
        print "ID: ",self.ID
        print "##Name: ",self.name
        print "##Quaternion: ",[self.qRotation.angle,self.qRotation.x,self.qRotation.y,self.qRotation.z]
        print "##Offset Vector: ",[self.vOffset.x,self.vOffset.y,self.vOffset.z]
        print "##Length: ",self.fLength
        print "##Joint Types: ",self.jType
        print "##Childrens IDs: ",self.iChildren
        print "##Parent ID: ",self.iParent
        print "##Options: ",self.options
        print "##VertexGroup: ",self.vergrpID        
        print "\n"

    # Gets the IDs for parent, childrens and vertexGroup
    def getIDs(self):
        self.iChildren = list()
        self.iParent =int(-1)
        for bb in bones:
            if bb.name == self.sParent:
                self.iParent = bb.ID
            for ch in self.sChildren:
                if bb.name == ch:
                    self.iChildren.append(bb.ID)

        while len(self.iChildren) < 8:
            self.iChildren.append(-1) # It have to be 8

        
        
        for grp in vertexGroups:
            if grp.name == self.name:
                grp.boneID = self.ID              



## Adds the bone to the list
def processBone(pbone):
    print "Processing bone ",pbone.name 
    tmp = Bone()
    tmp.ID = len(bones)
    tmp.qRotation = pbone.matrix['ARMATURESPACE'].toQuat()
    tmp.vOffset =   pbone.matrix['ARMATURESPACE'].translationPart()
    tmp.matrix = pbone.matrix['ARMATURESPACE']
    tmp.fWeight = pbone.weight
    tmp.name    = pbone.name         
    tmp.fLength  = pbone.length
    
    # Setting the Options ( we need only HINGE and CONNECTED)
    con=False
    hing=False
    for opt in pbone.options:
        if opt == Armature.CONNECTED:
            con=True
        if opt == Armature.HINGE:
            hing=True

    if con and hing:
        tmp.options=int(2)
    elif con:
        tmp.options=int(0)
    else:
        tmp.options=int(1)
        
    tmp.sChildren = list()    #Reset Childrens
    if pbone.children:
        for pchild in pbone.children:
            if len(tmp.sChildren) > 8:
                Blender.Draw.PupMenu("Error%t|Not more then 8 Children are possible!")
                return False                   
            tmp.sChildren.append(pchild.name) # Add the Name of every Child
           
    if(pbone.parent):
        tmp.sParent = pbone.parent.name
    else:
        tmp.sParent = str()
       
    bones.append(tmp)
    tmp = 0  # Paraniod


###################################################
##  The Functions, Classes and globals end here  ##
###################################################




def export():
    Window.EditMode(0) # leave edit mode before getting the mesh
    objects = Blender.Scene.GetCurrent().getChildren()
    
    for obj in objects:        
        if obj.getType() == 'Armature':
            #add Bones
            for bone in obj.getData().bones.values():
                if processBone(bone) == False:
                    return False
                
        if obj.getType() == 'Mesh':
            ###############################################################
            ###################### Add vertex groups ######################
            ###############################################################

	    matrix= Matrix()
	    matrix.identity()
	    obj.setMatrix(matrix)
	    
            for grpname in obj.getData(False,True).getVertGroupNames():
                verts = list() #vertices in this group
                meshverts  = obj.getData(False,True).verts
                for vertex in obj.getData(False,True).getVertsFromGroup(grpname, False):
                    
                    #first we check if we got already a vertex with this coordiantes
                    got_it = False
                    for savedvertex in vertices:
                        if abs(meshverts[vertex].co.x-savedvertex.x) < 0.000001 and abs(meshverts[vertex].co.y-savedvertex.y) < 0.000001 and abs(meshverts[vertex].co.z-savedvertex.z) < 0.000001:
                            #we got this vertex already
                            verts.append(savedvertex.id)
                            got_it = True

                    if got_it == False: #we havent got it?
                        # add it.
                        newvertex = Vertex()
                        newvertex.x = meshverts[vertex].co.x
                        newvertex.y = meshverts[vertex].co.y
                        newvertex.z = meshverts[vertex].co.z
                        newvertex.id = len(vertices)
                        vertices.append(newvertex)
                        # and also add it to the list of our vertex group
                        verts.append(newvertex.id)

                # all vertices of the group are now in verts, so lets create the group and add it
                grp = VertexGroup()
                grp.ID = len(vertexGroups)
                grp.name = grpname
                grp.vertices = verts
                grp.detailsm = int(obj.layers[0])
                #check if this groupname already exist
                for vg in vertexGroups:
                    if vg.name == grp.name:
                        Blender.Draw.PupMenu('Error%t|Vertex Groups have to be unique! (found '+grp.name+' two times)')
                        return False             
                vertexGroups.append(grp)

            if(len(obj.getData(False,True).getVertGroupNames()) == 0):
                Blender.Draw.PupMenu('Error%t|No Vertex Groups were found for mesh '+obj.getData(False,True).name)
                Blender.Draw.PupMenu('Info%t|It may help you to know that mesh '+obj.getData(False,True).name+" got " + str(len(obj.getData(False,True).verts))+" Vertices")
                for des in objects:
                    des.select(False)
                Blender.Draw.PupMenu('Further Info%t|The mesh has been selected for you.')    
                obj.select(True)
                return False


 

            #############################
            ######### Add faces #########
            #############################             
            for faceElement in obj.getData(False,True).faces:
                tmpface = face()
                tmpface.ID = len(faces)
                normal_written = False
                if(obj.getData(False,True).faceUV) and faceElement.image: #we got UV's
                    got_tex= False
                    for tex in textures:
                        if tex.name == faceElement.image.name:
                            got_tex = True
                            tmpface.texture = tex.id

                    if (got_tex == False):
                        tmptex = texture()
                        tmptex.id = len(textures)
                        tmptex.name = faceElement.image.name
                        textures.append(tmptex)
                        tmpface.texture = tmptex.id                      
                        
                    
                    for uvc in faceElement.uv:
                        tmpface.uvcoords.append(uvc.x)
                        tmpface.uvcoords.append(uvc.y)
                        #print tmpface.ID," uv, ",uvc," -> ",uvc.x, " ",uvc.y

                for edge in faceElement.verts:                
                    for savedvertex in vertices:
                        # check for normal                
                        if abs(faceElement.no.x-savedvertex.x) < 0.000001 and abs(faceElement.no.y-savedvertex.y ) < 0.000001and abs(faceElement.no.z-savedvertex.z) < 0.000001:
                            tmpface.normal = savedvertex.id
                            normal_written = True
                            #print "Found normal: ",savedvertex.id
                            
                        # add the vertices to the index                    
                        if abs(edge.co.x-savedvertex.x) < 0.000001 and abs(edge.co.y-savedvertex.y) < 0.000001 and abs(edge.co.z-savedvertex.z) < 0.000001:
                            #print "Found edge: ",savedvertex.id
                            tmpface.Vertices.append(savedvertex.id)


                    
                if normal_written == False: # Not writteN?
                    
                    norm = Vertex() #than we need to add it
                    norm.id = len(vertices)
                    norm.x = faceElement.no.x
                    norm.y = faceElement.no.y
                    norm.z = faceElement.no.z                    
                    #print "Added normal: ",norm.id
                    vertices.append(norm)                
                    tmpface.normal = norm.id
                
                if(len(tmpface.Vertices) != len(faceElement.verts)):
                    Blender.Draw.PupMenu('Error%t|Could not solve all vertices of face '+str(tmpface.ID)+" in mesh "+obj.getData(False,True).name)
                    Blender.Draw.PupMenu('Info%t|This could mean that its vertices are not part of any vertexGroup.')  
                    
                    for des in objects:
                        des.select(False)
                    obj.select(True)
                    
                    for des in obj.getData(False,True).faces:
                        des.sel=0
                        
                    Blender.Draw.PupMenu('Further Info%t|The face has been selected for you.')   
                    faceElement.sel=1
                    obj.getData(False,True).update()
                    Blender.Redraw()
                    Window.EditMode(1)
                    return False
                
                faces.append(tmpface)           


    if(len(bones) == 0):
        Blender.Draw.PupMenu('Warning%t|No Bones were found! Your model will not be functional!')
        


  
    ######################################################
    ################### Add animations ###################
    ######################################################        
    # Now loop through all the actions
    for name, action in Blender.Armature.NLA.GetActions().iteritems():
        actobj = Action()
        actobj.id = len(actionlist)
        actobj.name = name
        actobj.frames = list()

        
        

        # Loop through all the Ipos (for each bone one)
        for bonename, ipoobj in action.getAllChannelIpos().iteritems():                 
            for curve in ipoobj.curves:
                for point in curve.bezierPoints:
                    # Check if the action got this frame already
                    got_id = False
                    frmid = int(-1)
                    for frm in actobj.frames:                        
                        if frames[frm].nr == point.pt[0]:
                            #print "Found frame"
                            got_id = True
                            frmid = frm

                    if got_id == False:
                        #print "Add frame"
                        tmpfrm = Frame()
                        tmpfrm.id = len(frames)
                        tmpfrm.nr = point.pt[0]
                        frames.append(tmpfrm)
                        frmid = tmpfrm.id
                        actobj.frames.append(frmid)

                    frames[frmid].add(bonename,curve.name,point.pt[1])
                        
                    print actobj.name+" -> "+bonename+"-> "+curve.name+" "+str(point.pt)


        actionlist.append(actobj)
   
        
        








def save(filename):
    fhandler=file(filename,"wb")

    if export() == False:
        return
    
    # Struct of header
    version= int(4)
    numBones=int(len(bones))
    numVertices = len(vertices)
    numFaces = len(faces)
    numGroups = len(vertexGroups)
    numTextures = len(textures)
    numActions = len(actionlist)
    numFrames = len(frames)
    head = pack("IIIIIIII",version,numBones,numVertices,numFaces,numGroups,numTextures,numActions,numFrames)
    
    fhandler.write(head)

    for bone in bones:
        bone.getIDs()
        bone.prepare()
        fhandler.write(bone.packed)

    for vert in vertices:
        vert.prepare()
        fhandler.write(vert.packed)


    for face in faces:
        face.prepare()
        fhandler.write(face.packed)

    for grp in vertexGroups:
        grp.prepare()
        fhandler.write(grp.packed)

    for tex in textures:
        tex.prepare()
        fhandler.write(tex.packed)
        
    for act in actionlist:
        act.prepare()
        fhandler.write(act.packed)

    for fr in frames:
        fr.prepare()
        fhandler.write(fr.packed)
    
    Blender.Draw.PupMenu('Alright%t|Exported '+str(numVertices)+' Vertices and '+str(numFaces)+' Faces.')
        
    fhandler.close()




Blender.Window.FileSelector (save, 'Export',"data.azm")
