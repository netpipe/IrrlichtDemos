#include "Luna.h"
#include <cstdio>

#ifdef __APPLE__
	#import <Cocoa/cocoa.h>
#endif

#ifdef WIN32
	#include <winsock2.h>
#endif

int main ( int argc, char** argv )
{
	#ifdef WIN32
		WSADATA wsaData;

		if ( WSAStartup ( MAKEWORD ( 1, 1 ), &wsaData ) != 0 )
		{
			fprintf ( stderr, "WSAStartup failed.\n" );
			return 1;
		}

	#endif

	#ifdef __OSX__
		NSApplicationLoad();
	#endif

		Luna game ( argc,argv );
		game.Run();

	#ifdef WIN32
		WSACleanup();
	#endif

	return 0;
}




