#ifndef PLAYER_H
#define PLAYER_H

#include <string>

class Player
{
	public:
		Player();
		~Player();

		std::string name;
		std::string guildName;
		unsigned int level;
		unsigned int health;

		bool duelling;
		bool attackable;

		bool inParty;
		bool inGuild;
};

#endif
