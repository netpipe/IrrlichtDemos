#include "Events.h"

bool EventRec::OnEvent(const SEvent &event)
{
    if (event.EventType == EET_GUI_EVENT)
    {
        s32 cid = event.GUIEvent.Caller->getID();

        switch(event.GUIEvent.EventType)
        {
            case EGET_BUTTON_CLICKED:

                switch (cid)
                {
					case 101:
						quit = true;
						return true;
					case 102:
						login = true;
						return true;

					case 104:
						conRefOK = true;
						return true;

					case 105:
						wrongPassOK = true;
						return true;

					case 901:
						devLogin = true;
						return true;
                }
        }
    }

    return false;
}

void EventRec::initialize()
{
    quit = false;
	login = false;
	conRefOK = false;
	wrongPassOK = false;
	devLogin = false;
}
