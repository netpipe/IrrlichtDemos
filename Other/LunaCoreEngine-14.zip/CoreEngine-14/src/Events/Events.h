#ifndef EVENTS_H
#define EVENTS_H

#include "../irrlicht/irrlicht.h"

using namespace irr;

using namespace core;
using namespace scene;
using namespace video;
using namespace io;
using namespace gui;

class EventRec : public IEventReceiver
{
    public:
        virtual bool OnEvent(const SEvent &event);
		void initialize();

        bool quit;
		bool login;
		bool conRefOK;
		bool wrongPassOK;

		// developer login
		bool devLogin;
};


#endif
