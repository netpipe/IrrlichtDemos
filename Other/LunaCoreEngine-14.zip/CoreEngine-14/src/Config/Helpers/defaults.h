#ifndef DEFAULTS_H
#define DEFAULTS_H

#define CONFIG_FILE "./Azadi.cfg"

#endif
