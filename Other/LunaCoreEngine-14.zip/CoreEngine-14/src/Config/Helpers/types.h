#ifndef TYPES_H
#define TYPES_H

#include "types/integer.h"
#include "types/float.h"
#include "types/boolean.h"
#include "types/long.h"

#endif
