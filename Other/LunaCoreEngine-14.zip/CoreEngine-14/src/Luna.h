#ifndef LUNA_H
#define LUNA_H

#include <vector>
#include <string>
#include <sstream>
#include <map>

#include "irrlicht/irrlicht.h"

#include "Events/Events.h"
#include "entities/player.h"
#include "Encryption/Blowfish.h"
#include "Net/Sockets.h"

using namespace irr;

using namespace core;
using namespace scene;
using namespace video;
using namespace io;
using namespace gui;

class Luna
{
    public:
        Luna(int argc, char** argv);
		~Luna(); // Cleans up the engine
        int Run();

        unsigned int resolution[2];
    private:
        int init();
        int shutdown();

        int lobby();
        int mainloop();

		// Developers loop
		int devloop();

		int doLogin(const std::wstring &username, const std::wstring &password);
		int handleMessages();

        IrrlichtDevice *device;
        IVideoDriver *driver;
        ISceneManager *smgr;
        IGUIEnvironment *guienv;

        EventRec events;

		// Encryption
		Encryption::Blowfish enc;

		// Character related
		std::wstring username;
		std::wstring password;

		std::vector<Player> players;

		// Network related
		TCPClientStream *comms;
};

#endif
