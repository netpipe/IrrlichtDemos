#include "Luna.h"

Luna::Luna(int argc, char** argv)
{

}

Luna::~Luna()
{

}

int Luna::init()
{
    device = createDevice(EDT_OPENGL, dimension2d<s32>(1280, 1024), 32, true, true, false, 0);


    device->setWindowCaption(L"Luna v0.01a");

    driver = device->getVideoDriver();
    smgr = device->getSceneManager();
    guienv = device->getGUIEnvironment();

    device->setEventReceiver(&events);

	events.initialize();

    resolution[0] = 1024;
    resolution[1] = 768;

	// generate the encryption keys
	enc.initialize("oijv08w92kljasdfk2jnvxp[z", 25);

    return 0;
}

int Luna::shutdown()
{
    device->drop();

    return 0;
}

int Luna::Run()
{
    if (init() < 0)
        return -1;

    while (device->run() && !events.quit)
    {
        if (lobby() < 0)
        {
            shutdown();
            break;
        }
		if (events.devLogin)
			devloop();
		else
			mainloop();
    }

    shutdown();

    return 0;
}

int Luna::doLogin(const std::wstring &username, const std::wstring &password)
{
	std::string uname(username.begin(), username.end());
	std::string pword(password.begin(), password.end());

	try
	{
		comms = new TCPClientStream(std::string("192.168.1.5"), 5488);
	}
	catch(...)
	{
		return -1;
	}

	// Request an account login
	*comms << "LEPLSAR " << uname << " " << pword << std::endl;
	std::string reply;

	// Obtain the OK from the server
	getline(*comms, reply);

	if (reply != "LEPAOK")
		return 1;

	*comms << "LEPSCR" << std::endl;
	getline(*comms, reply);
	int numOfServers;

	std::istringstream temp(reply);
	temp >> numOfServers;

	std::map<std::string, std::string> servers;
	for (unsigned int i = 0; i < numOfServers; ++i)
	{
		getline(*comms, reply);
		int it = reply.find(" ", 0);
		if (it != reply.size())
			servers[reply.substr(0, it)] = reply.substr(it+1, reply.size());
	}

	return 0;
}

int Luna::mainloop()
{
    if (!device->run())
        return 0;

    // Flush the gui and the scenes
    guienv->clear();
    smgr->clear();

	driver->getTexture("./data/textures/bottomPane800600.png");

    while (device->run() && !events.quit)
    {
        driver->beginScene(true, true, SColor(0, 0, 0, 0));

        smgr->drawAll();
        guienv->drawAll();
        driver->endScene();

        device->sleep(30, true);
    }

    return 0;
}

int Luna::devloop()
{
    if (!device->run())
        return 0;

    // Flush the gui and the scenes
    guienv->clear();
    smgr->clear();

	smgr->loadScene("./data/maps/devland.irr");

	driver->getTexture("./data/textures/bottomPane800600.png");

    while (device->run() && !events.quit)
    {
        driver->beginScene(true, true, SColor(0, 0, 0, 0));

        smgr->drawAll();
        guienv->drawAll();
        driver->endScene();

        device->sleep(30, true);
    }

    return 0;
}

int Luna::handleMessages()
{
	return 0;
}
