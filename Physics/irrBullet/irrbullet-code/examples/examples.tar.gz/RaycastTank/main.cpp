#include <irrlicht.h>
#include <iostream>
//#include "../../include/irrBullet.h"
#include "raycasttankexample.h"

using namespace std;

int main()
{
    CRaycastTankExample example;

    example.runExample();

    return 0;
}
