#include <irrlicht.h>
#include "affectorsexample.h"


int main()
{
    CAffectorsExample example;

    example.runExample();

    return 0;
}
