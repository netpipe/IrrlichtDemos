#include <irrlicht.h>
#include "helloworldexample.h"


int main()
{
    CHelloWorldExample example;

    example.runExample();

    return 0;
}
