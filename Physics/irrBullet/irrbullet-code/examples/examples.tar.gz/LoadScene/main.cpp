#include <irrlicht.h>
#include "loadsceneexample.h"


int main()
{
    CLoadSceneExample example;

    example.runExample();

    return 0;
}
