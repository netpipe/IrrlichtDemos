#include <irrlicht.h>
#include "characterexample.h"


int main()
{
    CCharacterExample example;

    example.runExample();

    return 0;
}
