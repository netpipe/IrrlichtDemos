A very basic demo showing how to implement CSG via BSP tree merging.

- February, 2009 - research started.
- July, 2009 - the project cannot be completed due to lack of time. (University sucks, always keeps me busy with useless things.)

Any good, bad, or ugly feedback will be appreciated.
If you think I have left out something or you have some better ideas,
please feel free to e-mail me.

e-mail :
www.myspace@inbox.ru
usercodegen@ymail.com

                                                     CodeGen
