/*
===============================================================================
	File:	Merge.h
	Desc:.
===============================================================================
*/

#ifndef __MX_DESTRUCTION__BSP_TREE_MERGING_H__
#define __MX_DESTRUCTION__BSP_TREE_MERGING_H__

namespace mix {

}//end of namespace mix

#endif /* ! __MX_DESTRUCTION__BSP_TREE_MERGING_H__ */

//--------------------------------------------------------------//
//				End Of File.									//
//--------------------------------------------------------------//
