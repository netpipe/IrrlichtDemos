/*
===============================================================================
	File:	GameManager.h
	Desc:
===============================================================================
*/

#ifndef __MX_GAME_MANAGER_H__
#define __MX_GAME_MANAGER_H__

namespace mix {


}//end of namespace mix

#endif /* ! __MX_GAME_MANAGER_H__ */

