
Work In Progress!! (c) 2007 All Rights Reserved!

Controls:

mouse - move camera
mouse button - jump
change camera - 1,2
Rotate camera (camera 2 only) - a/d or left/right
Esc - pause/exit

Website:

http://games.xzist.org
