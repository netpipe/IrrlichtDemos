RealisticWaterSceneNode
=======================

Water scene node with reflections and refractions for Irrlicht

![Water demo](http://elviss.lv/files/water_demo.jpg "Water demo")