
#include <Irrlicht.h>

using namespace irr;
using namespace core;
using namespace scene;
using namespace video;
using namespace gui;


// zx spectrum colours from wikipedia, all 15
enum ZXCOLOUR
{
	Black = 0,
	Blue0 = 0xFF0000be,
	Blue1 = 0xFF0000FF,
	Red0 = 0xFFBE0000,
	Red1 = 0xFFFF00FF,
	Magenta0 = 0xFFbe00be,
	Magenta1 = 0xFFFF00FF,
	Green0 = 0xFF00be00,
	Green1 = 0xFF00ff00,
	Cyan0 = 0xFF00bebe,
	Cyan1 = 0xFF00FFFF,
	Yellow0 = 0xFFbebe00,
	Yellow1 = 0xFFFFFF00,
	White0 = 0xFFbebebe,
	White1 = 0xFFFFFFFF,

	// for fuel in tank
	Magenta2 = 0xA0BE00BE
};

// states
enum STATES
{
	STATE_MENU, // the menu
	STATE_GAMEOVER, // game over screen
	STATE_PLAYING, // playing the game
	STATE_LOST_LIFE, // just lost a life, waiting...
	STATE_LAUNCH, // launching
	STATE_PAUSED, // pause game (P key)
	STATE_QUIT // the game is exiting
};


// gameplay
const f32 Thrust = 0.0001f;
const f32 SideThrust = 0.0001f;
const f32 WalkSpeed = 0.0025f;
const f32 Resistance = 0.991f;
const vector2df MaxSpeed(0.007f, 0.01f);
const f32 Gravity = 0.003f;
const s32 MaxEnemies = 12;
const s32 MaxBullets = 6;
const f32 PhaserSpeed = 0.02f;
const u32 TimeBetweenShots = 100;

// layout
const f32 MaxY = 6.0f;
const f32 MaxX = 5.0f;

// gfx
const f32 PhaserWidth = 0.01f;

// laziness
IMesh *billboardMesh=0;

class GameEntity : public ISceneNode
{
public:
	GameEntity(ISceneManager* mgr, vector3df position=vector3df(0,0,0),vector3df scale=vector3df(1,1,1)) 
	 : ISceneNode(mgr->getRootSceneNode(), mgr, -1, position),
	 Velocity(0,0,0), ExpiryTime(0),
	 HasGravity(false), IsDestructable(true), IsAlive(true), IsFragile(false), 
	 Expires(false), Resting(false), LastTime(0), IsCarryable(false), 
	 Score(0), PickUpStage(0), LevelUp(false), LeftFacing(false)
	{
		setAutomaticCulling(EAC_OFF);
	}

	virtual const core::aabbox3d<f32>& getBoundingBox() const { return Box; }
	virtual void OnAnimate(u32 timeMs)
	{
		if (!LastTime)
			LastTime=timeMs;

		f32 t = (f32)(timeMs-LastTime);
		LastTime = timeMs;
		if (!t)
			return;

		vector3df newP = getPosition();

		if (HasGravity && !Resting)
		{
			newP -= vector3df(0,Gravity*t,0);
			Velocity -= Velocity * (1-powf(Resistance,t));
		}

		newP += Velocity*t;

		// is the position off the screen?
		if (newP.X > MaxX || newP.X < -MaxX)
		{
			newP.X += (MaxX*2) * ( newP.X < 0 ? 1 : -1);
		}
		if (newP.X < -MaxY)
		{
			newP.Y = MaxY *0.25f;
		}

		setPosition(newP);
		ISceneNode::OnAnimate(timeMs);
	}
	virtual void render() { }
	void setLeftFacing(bool facing)
	{
		LeftFacing = facing;
		setRotation(vector3df(0, LeftFacing ? 180.0f : 0, 0));
	}

	vector3df Velocity;
	bool HasGravity, // does it fall
		 IsDestructable, // can it be destroyed?
		 IsAlive, // is it playing?
		 IsFragile, // does it break if it hits something solid?
		 Expires, // does it expire?
		 Resting, // has it landed?
		 IsCarryable, // is it something you carry round?
		 LevelUp, // when it hits the ground, does the ship get more complete?
		 LeftFacing; // is it flipped?
	u32 ExpiryTime;
	s32 Score, PickUpStage;
	aabbox3d<f32> Box;
	u32 LastTime;
};

class Billboard : public GameEntity
{
public:
	 Billboard(ISceneManager* mgr, ITexture* textures, s32 tcount=1, vector3df pos=vector3df(0,0,0), vector3df scale = vector3df(0.5,0.5,0.5))
		 : GameEntity(mgr, pos), Bill(0), Textures(textures), Count(tcount)
	 {
		Bill = mgr->addMeshSceneNode(billboardMesh, this, -1, pos, vector3df(0,0,0));
		setScale(scale);
		updateAbsolutePosition();
		Bill->setMaterialType(EMT_TRANSPARENT_ALPHA_CHANNEL);
		Bill->setMaterialTexture(0, textures);
		Box = Bill->getTransformedBoundingBox();
		Box.MaxEdge -= getPosition();
		Box.MinEdge -= getPosition();
		Bill->updateAbsolutePosition();
	}

	IMeshSceneNode *Bill;
	ITexture *Textures;
	s32 Count;
};


class Player : public Billboard, public IEventReceiver
{
public:
	Player(ISceneManager* mgr, ITexture* textures, s32 tcount=1)
		: Billboard(mgr, textures, tcount, vector3df(0,0,0),vector3df(0.25,0.5,0.5)), 
		Boost(false), Direction(false), Shooting(false)
	{
		HasGravity = true;
		IsAlive = true;
		IsDestructable = true;
		PickUp = 0;

		Particles = mgr->addParticleSystemSceneNode(false, this, -1, vector3df(-0.35f,-0.25f,0));
		Particles->setParticleSize(core::dimension2df(0.05f,0.05f));
		Particles->setParticlesAreGlobal(false);
		IParticleEmitter *e= Particles->createPointEmitter(vector3df(0,-0.002f,0), 50, 200, 
			SColor(255,0,0,0), SColor(255,0,0,0),100,300, 30 );
		Particles->setEmitter(e);
		e->drop();

		reset();
	}


	void reset()
	{
		setPosition(vector3df(0,MaxY*0.25f,0));
		updateAbsolutePosition();
		Velocity = vector3df(0,0,0);
		LastTime = 0;
		Boost = false;
		Direction = false;
		Shooting = false;
		setVisible(true);
		IsAlive = true;
	}

	virtual void OnAnimate(u32 timeMs)
	{
		f32 t = (f32)(timeMs-LastTime);

		Particles->setVisible(!Resting && (Boost || Direction));
		if (Resting)
		{
			if (Direction)
				Velocity.X = LeftFacing ? -WalkSpeed : WalkSpeed;
			else
				Velocity.X = 0;
		}
		else
		{
			if (Boost)
				Velocity += vector3df(0,Thrust*t,0);
			if (Direction)
				Velocity += vector3df((SideThrust*t) * (LeftFacing ? -1 : 1 ),0,0);
		}

		
		if (Velocity.X > MaxSpeed.X) Velocity.X = MaxSpeed.X; 
		if (Velocity.X < -MaxSpeed.X) Velocity.X = -MaxSpeed.X; 
		if (Velocity.Y > MaxSpeed.Y) Velocity.Y = MaxSpeed.Y; 
		if (Velocity.Y < -MaxSpeed.Y) Velocity.Y = -MaxSpeed.Y; 

		vector3df p = getPosition();
		if (p.Y > MaxY)
		{
			p.Y=MaxY;
			setPosition(p);
			Velocity.Y*= -0.3f;
		}
		GameEntity::OnAnimate(timeMs);

		if (PickUp)
			PickUp->setPosition(getAbsolutePosition());

	}

	void setPickUp(GameEntity * pickup)
	{
		PickUp = pickup;
	}

	virtual bool OnEvent(SEvent e)
	{
		// process keyboard input
		switch(e.KeyInput.Key)
		{
		case KEY_UP:
			Boost = e.KeyInput.PressedDown;
			if (Boost && Resting)
			{
				setPosition(getPosition() + vector3df(0,0.05f,0));
				Resting=false;
			}
			return true;
		case KEY_RIGHT:
			if (LeftFacing && e.KeyInput.PressedDown)
				setLeftFacing(false);

			Direction=e.KeyInput.PressedDown;

			return true;
		case KEY_LEFT:
			if (!LeftFacing && e.KeyInput.PressedDown)
				setLeftFacing(true);

			Direction=e.KeyInput.PressedDown;
			return true;

		case KEY_CONTROL:
			Shooting=e.KeyInput.PressedDown;

			return true;
			
		}
		return false;
	}

	IParticleSystemSceneNode *Particles;
	GameEntity *PickUp;
	bool Boost, Direction, Shooting;
};

class Enemy : public Billboard
{
public:
	Enemy(ISceneManager* mgr, ITexture* texture, vector3df pos, ZXCOLOUR c, s32 ai=0) 
		: Billboard(mgr, texture, 1),
		AI(ai)
	{
		IsAlive = true;
		IsDestructable = true;
		Bill->getMaterial(0).AmbientColor = c;
		Colour = c;
		setPosition(pos);
		setScale(vector3df(0.3f,0.3f,0.3f));
		updateAbsolutePosition();
		Bill->updateAbsolutePosition();

		f32 direction =  (rand() % 2) ? 1.f : -1.f;
		f32 direction2=  (rand() % 2) ? 1.f : -1.f;

		Score = 50;

		switch(AI)
		{
		case 0: // floaty
			{
			IsFragile = true;
			f32 speed = (f32) (rand() % 4)+1;
			Velocity.Y = -0.0001f * speed;
			Velocity.X = 0.0005f * speed * direction;
			break;
			}
		case 1: // bouncey fuzzballs
			{
			Score = 60;
			Velocity.Y = -0.0025f * direction2;
			Velocity.X = 0.0025f * direction;
			break;
			}
		case 2: // bubbles
			{
			Score = 80;
			Velocity.Y = -0.0015f * direction2;
			Velocity.X = 0.0015f * direction;
			break;
			}
		case 3: // jet things
			{
			Score = 70;
			Velocity.Y = -0.0015f * direction2;
			Velocity.X = 0.003f;
			break;
			}
		case 4: // ufos
			{
			Score = 100;
			Velocity.Y = -0.0015f * direction2;
			Velocity.X = 0.0015f * direction;
			break;
			}
		default:
			
			break;
		}
		setLeftFacing(Velocity.X < 0);

	}
	s32 AI;
	ZXCOLOUR Colour;
};

class Bonus : public GameEntity
{
public:
	Bonus(ISceneManager* mgr, IMesh *part, s32 score, ZXCOLOUR col, vector3df pos) 
		: GameEntity(mgr, pos)
	{
		HasGravity = true;
		IsDestructable = false;
		Score = score;
		Node = mgr->addMeshSceneNode(part, this, -1,
			vector3df(0,-part->getBoundingBox().getCenter().Y,0), vector3df(0,0,0));
		Node->getMaterial(0).AmbientColor = col;
		setScale(vector3df(0.3f,0.3f,0.3f));
		updateAbsolutePosition();
		Box = Node->getTransformedBoundingBox();
		Box.MaxEdge -= getPosition();
		Box.MinEdge -= getPosition();
		ISceneNodeAnimator *anm = mgr->createRotationAnimator( vector3df(0,1.0f,0));
		Node->addAnimator(anm);
		anm->drop();

	}
	IMeshSceneNode *Node;
};

class RocketPart : public GameEntity
{
public:
	RocketPart(ISceneManager* mgr, IMesh *part, s32 PartNo, vector3df pos) : GameEntity(mgr, pos)
	{
		HasGravity = true;
		IsCarryable = true;

		PickUpStage = PartNo;

		Node = mgr->addMeshSceneNode(part, this, -1,
			vector3df(0,-part->getBoundingBox().getCenter().Y,0), vector3df(0,0,0));
		setScale(vector3df(0.3f,0.3f,0.3f));
		Box = Node->getTransformedBoundingBox();
		updateAbsolutePosition();
		Node->updateAbsolutePosition();
		Box.MaxEdge -= getPosition();
		Box.MinEdge -= getPosition();

		if (PartNo > 2)
			setLeftFacing(true); // oops modeled the wrong way around

	}
	IMeshSceneNode* Node;
};
class Rocket : public GameEntity
{
public:
	Rocket(ISceneManager* mgr, IMesh *part, IMesh *part2, IMesh *part3, IVideoDriver *driver) : GameEntity(mgr)
	{
		Driver = driver;
		Target = driver->createRenderTargetTexture(dimension2di(256,256), "Rocket");

		Mesh1 = mgr->addMeshSceneNode(part, this);
		OriginalTex = Mesh1->getMaterial(0).Textures[0];
		Mesh1->setMaterialTexture(0, Target);
		Mesh2 = mgr->addMeshSceneNode(part2, this);
		Mesh2->setMaterialTexture(0, Target);
		Mesh3 = mgr->addMeshSceneNode(part3, this);
		Mesh3->setMaterialTexture(0, Target);

		f32 Yoffset = Mesh1->getTransformedBoundingBox().MinEdge.Y - getPosition().Y;
		setStage(1);
		setScale( vector3df(0.3f, 0.3f, 0.3f));
		setPosition(vector3df(MaxX*0.3f, -Yoffset/2.0f, 0));
		updateAbsolutePosition();
		Mesh1->updateAbsolutePosition();
		Mesh2->updateAbsolutePosition();
		Mesh3->updateAbsolutePosition();
		Flash=true;
	}
	~Rocket()
	{
		if (Target)
			Target->drop();
	}

	void setStage(s32 stage)
	{
		Stage = stage;
		Mesh1->setVisible(true);
		Mesh2->setVisible((Stage > 1));
		Mesh3->setVisible((Stage > 2));
		Driver->setRenderTarget(Target, true, true, video::SColor(255,255,255,255));
		Driver->draw2DImage(OriginalTex, position2di(0,0));
		if ( (Stage > 3 && Stage < 9) || (Stage==9 && Flash) )
		{
			s32 p = 256-( (256/6) * (Stage-3));
			rect<s32> pos(0,p,256,256);
			Driver->draw2DRectangle((SColor)Magenta2, pos);
		}
		Driver->setRenderTarget(0);
		if (Stage==9)
			Flash =! Flash;

		if (Stage==10)
			Velocity.Y = 0.003f;

		if (Stage==11)
			Velocity.Y = -0.002f;
	}

	IMeshSceneNode *Mesh1, *Mesh2, *Mesh3;
	s32 Stage;
	bool Flash;
	ITexture *Target, *OriginalTex;
	IVideoDriver *Driver;

};

class Ledge : public GameEntity
{
public:
	Ledge(ISceneManager* mgr, f32 width, vector3df pos, ZXCOLOUR col, IMesh *mesh) : GameEntity(mgr, pos)
	{
		IsAlive = true;

		updateAbsolutePosition();
		Node = mgr->addMeshSceneNode(mesh, this);
		Node->getMaterial(0).AmbientColor = (SColor)col;
		Node->setScale(vector3df(width*0.60f, 0.15f, 0.25f));
		Node->updateAbsolutePosition();
		Box = Node->getTransformedBoundingBox();
		Box.MaxEdge -= getPosition();
		Box.MinEdge -= getPosition();
		
	}

	ISceneNode *Node;
};

class PhaserFire : public GameEntity
{
public:
	PhaserFire(ISceneManager* mgr) : GameEntity(mgr) 
	{
	}

	void shoot(vector3df pos, s32 direction, u32 length) 
	{
		u32 c = rand() % 3;
		switch (c)
		{
		case 0: Mat.AmbientColor = (SColor)Magenta1; break;
		case 1: Mat.AmbientColor = (SColor)White1; break;
		case 2: Mat.AmbientColor = (SColor)Blue1; break;
		//case 3: Mat.AmbientColor = (SColor)Yellow1; break;
		//case 4: Mat.AmbientColor = (SColor)Cyan1; break;
		}
		StartY = pos.Y;
		StartX = pos.X;
		EndX = pos.X;
		Direction = PhaserSpeed * (f32)direction;
		Length = length;
		Box.reset(pos);
		LastTime=0;
		Finished = false;
		Stopped = false;
	}

	virtual void OnAnimate(u32 timeMs)
	{
		if (!LastTime)
		{
			LastTime=timeMs;
			EndTime = timeMs+Length;
			return;
		}

		f32 tdif = (f32)(timeMs-LastTime);
		LastTime=timeMs;

		if (timeMs > EndTime) 
		{
			// move the tail, check if we've finished
			StartX += Direction * tdif;
			if ((Direction > 0 && StartX > EndX) || (Direction < 0 && EndX < StartX) )
			{
				Finished = true;
			}
			
		}
		else if (!Stopped)
		{
			EndX += Direction * tdif;
		}

		Box.reset(vector3df(StartX, StartY-PhaserWidth,-PhaserWidth ));
		Box.addInternalPoint(vector3df(EndX, StartY+PhaserWidth,PhaserWidth ));

		ISceneNode::OnAnimate(timeMs);

	}

	virtual void OnRegisterSceneNode()
	{
		if (!Finished)
		{
			SceneManager->registerNodeForRendering(this, ESNRP_TRANSPARENT);
		}
		ISceneNode::OnRegisterSceneNode();
	}
	virtual void render()
	{
		SceneManager->getVideoDriver()->setMaterial(Mat);
		SceneManager->getVideoDriver()->setTransform(ETS_WORLD, AbsoluteTransformation);

		SceneManager->getVideoDriver()->draw3DBox(Box);
		aabbox3df b2;
		if (Box.MaxEdge.X > MaxX)
		{
			b2 = Box;
			b2.MaxEdge.X -= MaxX*2;
			b2.MinEdge.X -= MaxX*2;
			SceneManager->getVideoDriver()->draw3DBox(b2);
		}
		if (Box.MinEdge.X < -MaxX)
		{
			b2 = Box;
			b2.MaxEdge.X += MaxX*2;
			b2.MinEdge.X += MaxX*2;
			SceneManager->getVideoDriver()->draw3DBox(b2);
		}
	}

	SMaterial Mat;
	f32 StartY, StartX, EndX;
	bool Stopped, Finished;
	u32 Length;
	f32 Direction;
	u32 LastTime, EndTime;
};

class Explosion : public Billboard
{
public:
	Explosion(ISceneManager* mgr, array<ITexture*> &textures, vector3df pos, ZXCOLOUR col=White1, u32 Length=300) 
		: Billboard(mgr, textures[0], 1)
	{
		IsAlive = true;
		IsDestructable = false;
		Expires = true;
		// create texture animator
		ISceneNodeAnimator *anm = mgr->createTextureAnimator( textures, Length / textures.size(), false);
		Bill->addAnimator(anm);
		anm->drop();
		Bill->getMaterial(0).AmbientColor = col;
		// deletion animator
		anm = mgr->createDeleteAnimator(Length);
		addAnimator(anm);
		anm->drop();

		setPosition(pos);
		updateAbsolutePosition();
		Bill->updateAbsolutePosition();

	}
};


class JetPac : public IEventReceiver
{
public:

	JetPac()
	{
		s32 w=800, h=600;
		device =
			createDevice( video::EDT_DIRECT3D9, dimension2d<s32>(w, h), 32,
				false, false, false, 0);

		device->setWindowCaption(L"JetPac");

		driver = device->getVideoDriver();
		smgr = device->getSceneManager();
		env = device->getGUIEnvironment();

		device->setEventReceiver(this);
		smgr->setAmbientLight(SColorf(1.0, 1.0, 1.0, 1.0));

		loadResources();
		// create stuff
		Camera = smgr->addCameraSceneNode(0, vector3df(0,MaxY/2,-5), vector3df(0,MaxY/2,0));
		player = new Player(smgr, *PlayerTextures.pointer());
		player->setPosition(vector3df(0,MaxY*0.25f,0));

		// floor
		platforms.push_back( new Ledge(smgr, MaxX*2.0f, vector3df(0,0,0), Yellow0, platformMesh));
		// platforms
		platforms.push_back( new Ledge(smgr, MaxX*0.35f, vector3df(MaxX*0.65f,MaxY*0.8f,0), Green0, platformMesh));
		platforms.push_back( new Ledge(smgr, MaxX*0.25f, vector3df(0,MaxY/2.0f,0), Green0, platformMesh));
		platforms.push_back( new Ledge(smgr, MaxX*0.35f, vector3df(-MaxX*0.55f,MaxY*0.7f,0), Green0, platformMesh));
		
		// ship
		ship = new Rocket(smgr, rocketBaseMesh, rocketBodyMesh, rocketConeMesh, driver);

		// bullets
		for (u32 i=0; i<MaxBullets; ++i)
			bullets.push_back( new PhaserFire(smgr));

		// create GUI
		s32 q = w/3;
		ScoreText   = env->addStaticText(L"Score: 0", rect<s32>(0,0,q,80));
		ScoreText->setOverrideColor(Cyan0);
		ScoreText->setTextAlignment(EGUIA_CENTER, EGUIA_CENTER);
		LivesText = env->addStaticText(L"3~", rect<s32>(q,0,q*2,80));
		LivesText->setTextAlignment(EGUIA_CENTER, EGUIA_CENTER);
		LivesText->setOverrideColor(White0);
		HiScoreText = env->addStaticText(L"HiScore: 0", rect<s32>(q*2,0,q*3,80));
		HiScoreText->setTextAlignment(EGUIA_CENTER, EGUIA_CENTER);
		HiScoreText->setOverrideColor(Cyan0);
		MenuText = env->addStaticText(L"Press CTRL to play!", rect<s32>(0,0,w,h));
		MenuText->setTextAlignment(EGUIA_CENTER, EGUIA_CENTER);
		MenuText->setOverrideColor(White0);
		GameOverText = env->addStaticText(L"GAME OVER", rect<s32>(0,0,w,h));
		GameOverText->setTextAlignment(EGUIA_CENTER, EGUIA_CENTER);
		GameOverText->setOverrideColor(White1);
		GameOverText->setVisible(false);
		setHiScore(0);
		setScore(0);
		setLives(3);

		setState(STATE_MENU);
	}
	~JetPac()
	{
		player->drop();
		u32 i;
		for (i=0; i<platforms.size(); ++i)
			platforms[i]->drop();

		for (i=0; i<enemies.size(); ++i)
			enemies[i]->drop();

		for (i=0; i<collectables.size(); ++i)
			collectables[i]->drop();

		ship->drop();

		device->drop();
	}

	// clear everything and start a new game
	void newGame()
	{
		// menu->setVisible(false);

		setScore(0);
		setLives(3);
		Level = 4;
		startLevel();

		setState(STATE_PLAYING);
	}
	void setState(STATES state)
	{
		State = state;
		MenuText->setVisible(State == STATE_MENU);
		GameOverText->setVisible(State == STATE_GAMEOVER);

		switch(state)
		{
		case STATE_PLAYING:
		{
			// remove enemies
			for (u32 i=0; i<enemies.size(); ++i)
			{
				enemies[i]->remove();
				enemies[i]->drop();
			}
			enemies.clear();
			// respawn player
			player->reset();
			NextShootTime = 0;
			NextFlashTime = 0;
			break;
		}
		case STATE_LAUNCH:
		{
			ship->setStage(10); // we have ignition!
			player->setVisible(false);
			player->IsAlive = false;
			break;
		}
		default:
			break;

		}

	}

	bool startLevel()
	{
		u32 t = device->getTimer()->getTime();
		// clear enemies
		u32 i;
		for (i=0; i<enemies.size(); ++i)
		{
			enemies[i]->remove();
			enemies[i]->drop();
		}
		enemies.clear();

		// clear pickups
		for (i=0; i<collectables.size(); ++i)
		{
			collectables[i]->remove();
			collectables[i]->drop();
		}
		collectables.clear();

		// launch enemies!!
		NextEnemyTime = t + rand() % 1000;
		NextBonusTime = t + rand() % 60000;

		// reset ship. every 4th level you have to start again
		if (Level%4 == 1)
		{
			ship->setStage(1);
			RocketPart* rp = new RocketPart(smgr, rocketBodyMesh, 1, vector3df(0, MaxY, 0));
			collectables.push_back( rp );
			rp = new RocketPart(smgr, rocketConeMesh, 2, vector3df(-MaxX*0.5f, MaxY, 0));
			collectables.push_back( rp );

			ship->Velocity.Y = 0.0f;
			//ship->setPosition();

			NextFuelTime = 0;
			return true;
		}
		else
		{
			ship->setStage(3);
			NextFuelTime = t + rand() % 20000;
			return false;
		}
		
	}

	void loadResources()
	{
		// add archive
		device->getFileSystem()->addFolderFileArchive("media");

		// load font
		font = env->getFont("ZXFont.png");
		env->getSkin()->setFont(font);

		// load platform
		platformMesh = smgr->getMesh("platform.obj")->getMesh(0);

		// load player
		PlayerTextures.push_back(driver->getTexture("jetpac.png"));

		// load rocket
		rocketBaseMesh = smgr->getMesh("rocket_base2.obj")->getMesh(0);
		rocketBodyMesh = smgr->getMesh("rocket_body2.obj")->getMesh(0);
		rocketConeMesh = smgr->getMesh("rocket_cone2.obj")->getMesh(0);

		// load fuel
		fuelMesh = smgr->getMesh("fuel.obj")->getMesh(0);
		billboardMesh = smgr->getMesh("billboard.obj")->getMesh(0);

		// load bad guys
		BadGuyTextures.push_back(driver->getTexture("comet.png"));
		BadGuyTextures.push_back(driver->getTexture("fuzzy.png"));
		BadGuyTextures.push_back(driver->getTexture("bubble.png"));
		BadGuyTextures.push_back(driver->getTexture("jet.png"));
		BadGuyTextures.push_back(driver->getTexture("ufo.png"));
		//BadGuyTextures.push_back(driver->getTexture("cross.png"));
		//BadGuyTextures.push_back(driver->getTexture("frog.png"));

		BonusMeshes.push_back( smgr->getMesh("bonus1.obj")->getMesh(0)); // yarble
		BonusMeshes.push_back( smgr->getMesh("bonus2.obj")->getMesh(0)); // gold
		BonusMeshes.push_back( smgr->getMesh("bonus3.obj")->getMesh(0)); // diamond
		//BonusMeshes.push_back( smgr->getMesh("bonus4.obj")->getMesh(0)); // pearl

		// load explosion
		ExplosionTextures.push_back(driver->getTexture("explosion0.png"));
		ExplosionTextures.push_back(driver->getTexture("explosion1.png"));
		ExplosionTextures.push_back(driver->getTexture("explosion2.png"));
		ExplosionTextures.push_back(driver->getTexture("explosion3.png"));
	}

	// start the game loop
	void run()
	{
		u32 now = device->getTimer()->getTime();

		while(State != STATE_QUIT)
		{
			if (device->isWindowActive())
			{
				if (!device->run())
				{
					setState(STATE_QUIT);
				}
				else
				{
					driver->beginScene(true, true, SColor(0,0,0,0));
					if (State != STATE_MENU)
						smgr->drawAll();

					env->drawAll();
					driver->endScene();
					if (State != STATE_MENU)
					{
						logicAndCollisions();
						spawnThings();
					}
					device->sleep(1);
				}
			}
		}
	}
	// create stuff...
	void spawnThings()
	{
		u32 t = device->getTimer()->getTime();

		if (State == STATE_LOST_LIFE && t > NextMenuTime)
		{
			if (Lives > 0)
				setState(STATE_PLAYING);
			else
			{
				setState(STATE_GAMEOVER);
				NextMenuTime = t + 3000;
			}

		}

		if (NextFuelTime && t > NextFuelTime)
		{
			// spawn fuel
			NextFuelTime = 0;
			f32 p = (rand() % (s32)(MaxX*2-2)) - MaxX + 1;
			collectables.push_back( new RocketPart(smgr, fuelMesh, ship->Stage, vector3df(p, MaxY+3, 0)));
		}

		if (t > NextEnemyTime)
		{
			NextEnemyTime = t + rand() % (1000 - 900 / ( Level > 19 ? 1 : 20-Level ));
			if (enemies.size() < (u32)(MaxEnemies+Level))
			{
				// spawn new enemy
				
				ZXCOLOUR c;
				u32 p = rand() % 4;
				switch (p)
				{
				case 0: c = Red0; break;
				case 1: c = Cyan0; break;
				case 2: c = Magenta0; break;
				case 3: c = Green0; break;
				}
				f32 height = (rand() % (s32)MaxY) + 2.f;
				vector3df pos(-MaxX,height,0);

				enemies.push_back( new Enemy(smgr, BadGuyTextures[(Level-1) % BadGuyTextures.size()], pos, c, (Level-1) % BadGuyTextures.size()) );
			}
		}

		if (NextBonusTime && t > NextBonusTime)
		{
			// spawn new bonus
			u32 no = rand() % BonusMeshes.size();
			ZXCOLOUR c;
			switch (no)
			{
			case 0: c = Cyan0; break; // triyarble
			case 1: c = Yellow1; break; // gold bar
			case 2: c = White1; break; // diamond
			//case 3: c = White0; break; // pearl
			}
			f32 p = (rand() % (s32)(MaxX*2-2)) - MaxX + 1;
			collectables.push_back( new Bonus(smgr, BonusMeshes[no], 1000*no, c, vector3df(p, MaxY+3, 0)));
			NextBonusTime = 0;
		}
	}

	void setScore(s32 newScore)
	{
		if (!newScore)
			NextExtraLife = 1;

		Score = newScore;
		if (Score > HiScore)
			setHiScore(Score);

		stringw txt = L"Score: ";
		txt += Score;
		if ((u32)Score > NextExtraLife*20000)
		{
			NextExtraLife ++;
			setLives(Lives+1);
		}
		ScoreText->setText(txt.c_str());
	}

	void setLives(s32 l)
	{
		Lives = l;
		stringw txt = l;
		txt += L"~";
		LivesText->setText(txt.c_str());
	}

	void setHiScore(s32 newScore)
	{
		HiScore = newScore;

		stringw txt = L"High: ";
		txt += HiScore;
		HiScoreText->setText(txt.c_str());
	}

	void logicAndCollisions()
	{
		
		u32 now = device->getTimer()->getTime();
		u32 i, j;
		aabbox3df b = player->getTransformedBoundingBox();
		vector3df p = player->getPosition();
		bool collision =false;

		// dead players can't do any of this-
		if (player->IsAlive)
		{

			// shoot
			if (player->Shooting && now > NextShootTime)
			{
				for (u32 i=0; i<bullets.size(); ++i)
				{
					if (bullets[i]->Finished)
					{
						bullets[i]->shoot(player->getPosition() + vector3df(0,-0.04f,0), player->LeftFacing ? -1 : 1, 350);
						NextShootTime = now + TimeBetweenShots;
						break;
					}
				}
			}

			// collide player with world
			for (i=0; i<platforms.size(); ++i)
			{
				aabbox3df b2 = platforms[i]->getTransformedBoundingBox();

				if (b.intersectsWithBox(b2))
				{
					collision = true;
					
					if (b.MinEdge.Y > platforms[i]->getPosition().Y)
					{
						if (p.X > b2.MinEdge.X && p.X < b2.MaxEdge.X)
						{
							// landed
							player->Resting = true;
						}
						else
						{
							player->Resting = false;
						}
						p.Y += b2.MaxEdge.Y - b.MinEdge.Y;
						player->Velocity.Y = 0;
						player->setPosition(p);
					}
					else
					{
						player->Resting = false;
						if (p.X > b2.MinEdge.X && p.X < b2.MaxEdge.X)
						{
							// roof
							player->Velocity.Y *= -0.3f;
						}
						else
						{
							// wall
							if (p.X > b2.MaxEdge.X)
							{
								p.X += b2.MaxEdge.X - b.MinEdge.X + 0.02f;
								player->Velocity.X = 0.002f;
							}
							else
							{
								p.X += b2.MinEdge.X - b.MaxEdge.X - 0.02f;
								player->Velocity.X = -0.002f;
							}
							player->setPosition(p);
						}
					}
				}
			}

			if (!collision && player->Resting) 
				player->Resting = false;

			// player and pickups
			for (j=0; j<collectables.size(); ++j)
			{
				if (!collectables[j]->IsCarryable || (!collectables[j]->LevelUp && !player->PickUp && (ship->Stage == collectables[j]->PickUpStage || collectables[j]->PickUpStage > 9) ))
				{
					aabbox3df b2 = collectables[j]->getTransformedBoundingBox();
					if (b.intersectsWithBox(b2))
					{
						if (collectables[j]->IsCarryable)
						{
							collectables[j]->Resting = true;
							collectables[j]->LevelUp = true; // for when it gets dropped
							player->setPickUp(collectables[j]);
						}
						else
						{
							setScore(Score + collectables[j]->Score);
							collectables[j]->remove();
							collectables[j]->drop();
							collectables.erase(j--);
							NextBonusTime = now + 30000 + rand() % 30000;
						}
					}
				}
			}

			// player dropping pickup
			vector3df p2 = ship->getPosition();
			p2.Y = p.Y;
			if (player->PickUp && b.isPointInside(p2))
			{
				// drop pickup
				player->PickUp->setPosition(p2);
				player->PickUp->Resting = false;
				player->setPickUp(0);
			}

			// player entering spaceship
			if (ship->Stage == 9 && player->Resting && b.isPointInside(ship->getPosition()))
			{
				setState(STATE_LAUNCH);
			}

		} // <- dead players can't do any of that

		// enemies		
		
		for (i=0; i<enemies.size(); ++i)
		{
			b = enemies[i]->getTransformedBoundingBox();
			aabbox3df b2;

			// enemies going too far out of bounds
			if (b.MaxEdge.Y > MaxY + 2)
			{
				// remove it
				enemies[i]->drop();
				enemies[i]->remove();
				enemies.erase(i--);
			}

			if (player->IsAlive)
			{
				// enemies and player
				b2 = player->getTransformedBoundingBox();
				if (b.intersectsWithBox(b2))
				{
					Explosion *e = new Explosion(smgr, ExplosionTextures, b.getCenter());
					e->drop();
					enemies[i]->drop();
					enemies[i]->remove();
					enemies.erase(i--);

					e = new Explosion(smgr, ExplosionTextures, b2.getCenter());
					e->drop();
					
					setLives(Lives-1);
					player->setVisible(false);
					player->IsAlive = false;
					if (player->PickUp)
					{
						player->PickUp->LevelUp = false;
						player->PickUp->Resting = false;
						player->setPickUp(0);
					}

					NextEnemyTime = now + 10000;
					NextMenuTime = now + 5000;

					State = STATE_LOST_LIFE;
					return;
				}
			}

			// enemies and scenery
			for (j=0; j < platforms.size(); ++j)
			{
				b2 = platforms[j]->getTransformedBoundingBox();

				if (b.intersectsWithBox(b2))
				{
					if (enemies[i]->IsFragile)
					{
						// destroy enemy
						Explosion *e = new Explosion(smgr, ExplosionTextures, b.getCenter(), enemies[i]->Colour);
						e->drop();
						enemies[i]->drop();
						enemies[i]->remove();
						enemies.erase(i--);
						break;
					}
					else
					{
						// change direction
						/*if (b.MaxEdge.X > b2.MinEdge.X && b.MinEdge.X < b2.MaxEdge.X)
						{
							enemies[i]->Velocity.X *=-1.f;
						}else*/
						if (b.MaxEdge.Y > b2.MinEdge.Y && b.MinEdge.Y < b2.MaxEdge.Y)
						{
							enemies[i]->Velocity.Y *=-1.f;
						}

					}

					
				}
			}
			// enemies and bullets
			for (j=0; j < bullets.size(); ++j)
			{
				if (!bullets[j]->Finished)
				{
					b2 = bullets[j]->getBoundingBox();
					bool destroy = false;
					
					if (b.intersectsWithBox(b2))
						destroy=true;

					aabbox3df b3;

					if (!destroy && b2.MaxEdge.X > MaxX)
					{
						b3 = b2;
						b3.MaxEdge.X -= MaxX*2;
						b3.MinEdge.X -= MaxX*2;

						if (b.intersectsWithBox(b3))
							destroy=true;
					}
					if (!destroy && b2.MinEdge.X < -MaxX)
					{
						b3 = b2;
						b3.MaxEdge.X += MaxX*2;
						b3.MinEdge.X += MaxX*2;
						if (b.intersectsWithBox(b3))
							destroy=true;
					}

					if (destroy)
					{
						setScore( Score + enemies[i]->Score );
						// destroy enemy
						Explosion *e = new Explosion(smgr, ExplosionTextures, b.getCenter(), enemies[i]->Colour);
						e->drop();
						enemies[i]->drop();
						enemies[i]->remove();
						enemies.erase(i--);
						break;

					}

				}
			}

		}

		// todo: weapons and scenery?

		// pickups and scenery

		for (j=0; j<collectables.size(); ++j)
		{
			if (collectables[j]->Resting)
				continue;

			b = collectables[j]->getTransformedBoundingBox();
		
			for (i=0; i<platforms.size(); ++i)
			{
				aabbox3df b2 = platforms[i]->getTransformedBoundingBox();

				if (b.intersectsWithBox(b2))
				{
					collectables[j]->Resting = true;
					if (collectables[j]->LevelUp)
					{
						ship->setStage(ship->Stage +1);
						if (ship->Stage > 2 && ship->Stage < 9)
						{
							NextFuelTime = device->getTimer()->getTime() + rand() % 20000;
						}

						collectables[j]->drop();
						collectables[j]->remove();
						collectables.erase(j--);

					}
					break;
				}
			} 
		} // pickups + scenery

		// ship flashing
		if (ship->Stage == 9 && now > NextFlashTime )
		{
			ship->setStage(9);
			NextFlashTime = now + 400;
		}
		if (State == STATE_LAUNCH)
		{
			if (ship->Stage == 10) // up
			{
				if (ship->getTransformedBoundingBox().MinEdge.Y > MaxY+2)
				{
					Level = Level + 1;
					setScore(Score + 2000);
					if (!startLevel())
					{
						ship->setStage(11);
					}
				}
			}
			else if (ship->Stage == 11) // down
			{
				if (ship->getTransformedBoundingBox().MinEdge.Y <
					platforms[0]->getTransformedBoundingBox().MaxEdge.Y)
				{
					ship->setStage(3);
					ship->Velocity.Y = 0.0f;
					setState(STATE_PLAYING);
				}
			}
		}
		// game over to menu
		if (State == STATE_GAMEOVER && now > NextMenuTime)
		{
			setState(STATE_MENU);
		}
	}

	virtual bool OnEvent(SEvent e)
	{
		// process keyboard input

		if (e.EventType == EET_KEY_INPUT_EVENT)
		{

			switch(State)
			{
			case STATE_MENU:
				if (!e.KeyInput.PressedDown && e.KeyInput.Key == KEY_CONTROL)
					newGame();
				break;
			case STATE_PLAYING:
				if (player->IsAlive)
				{
					if (player->OnEvent(e))
						return true;
				}
				break;
			case STATE_GAMEOVER:
				if (!e.KeyInput.PressedDown)
				{
					setState(STATE_MENU);
					return true;
				}
				break;
			default:
				return true;
				break;
			}
		}

		return false;
	}

private:

	// business as usual
	IrrlichtDevice *device;
	ISceneManager *smgr;
	IVideoDriver *driver;
	IGUIEnvironment *env;

	// game state stuff
	s32 Lives, Score, HiScore, Level;
	u32 NextFuelTime, NextBonusTime, NextEnemyTime, 
		NextMenuTime, NextShootTime, NextFlashTime, NextExtraLife;

	// game resources
	IMesh *rocketBaseMesh, *rocketBodyMesh, *rocketConeMesh, *fuelMesh, *platformMesh;
	array<ITexture*> BadGuyTextures;
	array<ITexture*> ExplosionTextures;
	array<ITexture*> PlayerTextures;
	array<IMesh*> BonusMeshes;
	IGUIFont *font;

	// scene stuff
	ICameraSceneNode *Camera;
	Player *player;
	Rocket *ship;
	array<Ledge*> platforms;
	array<Enemy*> enemies;
	array<GameEntity*> collectables;
	array<PhaserFire*> bullets;

	// gui
	IGUIStaticText *ScoreText, *HiScoreText, *LivesText, *GameOverText, *MenuText;

	STATES State;
};
