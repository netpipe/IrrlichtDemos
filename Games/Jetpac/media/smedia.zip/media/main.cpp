
#include "Jetpac.h"

#ifdef _IRR_WINDOWS_
#pragma comment(lib, "Irrlicht.lib")
#endif


int main()
{
	JetPac *j = new JetPac();

	j->run();

	delete j;

	return 0;
}

