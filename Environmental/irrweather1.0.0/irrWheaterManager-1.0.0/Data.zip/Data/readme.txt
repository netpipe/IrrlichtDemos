-- irrWeatherManager 0.0.5 --

Thanks for using irrWeatherManager!

This was originally created for the Fighters Tactical Warfare combat simulation project, and is now
released, open-source, to C++ developers to use in their Irrlicht projects.

A lot of credit is due to Pazystamo and Bitplane for their two great projects:
ATMOsphere and Cloud Scene Node

These are a major part of the weather manager.


Please report bugs and give feedback at fighterstw@hotmail.com

- Josiah Hartzell (fighterstw@hotmail.com)


Special Thanks -

irrWeatherManager contains parts of code from these projects:

Changed or improved:
-	Pazystamo - ATMOsphere (www.pazystamo.projektas.lt)

Code that remains unchanged (Sudi's lightning scene node):
-	http://irrlicht.sourceforge.net/phpBB2/viewtopic.php?t=30176&highlight=cboltscenenode

Code used as a base for a whole new system:
-	Bitplane - CCloudSceneNode (and the irrExt fix) (http://irrlicht.sourceforge.net/phpBB2/viewtopic.php?t=7746&postdays=0&postorder=asc&highlight=cloud&start=0)

-- CloudSceneNode --


cloud01, cloud02, cloud03 are from sauerbraten (probably by remus) www.sauerbraten.org
The textures are free to use for both personal and commercial purposes.

-- irrWeatherManager 1.0.0 --

The update and the rewritting were made by Gawaboumga (Copyright (C) 20013-2014 Youri Hubaut)

I would like to thank a lot Pazystamo, Josiah Hartzell and tbw (I didn't find his real name) for their great projects: ATMOsphere, irrWeatherManager and CloudSceneNode.

