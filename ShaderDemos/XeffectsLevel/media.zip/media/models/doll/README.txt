Thank you for downloading Larry. Larry was made for your artistic vision in mind as well as for practice (In whatever you plan to make it do). This model does not come with a rig and may be released with a rig later on.

This model are available for you to use for any of your projects, if you do use  this file, please send me the link where
this file is being used, and if used in a video, I ask that you add me to the credits. I'd like to see what you guys come up with.

If you have any questions or comments about the model, you can email me at crew.christobel@mail.com 