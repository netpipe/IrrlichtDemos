  return __ffmpegjs_return;
}

module["exports"] = __ffmpegjs;
