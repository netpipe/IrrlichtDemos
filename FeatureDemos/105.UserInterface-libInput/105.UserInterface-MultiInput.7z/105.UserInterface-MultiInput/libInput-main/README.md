# x11 multiple device
x11 multiple device

was inspired by xinput xitest2 to freelance a library that could connect to mice and keyboards to get their states the same method. with cairo I could see this being easy to impliment overtop of existing xsessions.

freelanced by www.netpipe.ca

https://www.freelancer.com/u/mykelectronics was freelancer used for project.

use cmake . then make to compile and run the query_state demo to see API in action.
example query_state.cpp has the api frontend usage example.


https://github.com/netpipe/frostWM has more x11 code there

might even work with windows via www.straightrunning.com/XmingNotes ?

might impliment into OIS next open input system

https://github.com/NoobsArePeople2/manymouse has parts for the windows version.



todo
xdotool screen click support and cairo passthrough /screenshots soon
currently has wacom tablet support just needs to be finished.
